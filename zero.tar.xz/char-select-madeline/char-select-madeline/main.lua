-- name: [CS] Madeline
-- description: Madeline has climbed so many mountains she reached the Mushroom Kingdom... Help her overcome her own insecurities and defeat Bowser who stole all of her strawberries (and the stars)!\n\nModels done by Violet\n\nCoding done by EmilyEmmi\n\nVoicelines done by MelissaMekrose\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!
-- category: cs

-- Replace Mod Name with your Character/Pack name.
local TEXT_PACK_NAME = "Madeline"

-- Stops mod from loading if Character Select isn't on, Does not need to be touched
if not charSelect then
    djui_popup_create(
    "\\#ffffa0\\"..TEXT_PACK_NAME.." requires\nCharacter Select to be enabled.\n\nPlease rehost with it enabled.", 4)
    return
end

characterTable = {
    {
        name = "Madeline",
        nickname = "Madeline",
        description = "A young Canadian miss who loves to overcome challenges. Always ready for some most likely deadly platforming.",
        credits = "Violet",
        color = { r = 118, g = 182, b = 182 },               -- Menu Color
        model = smlua_model_util_get_id("madeline_violet_geo"), -- Replace custom_model to your character model's name.
        forceChar = CT_MARIO,                                -- Builds upon Vanilla Character
        lifeIcon = get_texture_info("madeline_violet_icon"),     -- File extension (.png) not needed here, converted to .tex on refresh
        camScale = 1,                                        -- Sets the camera scale of your character in the CS menu

        graffiti = get_texture_info("madeline_violet_icon"),

        palettes = {
            {
                name     = "Default",
                [PANTS]  = '363A43',
                [SHIRT]  = '76B6B6',
                [GLOVES] = 'FDD3A4',
                [SHOES]  = '27292E',
                [HAIR]   = 'FE7352',
                [SKIN]   = 'FDD3A4',
                [CAP]    = 'AF2138',
                [EMBLEM] = 'FFFFFF'
            },
            {
                name    = "Pico-8",
                [PANTS] = 'FF004D',
                [SHIRT] = '008751',
                [GLOVES] = 'FFF1E8',
                [SHOES] = 'FFF1E8',
                [HAIR] = 'FF004D',
                [SHOES] = 'FFF1E8',
                [SKIN] = 'FFCCAA',
                [CAP] = 'FF004D',
                [EMBLEM] = 'FF004D'
            },
            {
                name    = "Lani",
                [PANTS] = '7E2553',
                [SHIRT] = 'FFEC27',
                [GLOVES] = 'FFF1E8',
                [SHOES] = 'FFF1E8',
                [HAIR] = '1D2B53',
                [SHOES] = 'FFF1E8',
                [SKIN] = 'AB5236',
                [CAP] = '7E2553',
                [EMBLEM] = '7E2553'
            }
        },

        voices = {
            [CHAR_SOUND_OKEY_DOKEY] =         'MadelineOkeyDokie.ogg', -- Starting game
        	[CHAR_SOUND_LETS_A_GO] =          'MadelineLetsAGo.ogg', -- Starting level
        	[CHAR_SOUND_PUNCH_YAH] =          'MadelineYah.ogg', -- Punch 1
        	[CHAR_SOUND_PUNCH_WAH] =          'MadelineWah.ogg', -- Punch 2
        	[CHAR_SOUND_PUNCH_HOO] =          'MadelineHoo.ogg', -- Punch 3
        	[CHAR_SOUND_YAH_WAH_HOO] =       {'MadelineWah.ogg', 'MadelineYah.ogg', 'MadelineHoo.ogg'}, -- First Jump Sounds
        	[CHAR_SOUND_HOOHOO] =             'MadelineHoohoo.ogg', -- Second jump sound
        	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'MadelineYahoo.ogg'}, -- Triple jump sounds
			[CHAR_SOUND_UH] =                 'MadelineUh.ogg', -- Wall bonk
			[CHAR_SOUND_UH2] =                'MadelineUh.ogg', -- Landing after long jump
			[CHAR_SOUND_UH2_2] =              'MadelineUh.ogg',
        	[CHAR_SOUND_DOH] =                'MadelineDoh.ogg', -- Hard wall bonk
        	[CHAR_SOUND_OOOF] =               'MadelineOoof.ogg', -- Attacked in air
        	[CHAR_SOUND_OOOF2] =              'MadelineOoof.ogg', -- Land from hard bonk
        	[CHAR_SOUND_HAHA] =               'MadelineHaha.ogg', -- Landing triple jump
        	[CHAR_SOUND_HAHA_2] =             'MadelineHaha.ogg', -- Landing in water from big fall
        	[CHAR_SOUND_YAHOO] =              'MadelineYahoo.ogg', -- Long jump
        	[CHAR_SOUND_WHOA] =               'MadelineWhoa.ogg', -- Grabbing ledge
        	[CHAR_SOUND_EEUH] =               'MadelineEeuh.ogg', -- Climbing over ledge
        	[CHAR_SOUND_WAAAOOOW] =           'MadelineFalling.ogg', -- Falling a long distance
        	[CHAR_SOUND_TWIRL_BOUNCE] =       'MadelineBoing.ogg', -- Bouncing off of a flower spring
        	[CHAR_SOUND_GROUND_POUND_WAH] =   'MadelineWah.ogg', -- Ground Pound after startup
        	[CHAR_SOUND_WAH2] =               'MadelineWah.ogg', -- Throwing something
        	[CHAR_SOUND_HRMM] =               'MadelineHrmm.ogg', -- Lifting something
        	[CHAR_SOUND_HERE_WE_GO] =         'MadelineHereWeGo.ogg', -- Star get
        	[CHAR_SOUND_SO_LONGA_BOWSER] =    'MadelineBowser.ogg', -- Throwing Bowser
        --DAMAGE
        	[CHAR_SOUND_ATTACKED] =     'MadelineDamaged.ogg', -- Damaged
        	[CHAR_SOUND_PANTING] =      'MadelinePanting.ogg', -- Low health
        	[CHAR_SOUND_PANTING_COLD] = 'MadelinePanting.ogg', -- Getting cold
        	[CHAR_SOUND_ON_FIRE] =      'MadelineBurning.ogg', -- Burned
        --SLEEP SOUNDS
        	[CHAR_SOUND_IMA_TIRED] = 'MadelineTired.ogg', -- Mario feeling tired
        	[CHAR_SOUND_YAWNING] =   'MadelineYawn.ogg', -- Mario yawning before he sits down to sleep
        	[CHAR_SOUND_SNORING1] =  'MadelineSnore1.ogg', -- Snore Inhale
        	[CHAR_SOUND_SNORING2] =  'MadelineSnore2.ogg', -- Exhale
        --COUGHING (USED IN THE GAS MAZE)
			[CHAR_SOUND_COUGHING3] = 'MadelineCough1.ogg', -- Cough take 1
			[CHAR_SOUND_COUGHING3] = 'MadelineCough2.ogg', -- Cough take 2
        	[CHAR_SOUND_COUGHING3] = 'MadelineCough3.ogg', -- Cough take 3
        --DEATH
        	[CHAR_SOUND_DYING] =    'MadelineDead.ogg', -- Dying from damage
        	[CHAR_SOUND_DROWNING] = 'MadelineDrown.ogg', -- Running out of air underwater
        	[CHAR_SOUND_MAMA_MIA] = 'MadelineMamaMia.ogg' -- Booted out of level
        },
    },
        {
        name = "Badeline",
        nickname = "Badeline",
        description = "The dark alter ego of Madeline. She is there to bring pain and torment to... herself?",
        credits = "Violet",
        color = { r = 151, g = 96, b = 170 },               -- Menu Color
        model = smlua_model_util_get_id("badeline_violet_geo"), -- Replace custom_model to your character model's name.
        forceChar = CT_MARIO,                                -- Builds upon Vanilla Character
        lifeIcon = get_texture_info("badeline_violet_icon"),     -- File extension (.png) not needed here, converted to .tex on refresh
        camScale = 1,                                        -- Sets the camera scale of your character in the CS menu

        graffiti = get_texture_info("badeline_violet_icon"),

        palettes = {
            {
                name     = "Default",
                [PANTS]  = '401932',
                [SHIRT]  = '9760AA',
                [GLOVES] = 'EDD3CA',
                [SHOES]  = '4B2146',
                [HAIR]   = 'EF77DC',
                [SKIN]   = 'EDD3CA',
                [CAP]    = 'AF2138',
                [EMBLEM] = 'FFFFFF'
            },
            {
                name    = "Part Of Her",
                [PANTS] = '45283C',
                [SHIRT] = '639BFF',
                [GLOVES] = 'DF7126',
                [SHOES] = 'DF7126',
                [HAIR] = '3F3F74',
                [SHOES] = 'DF7126',
                [SKIN] = 'D9A066',
                [CAP] = '3F3F74',
                [EMBLEM] = '3F3F74'
            },
            {
                name    = "Ex",
                [PANTS] = '4B1F58',
                [SHIRT] = '286A75',
                [GLOVES] = 'D69F3E',
                [SHOES] = '000000',
                [HAIR] = '0B3D41',
                [SHOES] = '000000',
                [SKIN] = 'D69F3E',
                [CAP] = '47DD7D',
                [EMBLEM] = '47DD7D'
            }
        },

        voices = {
            [CHAR_SOUND_OKEY_DOKEY] =         'BadelineOkeyDokie.ogg', -- Starting game
        	[CHAR_SOUND_LETS_A_GO] =          'BadelineLetsAGo.ogg', -- Starting level
        	[CHAR_SOUND_PUNCH_YAH] =          'BadelineYah.ogg', -- Punch 1
        	[CHAR_SOUND_PUNCH_WAH] =          'BadelineWah.ogg', -- Punch 2
        	[CHAR_SOUND_PUNCH_HOO] =          'BadelineHoo.ogg', -- Punch 3
        	[CHAR_SOUND_YAH_WAH_HOO] =       {'BadelineWah.ogg', 'BadelineYah.ogg', 'BadelineHoo.ogg'}, -- First Jump Sounds
        	[CHAR_SOUND_HOOHOO] =             'BadelineHoohoo.ogg', -- Second jump sound
        	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'BadelineYahoo.ogg'}, -- Triple jump sounds
			[CHAR_SOUND_UH] =                 'BadelineUh.ogg', -- Wall bonk
			[CHAR_SOUND_UH2] =                'BadelineUh.ogg', -- Landing after long jump
			[CHAR_SOUND_UH2_2] =              'BadelineUh.ogg',
        	[CHAR_SOUND_DOH] =                'BadelineDoh.ogg', -- Hard wall bonk
        	[CHAR_SOUND_OOOF] =               'BadelineOoof.ogg', -- Attacked in air
        	[CHAR_SOUND_OOOF2] =              'BadelineOoof.ogg', -- Land from hard bonk
        	[CHAR_SOUND_HAHA] =               'BadelineHaha.ogg', -- Landing triple jump
        	[CHAR_SOUND_HAHA_2] =             'BadelineHaha.ogg', -- Landing in water from big fall
        	[CHAR_SOUND_YAHOO] =              'BadelineYahoo.ogg', -- Long jump
        	[CHAR_SOUND_WHOA] =               'BadelineWhoa.ogg', -- Grabbing ledge
        	[CHAR_SOUND_EEUH] =               'BadelineEeuh.ogg', -- Climbing over ledge
        	[CHAR_SOUND_WAAAOOOW] =           'BadelineFalling.ogg', -- Falling a long distance
        	[CHAR_SOUND_TWIRL_BOUNCE] =       'BadelineBoing.ogg', -- Bouncing off of a flower spring
        	[CHAR_SOUND_GROUND_POUND_WAH] =   'BadelineWah.ogg', -- Ground Pound after startup
        	[CHAR_SOUND_WAH2] =               'BadelineWah.ogg', -- Throwing something
        	[CHAR_SOUND_HRMM] =               'BadelineHrmm.ogg', -- Lifting something
        	[CHAR_SOUND_HERE_WE_GO] =         'BadelineHereWeGo.ogg', -- Star get
        	[CHAR_SOUND_SO_LONGA_BOWSER] =    'BadelineBowser.ogg', -- Throwing Bowser
        --DAMAGE
        	[CHAR_SOUND_ATTACKED] =     'BadelineDamaged.ogg', -- Damaged
        	[CHAR_SOUND_PANTING] =      'BadelinePanting.ogg', -- Low health
        	[CHAR_SOUND_PANTING_COLD] = 'BadelinePanting.ogg', -- Getting cold
        	[CHAR_SOUND_ON_FIRE] =      'BadelineBurning.ogg', -- Burned
        --SLEEP SOUNDS
        	[CHAR_SOUND_IMA_TIRED] = 'BadelineTired.ogg', -- Mario feeling tired
        	[CHAR_SOUND_YAWNING] =   'BadelineYawn.ogg', -- Mario yawning before he sits down to sleep
        	[CHAR_SOUND_SNORING1] =  'BadelineSnore1.ogg', -- Snore Inhale
        	[CHAR_SOUND_SNORING2] =  'BadelineSnore2.ogg', -- Exhale
        --COUGHING (USED IN THE GAS MAZE)
			[CHAR_SOUND_COUGHING3] = 'BadelineCough1.ogg', -- Cough take 1
			[CHAR_SOUND_COUGHING3] = 'BadelineCough2.ogg', -- Cough take 2
        	[CHAR_SOUND_COUGHING3] = 'BadelineCough3.ogg', -- Cough take 3
        --DEATH
        	[CHAR_SOUND_DYING] =    'BadelineDead.ogg', -- Dying from damage
        	[CHAR_SOUND_DROWNING] = 'BadelineDrown.ogg', -- Running out of air underwater
        	[CHAR_SOUND_MAMA_MIA] = 'BadelineMamaMia.ogg' -- Booted out of level
        },
    },
}

-- This function loads and applies Character Data based on the table above, does not need to be touched
local CSloaded = false
local function on_character_select_load()
    for i, char in pairs(characterTable) do
        local _ENV = setmetatable(char, { __index = _G })
        tablePos = charSelect.character_add(name, description, credits, color, model, forceChar, lifeIcon, camScale)
        -- if caps then character_add_caps(model, caps) end
        if voices then charSelect.character_add_voice(model, voices) end
        if palettes then
            for i = 1, #palettes do
                charSelect.character_add_palette_preset(model, palettes[i], palettes[i].name)
            end
        end
        charSelect.character_set_category(tablePos, TEXT_PACK_NAME)
        charSelect.character_add_graffiti(tablePos, graffiti)

        if anims then charSelect.character_add_animations(model, anims, eyes, hands) end

        if meter then charSelect.character_add_health_meter(tablePos, meter) end
    end

    charSelect.credit_add(TEXT_PACK_NAME, "VioletSM64", "Pack Creator / Models")
    charSelect.credit_add(TEXT_PACK_NAME, "EmilyEmmi", "Celeste Moveset Code")
    charSelect.credit_add(TEXT_PACK_NAME, "MelissaMekrose", "Madeline/Badeline VA")
    charSelect.credit_add(TEXT_PACK_NAME, "Crystalika", "Strawberry Model")
    if celeste and (not celesteMadeline) and celeste.cs_setup_dash_settings then -- celeste moveset support
        local E_MODEL_DASH_PARTICLE = smlua_model_util_get_id("dashparticle_violet_geo")
        local E_MODEL_DASH_PARTICLE_HAIR = smlua_model_util_get_id("dashparticlehair_violet_geo")

        celeste.cs_setup_dash_settings(CT_MADELINE, E_MODEL_DASH_PARTICLE, E_MODEL_DASH_PARTICLE_HAIR, true)
        celeste.cs_setup_dash_settings(CT_BADELINE, E_MODEL_DASH_PARTICLE, E_MODEL_DASH_PARTICLE_HAIR, true)
    end
    CSloaded = true
end

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)

-- NEW: Set up moveset if Celeste Moveset isn't already on))
if not celesteOn then
	require("moveset/moveset")
    require("moveset/packet")
	require("moveset/z_api")
end