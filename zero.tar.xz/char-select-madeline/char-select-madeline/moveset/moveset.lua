-- Celeste moveset by EmilyEmmi
-- Modified to integrate Character Select functions

ACT_GROUND_DASH = allocate_mario_action(ACT_GROUP_MOVING | ACT_FLAG_MOVING | ACT_FLAG_ATTACKING)
ACT_AIR_DASH = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ATTACKING)
ACT_WATER_DASH = allocate_mario_action(ACT_GROUP_SUBMERGED | ACT_FLAG_SWIMMING | ACT_FLAG_SWIMMING_OR_FLYING |
  ACT_FLAG_WATER_OR_TEXT | ACT_FLAG_ATTACKING)
ACT_METAL_WATER_DASH = allocate_mario_action(ACT_GROUP_SUBMERGED | ACT_FLAG_METAL_WATER | ACT_FLAG_WATER_OR_TEXT |
  ACT_FLAG_ATTACKING)
ACT_METAL_GROUND_WATER_DASH = allocate_mario_action(ACT_GROUP_SUBMERGED | ACT_FLAG_METAL_WATER | ACT_FLAG_WATER_OR_TEXT |
  ACT_FLAG_ATTACKING)
ACT_WALL_SLIDE = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_MOVING |
  ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION | ACT_FLAG_SHORT_HITBOX)
ACT_WALL_CLIMB = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_MOVING |
  ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION | ACT_FLAG_SHORT_HITBOX)
ACT_PICKING_UP_STALL = allocate_mario_action(ACT_GROUP_OBJECT | ACT_FLAG_STATIONARY | ACT_FLAG_INTANGIBLE | ACT_FLAG_AIR)
ACT_THROWING_CUSTOM = allocate_mario_action(ACT_FLAG_MOVING | ACT_FLAG_THROWING)
ACT_AIR_THROW_CUSTOM = allocate_mario_action(ACT_FLAG_AIR | ACT_FLAG_ALLOW_VERTICAL_WIND_ACTION | ACT_FLAG_CONTROL_JUMP_HEIGHT | ACT_FLAG_THROWING)
ACT_CUSTOM_TURN = allocate_mario_action(ACT_GROUP_MOVING | ACT_FLAG_MOVING)

E_MODEL_DASH_PARTICLE = smlua_model_util_get_id("dashparticle_violet_geo")
E_MODEL_DASH_PARTICLE_HAIR = smlua_model_util_get_id("dashparticlehair_violet_geo")
E_MODEL_DASH_RING = smlua_model_util_get_id("dashring_geo")

DASH_COUNT = 1             -- how many dashes can be done
DASH_TIMER_MAX = 10        -- how many frames the dash lasts
DASH_COOLDOWN = 12         -- how many frames after dashing until another dash may be performed
REFILL_DELAY = 6           -- how many frames after dashing until the dash may be refilled
DASH_ATTACK_ADD = 2        -- how many extra frames after the dash a wallbounce can be performed
DASH_BUNNY_ADD = 4         -- how many extra frames after the dash a bunny hop can be performed (only for hypers)
DAMP_RATE = 0.95           -- how much velocity is lost each frame during dash dampening (exponential decay)
DAMP_START = 4             -- what frame dash dampening starts at (also allows for adjustment)
DASH_DOWN_LENIENCY = 3     -- how many frames you can press Z or D-DPad at the start of a dash to switch to a downward dash
ORTHO_VELOCITY = 70        -- dash velocity when traveling orthogonally (1 direction)
DIAG_VELOCITY = 50         -- dash velocity when traveling diagonally (2 directions; should be about ORTHO_VELOCITY * sqrt(2))
ORTHO_VELOCITY_END = 51    -- velocity when an orthogonal dash ends (demos maintain speed). Should be equal to around ORTHO_VELOCITY*DAMP_RATE^(DAMP_TIMER_MAX - DAMP_START)
DIAG_VELOCITY_END = 37     -- velocity when an diagonal dash ends (demos maintain speed). Should be equal to around DIAG_VELOCITY*DAMP_RATE^(DAMP_TIMER_MAX - DAMP_START)
HYPER_DAMP = 0.7           -- how much jump is reduced during a hyper
SUPER_VELOCITY = 60        -- the horizontal velocity set during a super
HYPER_VELOCITY = 80        -- the horizontal velocity set during a hyper
MAX_AIR_SPEED = 50         -- cap for air speed after a dash
ULTRA_MULTIPLIER = 1.2     -- mario's horizontal velocity is multiplied by this after landing from a diagonal downward dash (allows for ultras to be performed)
TURN_AROUND_LENIENCY = 3   -- extra frames to perform a skid jump after turning around
LONG_DASH_ADD = 0          -- how much velocity is added during a Long Jump Super/Hyper
WALLBOUNCE_COYOTE_TIME = 1 -- how many frames after touching a wall that a wall bounce may be performed
COYOTE_TIME = 3            -- frames that one may jump in midair after walking off a ledge
BUFFER_JUMP_TIME = 3       -- frames for buffering a jump
REGRAB_DELAY = 5           -- frames after dropping an object we can regrab
DASH_COLOR_MAX = 5         -- max frames for the dash color to take effect (for color lerping)
MAX_STAMINA = 3300         -- stamina for climbing; staying still subtracts 10 per frame, and climbing and jumping subtract more
HAIR_STYLE = true          -- change the hair color instead of the shirt/cap/overalls color, like in actual celeste (ALWAYS TRUE IN THIS VERSION)
CEL64_LIKE_DASH = false    -- air dash has some vertical momentum by default, all dash jumps are hypers, can't dash up/down, can't reverse
RELATIVE_CLIMB = false     -- climb towards wall to go up
RENDER_BAR = false         -- renders stamina bar on hud
USE_CRAWL_ANIM = true      -- uses the crawling animation for climbing instead of pole stuff; not toggleable in-game
DEBUG_ENABLED = false      -- unlocks all strawberries, among other things

-- loads the player's current colors into this table
local USED_PARTS = { SHIRT, PANTS, CAP, SKIN, HAIR }
function setup_palette(index)
  local np = gNetworkPlayers[index]
  if not np then return end
  local body = {}
  for i, part in ipairs(USED_PARTS) do
    local color = network_player_get_override_palette_color(np, part)
    body[part] = color
  end
  return body
end

gGlobalSyncTable.dashCount = DASH_COUNT
gGlobalSyncTable.infStamina = false
gGlobalSyncTable.superDash = false
gGlobalSyncTable.allowNeutral = false
gGlobalSyncTable.nerfMoveset = true

function reset_celeste_fields(index)
  local c = gCelesteStates[index]
  c.dashColorTimer = 0
  c.whiteColorTimer = 0
  c.dashes = gGlobalSyncTable.dashCount or 1
  c.vertDash = false
  c.dashTimer = 0
  c.refillTimer = 0
  c.dashCooldown = 0
  c.dashAttackTimer = 0
  c.bunnyHopTimer = 0
  c.demoDash = false
  c.jumpCount = 0
  c.coyoteTime = 0
  c.wallbounceCoyote = 0
  c.stamina = MAX_STAMINA
  c.holdAwayFromWallTime = 0
  c.flashTimer = 0
  c.bunnyHop = false
  c.jumpFromDash = false
  c.velXBeforeGroundPound = 0
  c.actionTimer = 0
  c.prevActionTimer = 0
  c.climbYaw = 0.1
  c.climbXMultiplier = 1
  c.alreadyBufferedA = false
  c.alreadyBufferedB = false
  c.dashBuffer = 0
  c.regrabDelay = 0
  c.turnAroundLeniency = 0
  c.spawnRingTimer = 0
  c.coyoteWasOnSlide = false
  c.lastPlayedSound = ""
  c.lastPlayedVolume = 0
  c.lastPlayedRepeat = 0
  c.validForPlaySound = (index == 0)
end

gCelesteStates = {}
for i = 0, (MAX_PLAYERS - 1) do
  gCelesteStates[i] = {}
  local c = gCelesteStates[i]
  c.defaultColor = setup_palette(i)
  c.baseColor = setup_palette(i)
  c.currColor = setup_palette(i)
  c.noDashColor = setup_palette(i)
  c.twoDashColor = setup_palette(i)
  c.updateDashColors = true
  c.hairStyle = HAIR_STYLE
  c.fragmentDash = CEL64_LIKE_DASH
  c.relClimb = RELATIVE_CLIMB
  c.allowBufferJump = true
  c.allowCoyoteTime = true
  c.movesetDisabled = false
  c.dashBind = 0
  reset_celeste_fields(i)
end

sfx = {
  dash = (audio_sample_load("dash.mp3")),
  super = (audio_sample_load("super.mp3")),
  hyper = (audio_sample_load("hyper.mp3")),
  wallbounce = (audio_sample_load("wallbounce.mp3")),
  skidJump = (audio_sample_load("skidJump.mp3")),
  -- Unused, since the strawberry campaign is unimplemented
  --[[strawbGet = (audio_sample_load("strawbGet.mp3")),
  strawbGetGold = (audio_sample_load("strawbGetGold.mp3")),
  strawbGetMoon = (audio_sample_load("strawbGetMoon.mp3")),]]
}

-- check for faster swimming
local fast_swim = 1
for i, mod in ipairs(gActiveMods) do
  if mod.name == "Faster Swimming" then
    print("Faster Swimming detected!")
    fast_swim = 0.5
    break
  end
end

-- Utility function to check if the celeste moveset should be enabled
function celeste_moveset_enabled(index)
  local charNum = charSelect.character_get_current_number(index)
  return (charSelect.gCSPlayers[index].movesetToggle) and (charNum == CT_MADELINE or charNum == CT_BADELINE)
end

-- Hooks moveset function to both Madeline and Badeline
function hook_celeste_moveset(hookEventType, func)
  if CT_MADELINE == nil or CT_BADELINE == nil then return end
  charSelect.character_hook_moveset(CT_MADELINE, hookEventType, func)
  charSelect.character_hook_moveset(CT_BADELINE, hookEventType, func)
end

function display_controls(msg)
  local c = gCelesteStates[0]

  if msg and msg:lower() == "climb" then
    djui_chat_message_create("CLIMBING CONTROLS:")
    if c.relClimb then
      djui_chat_message_create("Hold B to grab walls and hold towards it to climb up")
      djui_chat_message_create("Climb down by holding away and press A to jump up.")
    else
      djui_chat_message_create("Hold B to grab walls and hold up to climb up.")
      djui_chat_message_create("Climb down by holding down and press A to jump up.")
    end
    djui_chat_message_create("TIP: Jumping or climbing up uses more stamina than climbing sideways/down.")
  else
    local dashKeyString = "X"
    if c.dashBind == 1 then
      dashKeyString = "Y"
    elseif c.dashBind == 2 then
      dashKeyString = "L"
    end

    djui_chat_message_create("DASH CONTROLS:")
    djui_chat_message_create("Press "..dashKeyString.." to dash in the joystick's direction.")
    if c.fragmentDash then
      djui_chat_message_create("You will go slightly up when dashing in midair.")
    else
      djui_chat_message_create("Hold A or U-DPAD while dashing for an upward angle.")
      djui_chat_message_create("Hold Z or D-DPAD while dashing for a downward angle.")
      djui_chat_message_create("Hold no direction to dash straight forward, up, or down.")
    end
    if gGlobalSyncTable.nerfMoveset then
      djui_chat_message_create("You can jump or kick from a grounded dash. Fly with the wing cap by crouching, then dash jumping.")
    else
      djui_chat_message_create("You can jump or kick from a grounded dash, and dive from a midair dash.")
    end
    djui_chat_message_create("Dashes will also automatically grab objects.")
    djui_chat_message_create("Type \\#50ff50\\/cel_controls climb\\#dcdcdc\\ for climbing controls.")
    djui_chat_message_create("For advanced techniques, see the Celeste Wiki.")
  end
  return true
end

hook_chat_command("cel_controls", "[CLIMB] - Displays controls for the Celeste moveset", display_controls)

-- all dashing actions
dashAction = {
  [ACT_AIR_DASH] = 1,
  [ACT_GROUND_DASH] = 1,
  [ACT_WATER_DASH] = 1,
  [ACT_METAL_GROUND_WATER_DASH] = 1,
  [ACT_METAL_WATER_DASH] = 1,
}

-- can't dash or climb out of these actions
-- (note that all cutsccene/invulnerable actions are also banned)
dashBanned = {
  [ACT_BURNING_FALL] = 1,
  [ACT_BURNING_GROUND] = 1,
  [ACT_BURNING_JUMP] = 1,
  [ACT_LAVA_BOOST] = 1,
  [ACT_DEATH_EXIT_LAND] = 1,
}

--[[landing_actions = {
  [ACT_JUMP_LAND] = 1,
  [ACT_FREEFALL_LAND] = 1,
  [ACT_SIDE_FLIP_LAND] = 1,
  [ACT_DOUBLE_JUMP_LAND] = 1,
  [ACT_TRIPLE_JUMP_LAND] = 1,
  [ACT_BEGIN_SLIDING] = 1,
  [ACT_HOLD_JUMP_LAND] = 1,
  [ACT_HOLD_FREEFALL_LAND] = 1,
  [ACT_BACKFLIP_LAND] = 1,
  [ACT_QUICKSAND_JUMP_LAND] = 1,
  [ACT_HOLD_QUICKSAND_JUMP_LAND] = 1,
  [ACT_AIR_THROW_LAND] = 1,
  [ACT_LONG_JUMP_LAND] = 1,
  [ACT_DIVE_SLIDE] = 1,
}]]

local prevCelesteState = {}
local justThrownObject
function before_madeline_update(m)
  local c = gCelesteStates[m.playerIndex]

  -- handle custom sync states
  if m.playerIndex == 0 then
    local foundDifference = false
    local playerPacket = string.pack("<B", BYTE_PACKET_CEL_STATE)
    playerPacket = playerPacket .. string.pack("<B", network_global_index_from_local(0))

    for a,field in ipairs(SYNC_CEL_FIELDS) do
      local byteType = SYNC_CEL_FIELD_TYPE[field] or "<B"
      local value = c[field]
      if type(value) == "boolean" then
        value = (value and 1) or 0
      elseif type(value) == "number" and byteType ~= "<f" and byteType ~= "<d" then
        value = math.floor(value)
      elseif value == nil then
        value = 0
      end
      
      playerPacket = playerPacket .. string.pack(byteType, value)
      if prevCelesteState[field] ~= value then
        prevCelesteState[field] = value
        foundDifference = true
      end
    end

    if foundDifference or get_global_timer() % 5 == 0 then
      network_send_bytestring_to_all_in_area(false, playerPacket)
    end
  end

  -- buffer jump / rollout
  if c.allowBufferJump then
    if (c.alreadyBufferedA ~= (m.action & ACT_FLAG_AIR == 0)) and m.controller.buttonPressed & A_BUTTON ~= 0 then
      c.alreadyBufferedA = not c.alreadyBufferedA
    end
    if (c.alreadyBufferedB ~= (m.action & ACT_FLAG_AIR == 0)) and m.controller.buttonPressed & B_BUTTON ~= 0 then
      c.alreadyBufferedB = not c.alreadyBufferedB
    end

    if (m.playerIndex ~= 0 or not is_game_paused()) then
      if ((m.prevAction & ACT_FLAG_AIR) ~= 0 and ((m.action & ACT_FLAG_AIR) == 0)
            or (m.action & ACT_FLAG_METAL_WATER ~= 0 and m.prevAction & ACT_FLAG_METAL_WATER ~= 0 and m.pos.y == m.floorHeight)) then
        if (not c.alreadyBufferedA) and (m.framesSinceA < BUFFER_JUMP_TIME) then
          m.controller.buttonPressed = m.controller.buttonPressed | A_BUTTON
          m.controller.buttonDown = m.controller.buttonDown | A_BUTTON
          c.alreadyBufferedA = true
        end
        if (not c.alreadyBufferedB) and m.action & ACT_FLAG_METAL_WATER == 0 and (m.prevAction ~= ACT_DIVE or c.prevActionTimer > m.framesSinceB) and m.framesSinceB < BUFFER_JUMP_TIME then
          m.controller.buttonPressed = m.controller.buttonPressed | B_BUTTON
          m.controller.buttonDown = m.controller.buttonDown | B_BUTTON
          c.alreadyBufferedB = true
        end
      end
    end
  end

  -- allow jumping in long jump and triple jump land
  if (m.action == ACT_LONG_JUMP_LAND or m.action == ACT_LONG_JUMP_LAND_STOP or m.action == ACT_TRIPLE_JUMP_LAND or m.action == ACT_TRIPLE_JUMP_LAND_STOP) and m.controller.buttonPressed & A_BUTTON ~= 0 then
    if m.controller.buttonDown & Z_TRIG == 0 then
      set_jump_from_landing(m)
    elseif m.action ~= ACT_LONG_JUMP_LAND and m.action ~= ACT_LONG_JUMP_LAND_STOP then
      set_mario_action(m, ACT_LONG_JUMP, 0)
    end
  end
end

hook_event(HOOK_BEFORE_MARIO_UPDATE, before_madeline_update)

-- if the player presses A, the dash is attempted early (so that pressing Y+A together automatically dash jumps)
function attempt_early_dash(m)
  if m.controller.buttonPressed & A_BUTTON == 0 or m.input & INPUT_NONZERO_ANALOG == 0 then return end

  dash_handling(m)
end

-- checks if the player presses the dash key and can dash, and sets dash action if so
function dash_handling(m)
  local c = gCelesteStates[m.playerIndex]
  local DASH_KEY = X_BUTTON
  if c.dashBind == 1 then
    DASH_KEY = Y_BUTTON
  elseif c.dashBind == 2 then
    DASH_KEY = L_TRIG
  end

  if c.dashes > 0 and m.health > 0xFF and m.freeze == 0 and (c.dashCooldown == 0)
      and ((m.controller.buttonPressed & DASH_KEY) ~= 0 or c.dashBuffer ~= 0)
      and (m.action & (ACT_GROUP_CUTSCENE | ACT_FLAG_INTANGIBLE | ACT_FLAG_INVULNERABLE | ACT_FLAG_RIDING_SHELL)) == 0 and m.heldObj == nil
      and dashBanned[m.action] == nil then
    c.dashes = c.dashes - 1
    c.dashTimer = DASH_TIMER_MAX
    c.refillTimer = REFILL_DELAY
    c.dashCooldown = DASH_COOLDOWN
    if gGlobalSyncTable.superDash then
      c.dashTimer = c.dashTimer * 2
    end
    c.dashAttackTimer = c.dashTimer + DASH_ATTACK_ADD
    c.bunnyHopTimer = c.dashTimer + DASH_BUNNY_ADD
    c.dashBuffer = 0
    c.dashColorTimer = DASH_COLOR_MAX
    c.spawnRingTimer = 0

    local dashVelX, dashVelY = 0, 0
    if c.fragmentDash then
      if m.action & ACT_FLAG_AIR ~= 0 then
        dashVelY = 25
      else
        dashVelY = 0
      end
      dashVelX = ORTHO_VELOCITY
    elseif ((m.controller.buttonDown & Z_TRIG) ~= 0 and (m.controller.buttonDown & U_JPAD) == 0) or (m.controller.buttonDown & D_JPAD) ~= 0 then
      dashVelX = DIAG_VELOCITY
      dashVelY = -DIAG_VELOCITY
    elseif m.controller.buttonDown & (A_BUTTON | U_JPAD) ~= 0 then
      dashVelY = DIAG_VELOCITY
      dashVelX = DIAG_VELOCITY
    else
      dashVelY = 0
      dashVelX = ORTHO_VELOCITY
    end
    if (not c.fragmentDash) and (m.input & INPUT_NONZERO_ANALOG) == 0 and dashVelY ~= 0 then
      if dashVelY > 0 then
        dashVelY = ORTHO_VELOCITY
      else
        dashVelY = -ORTHO_VELOCITY
      end
      dashVelX = 0
    end

    -- store last wall to make wallbounces easier
    local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
    if m.wall ~= nil and (m.wall.type ~= SURFACE_BURNING) then
      c.wallbounceCoyote = WALLBOUNCE_COYOTE_TIME
      -- if holding towards wall or sliding, do upwards dash regardless of stick direction
      if dashVelY > 0 and abs_angle_diff(m.intendedYaw, wallYaw) > 0x6000 then
        dashVelX = 0
        dashVelY = ORTHO_VELOCITY
      end
    elseif c.wallbounceCoyote > 0 and m.action ~= ACT_AIR_DASH then
      c.wallbounceCoyote = c.wallbounceCoyote - 1
      -- if holding towards wall, do upwards dash regardless of stick direction
      if (not c.fragmentDash) and dashVelY > 0 and abs_angle_diff(m.intendedYaw, wallYaw) > 0x6000 then
        dashVelX = 0
        dashVelY = ORTHO_VELOCITY
      end
    end

    if (m.action & ACT_FLAG_SWIMMING) == 0 then
      m.faceAngle.y = m.intendedYaw
    else
      if dashVelX ~= 0 then
        dashVelY = 0
        dashVelX = ORTHO_VELOCITY
      end
      m.faceAngle.y = m.faceAngle.y - m.controller.stickX * 0x80
      m.faceAngle.x = clamp(m.faceAngle.x - m.controller.stickY * 0x50, -0x4000, 0x4000)
    end
    c.jumpFromDash = true
    c.jumpCount = 0

    if m.action == ACT_JUMP or m.action == ACT_WALL_KICK_AIR or m.action == ACT_JUMP_LAND
        or m.prevAction == ACT_JUMP or m.prevAction == ACT_WALL_KICK_AIR or m.prevAction == ACT_JUMP_LAND then
      c.jumpCount = 1
    elseif m.action == ACT_DOUBLE_JUMP or m.action == ACT_DOUBLE_JUMP_LAND
        or m.prevAction == ACT_DOUBLE_JUMP or m.prevAction == ACT_DOUBLE_JUMP_LAND then
      c.jumpCount = 2
    end

    -- demo dash
    if m.action == ACT_GROUND_POUND then
      c.demoDash = true
      m.forwardVel = c.velXBeforeGroundPound
    elseif dashVelY < 0 then
      c.demoDash = true
    else
      c.demoDash = false
    end

    -- mark vertical only dash (straight up/straight down)
    c.vertDash = (dashVelX == 0)

    if m.action & ACT_FLAG_METAL_WATER ~= 0 or (m.action & ACT_FLAG_SWIMMING ~= 0 and m.flags & MARIO_METAL_CAP ~= 0) then
      if dashVelY > 0 or (dashVelY < 0 and dashVelX == 0) or m.pos.y ~= m.floorHeight then
        set_mario_action(m, ACT_METAL_WATER_DASH, 0)
      else
        set_mario_action(m, ACT_METAL_GROUND_WATER_DASH, 0)
      end
    elseif m.action & ACT_FLAG_SWIMMING ~= 0 then
      set_mario_action(m, ACT_WATER_DASH, 0)
    elseif dashVelY > 0 or (dashVelY < 0 and dashVelX == 0) or (m.action & ACT_FLAG_AIR) ~= 0 then
      set_mario_action(m, ACT_AIR_DASH, 0)
    else
      if dashVelY < 0 then
        dashVelX = dashVelX * ULTRA_MULTIPLIER
        dashVelY = 0
      end
      set_mario_action(m, ACT_GROUND_DASH, 0)
    end

    -- maintain horizontal when doing dash (allows for ultra chains and such)
    local pos_vel = math.abs(m.forwardVel) -- dash out of blj for ludicrous speed
    if dashVelX ~= 0 and dashVelX < pos_vel then
      dashVelX = pos_vel
    end

    if m.action & ACT_FLAG_SWIMMING ~= 0 then
      m.forwardVel = dashVelX
      m.vel.x = (m.forwardVel * coss(m.faceAngle.x) * sins(m.faceAngle.y))
      m.vel.y = (dashVelX * sins(m.faceAngle.x) + dashVelY)
      m.vel.z = (m.forwardVel * coss(m.faceAngle.x) * coss(m.faceAngle.y))
    else
      mario_set_forward_vel(m, dashVelX)
      m.vel.y = dashVelY
    end

    -- fix camera
    if m.playerIndex == 0 and m.prevAction & ACT_FLAG_WATER_OR_TEXT == 0 and (m.area.camera.mode == CAMERA_MODE_WATER_SURFACE or m.area.camera.mode == CAMERA_MODE_BEHIND_MARIO) then
      set_camera_mode(m.area.camera, m.area.camera.defMode, 0)
    end

    -- sfx
    play_celeste_sound("dash", m)
  elseif c.allowBufferJump and (m.controller.buttonPressed & DASH_KEY) ~= 0 then
    c.dashBuffer = BUFFER_JUMP_TIME
  end
  c.dashBuffer = decrease_until_zero(c.dashBuffer)
end

-- refills dash+stamina and sets color fields
function refill_dash(index)
  local c = gCelesteStates[index]
  local maxDash = gGlobalSyncTable.dashCount
  if c.dashes < maxDash then
    c.dashes = maxDash
    c.whiteColorTimer = 2
    c.dashColorTimer = 0
  end
  c.stamina = MAX_STAMINA
end

local DEBUG_FIND_WALL = false
---@param m MarioState
function madeline_update(m)
  local c = gCelesteStates[m.playerIndex]

  local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)

  if (m.action == ACT_WALL_SLIDE or m.action == ACT_WALL_CLIMB) and USE_CRAWL_ANIM and (m.marioObj.header.gfx.animInfo.animID == MARIO_ANIM_CRAWLING) then
    m.marioObj.header.gfx.angle.x = m.marioObj.header.gfx.angle.x - 0x4000
    m.marioObj.header.gfx.pos.x = m.marioObj.header.gfx.pos.x + sins(m.marioObj.header.gfx.angle.y) * 50
    m.marioObj.header.gfx.pos.z = m.marioObj.header.gfx.pos.z + coss(m.marioObj.header.gfx.angle.y) * 50
  end

  if DEBUG_FIND_WALL then
    local col = collision_find_surface_on_ray(m.pos.x, m.pos.y, m.pos.z, sins(m.faceAngle.y) * 1000, 0,
      coss(m.faceAngle.y) * 1000)
    if surface_is_wall(col) then
      spawn_non_sync_object(id_bhvSparkleSpawn, E_MODEL_NONE, col.hitPos.x, col.hitPos.y, col.hitPos.z, nil)
    end
  end

  if gGlobalSyncTable.infStamina then
    c.stamina = 3300 -- MAX_STAMINA isn't used on the off chance we want to make it really low
  end

  if not celeste_moveset_enabled(m.playerIndex) then
    -- prevent using this to keep speed
    if c.jumpFromDash then
      c.jumpFromDash = false
      m.forwardVel = MAX_AIR_SPEED
    end
    c.actionTimer = 0
    c.prevActionTimer = 0
    c.coyoteTime = 0
    c.coyoteWasOnSlide = true
    c.refillTimer = 0
    c.dashTimer = 0
    if c.dashes > gGlobalSyncTable.dashCount then
      c.dashes = gGlobalSyncTable.dashCount
    end

    -- refill dash
    if (((m.action & ACT_FLAG_AIR) == 0 and m.action & ACT_GROUP_MASK ~= ACT_GROUP_AIRBORNE and (m.input & INPUT_ABOVE_SLIDE) == 0) or (m.action & ACT_FLAG_ON_POLE) ~= 0 or m.action & ACT_GROUP_MASK == ACT_GROUP_CUTSCENE) and ((m.action & ACT_FLAG_METAL_WATER | ACT_FLAG_SWIMMING) == 0 or m.flags & MARIO_METAL_CAP == 0 or m.pos.y == m.floorHeight) and c.refillTimer <= 0 then
      refill_dash(m.playerIndex)
    end

    goto PALETTE
  end

  -- reset jump from dash state (disables air drag)
  if (m.prevAction & ACT_FLAG_AIR == 0) and (m.action & ACT_FLAG_AIR) == 0 and ((m.action & ACT_FLAG_METAL_WATER) == 0 or m.pos.y == m.floorHeight) then
    c.jumpFromDash = false
    c.spawnRingTimer = 0
  end
  if c.actionTimer < 255 then
    c.actionTimer = c.actionTimer + 1
  end

  dash_handling(m)

  -- timers
  c.refillTimer = decrease_until_zero(c.refillTimer)
  c.dashCooldown = decrease_until_zero(c.dashCooldown)
  c.dashAttackTimer = decrease_until_zero(c.dashAttackTimer)
  c.bunnyHopTimer = decrease_until_zero(c.bunnyHopTimer)
  c.dashTimer = decrease_until_zero(c.dashTimer)
  c.spawnRingTimer = decrease_until_zero(c.spawnRingTimer)
  c.regrabDelay = decrease_until_zero(c.regrabDelay)

  -- dash and dash jump particles
  if (m.playerIndex == 0 or is_player_active(m) ~= 0) and m.marioObj.header.gfx.node.flags & GRAPH_RENDER_ACTIVE ~= 0 then
    if dashAction[m.action] then
      if (DASH_TIMER_MAX - c.dashTimer) % 3 == 0 and (REFILL_DELAY - c.refillTimer) > 1 then
        local model = (c.hairStyle and E_MODEL_DASH_PARTICLE_HAIR) or E_MODEL_DASH_PARTICLE
        spawn_non_sync_object(id_bhvDashParticle, model, m.pos.x, m.pos.y, m.pos.z,
          function(o) o.globalPlayerIndex = network_global_index_from_local(m.playerIndex) end)
      end
    elseif m.action & ACT_FLAG_AIR ~= 0 and c.spawnRingTimer ~= 0 and c.spawnRingTimer % 10 == 1 and m.forwardVel > 10 and m.action ~= ACT_WALL_SLIDE and m.action ~= ACT_WALL_CLIMB then
      spawn_non_sync_object(id_bhvRingParticle, E_MODEL_DASH_RING, m.pos.x, m.pos.y + 80, m.pos.z,
        function(o) o.globalPlayerIndex = network_global_index_from_local(m.playerIndex) end)
    end
  end

  -- refill dash
  if (((m.action & ACT_FLAG_AIR) == 0 and m.action & ACT_GROUP_MASK ~= ACT_GROUP_AIRBORNE and (m.input & INPUT_ABOVE_SLIDE) == 0) or (m.action & ACT_FLAG_ON_POLE) ~= 0 or m.action & ACT_GROUP_MASK == ACT_GROUP_CUTSCENE or (c.coyoteTime ~= 0 and not c.coyoteWasOnSlide)) and ((m.action & ACT_FLAG_METAL_WATER | ACT_FLAG_SWIMMING) == 0 or m.flags & MARIO_METAL_CAP == 0 or m.pos.y == m.floorHeight) and c.refillTimer <= 0 then
    refill_dash(m.playerIndex)
  end

  -- wallbounce
  if ((m.input & INPUT_A_PRESSED) ~= 0 or m.action == ACT_WALL_KICK_AIR) and m.action & ACT_FLAG_AIR ~= 0 and c.dashAttackTimer ~= 0 and c.vertDash and (m.action & ACT_FLAG_INVULNERABLE == 0 or m.wallKickTimer ~= 0) then
    local valid = true
    if m.wall == nil and c.wallbounceCoyote <= 0 then
      -- check if we're close enough to a wall
      local raydist = 100
      local pos = { m.pos.x, m.pos.y, m.pos.z }
      local forwardPos = { sins(m.faceAngle.y) * raydist, coss(m.faceAngle.y) * raydist }
      local col = collision_find_surface_on_ray(pos[1], pos[2], pos[3], forwardPos[1], 0, forwardPos[2])
      if col and surface_is_wall(col) and col.surface.type ~= SURFACE_BURNING and col.surface.type ~= SURFACE_CAMERA_BOUNDARY and col.surface.type ~= SURFACE_RAYCAST and (col.surface.type ~= SURFACE_VANISH_CAP_WALLS or m.flags & MARIO_VANISH_CAP == 0) then
        m.wall = col.surface
        m.wallNormal.x = col.surface.normal.x
        m.wallNormal.z = col.surface.normal.z
      else
        valid = false
      end
    end

    if valid then
      -- sfx
      play_celeste_sound("wallbounce", m)
      
      m.faceAngle.y = atan2s(m.wallNormal.z, m.wallNormal.x) -- the mario object conveniently stores the last wall's normal
      if m.action ~= ACT_WALL_KICK_AIR then
        set_mario_action(m, ACT_WALL_KICK_AIR, 0)
      end
      m.vel.y = ORTHO_VELOCITY + 15
      c.vertDash = false
      c.spawnRingTimer = 10
      return
    end
  end

  -- skid jump leniency
  if c.turnAroundLeniency ~= 0 then
    c.turnAroundLeniency = c.turnAroundLeniency - 1
  end

  if ((m.action & ACT_FLAG_AIR) ~= 0 or (m.action & ACT_FLAG_METAL_WATER ~= 0 and m.pos.y ~= m.floorHeight)) and (m.action & (ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_INTANGIBLE | ACT_FLAG_INVULNERABLE)) == 0 and (m.prevAction & ACT_FLAG_HANGING) == 0 and (m.action ~= ACT_SHOT_FROM_CANNON) and m.action & ACT_GROUP_MASK ~= ACT_GROUP_CUTSCENE then
    -- coyote time
    if m.vel.y > 0 then
      c.coyoteTime = 0
    elseif c.coyoteTime > 0 then
      if m.input & INPUT_A_PRESSED ~= 0 and m.prevAction & (ACT_FLAG_AIR | ACT_FLAG_DIVING) == 0 and c.allowCoyoteTime then
        if m.heldObj ~= nil then
          set_mario_action(m, ACT_HOLD_JUMP, 0)
        elseif m.action & ACT_FLAG_RIDING_SHELL ~= 0 then
          set_mario_action(m, ACT_RIDING_SHELL_JUMP, 0)
        elseif m.input & INPUT_Z_DOWN ~= 0 and m.prevAction & ACT_FLAG_BUTT_OR_STOMACH_SLIDE == 0 then
          set_mario_action(m, ACT_LONG_JUMP, 0)
        else
          set_jump_from_landing(m)
        end
      end
      c.coyoteTime = c.coyoteTime - 1
    end

    -- air drag like in celeste (only out of dash or when holding no direction)
    if (m.action ~= ACT_AIR_DASH and m.action ~= ACT_WALL_CLIMB and m.action ~= ACT_BACKFLIP and m.action ~= ACT_WALL_SLIDE) and c.jumpFromDash then
      local approachVel = MAX_AIR_SPEED
      if m.input & INPUT_NONZERO_ANALOG == 0 then
        approachVel = 0
      elseif m.action ~= ACT_LONG_JUMP and m.action ~= ACT_DIVE and not c.demoDash then
        approachVel = approachVel - 10 -- supers have a lower cap (but not when diving or long jumping since those already go 50ish by default)
      end
      if (approachVel == 0 and m.action ~= ACT_LONG_JUMP) or (m.forwardVel > approachVel) then
        mario_set_forward_vel(m, approach_s32(m.forwardVel, approachVel, 1, 1))
      end

      -- higher gravity to make bhops easier
      if c.dashTimer ~= 0 and m.input & INPUT_A_DOWN == 0 and c.demoDash and not c.fragmentDash then
        m.vel.y = m.vel.y - 4
      end
    end
  elseif (m.action & ACT_FLAG_AIR) == 0 then
    c.coyoteTime = COYOTE_TIME
    c.coyoteWasOnSlide = (m.input & INPUT_ABOVE_SLIDE ~= 0)
  end

  -- decelerate faster
  if m.action == ACT_DECELERATING or m.action == ACT_HOLD_DECELERATING then
    m.forwardVel = approach_f32(m.forwardVel, 0, 2, 2)
  end

  -- cancel climb jump or same wall kick
  if (m.action == ACT_WALL_KICK_AIR or m.action == ACT_JUMP or m.action == ACT_HOLD_JUMP) and m.actionArg == 1 then
    if m.actionTimer > 5 then
      m.usedObj = nil -- allow grabbing same pole after neutral jump
    elseif (m.input & INPUT_NONZERO_ANALOG) ~= 0 and abs_angle_diff(m.intendedYaw, wallYaw) < 0x2000 then
      m.actionArg = 2
      m.faceAngle.y = m.faceAngle.y + 0x8000
      m.forwardVel = -m.forwardVel
      if m.action == ACT_JUMP then
        m.actionArg = 1
        local prevY = m.vel.y
        set_mario_action(m, ACT_WALL_KICK_AIR, 0)
        m.vel.y = prevY + 20 -- regular jump is 42 by default, wall kick is 62.
        m.flags = m.flags | MARIO_MARIO_SOUND_PLAYED
        c.stamina = c.stamina + 703 -- refund stamina from jump
      end
    end
    m.actionTimer = m.actionTimer + 1
  end

  -- turn during wall kick
  if m.action == ACT_WALL_KICK_AIR or (m.action == ACT_HOLD_JUMP and m.actionArg ~= 0) then
    m.faceAngle.y = approach_s16_symmetric(m.faceAngle.y, m.intendedYaw, 0x100)
  end

  -- Adjust camera for wall climb
  if m.playerIndex == 0 and m.action == ACT_WALL_CLIMB then
    m.statusForCamera.action = m.statusForCamera.action | ACT_FLAG_ON_POLE
    m.statusForCamera.pos.y = m.statusForCamera.pos.y + math.max(m.vel.y * 12, 0)
  end

  -- make wall sliding occur as long as you are reasonably facing + holding towards a wall with a low y velocity
  if dashBanned[m.action] == nil and (m.action & ACT_FLAG_AIR) ~= 0 and (m.action & ACT_FLAG_RIDING_SHELL == 0) and (m.action ~= ACT_AIR_DASH) and m.action ~= ACT_WALL_SLIDE and m.action ~= ACT_WALL_CLIMB and (m.action == ACT_WALL_KICK_AIR or m.prevAction ~= ACT_WALL_SLIDE)
      and m.wall ~= nil and abs_angle_diff(m.faceAngle.y, wallYaw) > 0x4000 and abs_angle_diff(m.intendedYaw, wallYaw) > 0x6000 and (m.input & INPUT_NONZERO_ANALOG) ~= 0 and (m.vel.y <= 10 or (m.action == ACT_JUMP_KICK and m.controller.buttonDown & B_BUTTON ~= 0))
      and (m.action ~= ACT_JUMP or m.actionArg ~= 1 or m.vel.y <= 5) then
    if not m.heldObj then
      m.faceAngle.y = limit_angle(wallYaw + 0x8000)
      set_mario_action(m, ACT_WALL_SLIDE, 0)
    else
      m.wallKickTimer = 5
    end
  end

  -- holding wall kick
  if (m.action == ACT_HOLD_JUMP or m.action == ACT_HOLD_FREEFALL) and m.input & INPUT_A_PRESSED ~= 0 and m.wallKickTimer ~= 0 and c.actionTimer > 1 then
    if m.forwardVel < 20.0 then
      m.forwardVel = 20.0
    end
    local arg = 2
    if (m.input & INPUT_NONZERO_ANALOG) ~= 0 then
      m.faceAngle.y = m.faceAngle.y + 0x8000
    else
      m.forwardVel = -m.forwardVel
      arg = 1
    end
    m.wallKickTimer = 0
    set_mario_action(m, ACT_HOLD_JUMP, arg)
    m.vel.y = 52
  end

  -- crouch dash/bunny hop actually affect hitbox
  if c.demoDash and (c.bunnyHop or dashAction[m.action]) then
    m.bounceSquishTimer = 1
    m.marioObj.hitboxHeight = 80
  end

  ::PALETTE::

  -- update the default color
  local np = gNetworkPlayers[m.playerIndex]
  if not np.connected then return end
  for i, part in ipairs(USED_PARTS) do
    local actualColor = network_player_get_palette_color(np, part)
    if not compare_color(actualColor, c.defaultColor[part]) then
      c.defaultColor[part] = actualColor
      c.baseColor[part] = actualColor
      network_player_reset_override_palette(np)
    end
  end

  -- update the base color
  for i, part in ipairs(USED_PARTS) do
    local actualColor = network_player_get_override_palette_color(np, part)
    if not compare_color(actualColor, c.currColor[part]) then
      c.baseColor[part] = actualColor
      c.updateDashColors = true
    end
    c.currColor[part] = c.baseColor[part]
  end

  -- set up dash colors
  if c.updateDashColors then
    c.updateDashColors = false
    local pink = { r = 240, g = 140, b = 236 }       -- default two dash color
    local lightGreen = { r = 80, g = 240, b = 80 }   -- alt two dash color
    local magenta = { r = 0xFC, g = 0x02, b = 0x51 } -- second two dash color alt (if the player is already using both pink and dark green)
    local lightBlue = { r = 128, g = 212, b = 252 }  -- default no dash color
    local darkBlue = { r = 0, g = 0, b = 255 }       -- alt no dash color
    if c.hairStyle then
      c.noDashColor[HAIR] = pick_color_or_alt_if_similar(c.baseColor[HAIR], lightBlue, darkBlue)
      c.twoDashColor[HAIR] = pick_color_or_alt_if_similar(c.baseColor[HAIR], pink, lightGreen)
    else
      for i, part in ipairs(USED_PARTS) do
        if part == SHIRT or part == CAP then
          c.noDashColor[part] = pick_color_or_alt_if_similar_x2(c.baseColor[part], c.baseColor[PANTS], lightBlue,
            darkBlue)
        elseif part == PANTS then
          c.noDashColor[part] = pick_color_or_alt_if_similar_x2(c.baseColor[part], c.baseColor[SHIRT], lightBlue,
            darkBlue)
        end
        if part ~= HAIR and part ~= SKIN then
          c.twoDashColor[part] = pick_color_or_alt_if_either_are_similar_x2(c.baseColor[part], c.noDashColor[part], pink,
            lightGreen, magenta)
        end
      end
    end
  end

  -- dash and recharge color
  local visualDash = c.dashes
  if not celeste_moveset_enabled(m.playerIndex) then
    visualDash = 1
  end
  if c.whiteColorTimer ~= 0 then -- white color
    if c.hairStyle then
      c.currColor[HAIR] = { r = 255, g = 255, b = 255 }
    else
      c.currColor[SHIRT] = { r = 255, g = 255, b = 255 }
      c.currColor[PANTS] = { r = 255, g = 255, b = 255 }
      c.currColor[CAP] = { r = 255, g = 255, b = 255 }
    end
    c.whiteColorTimer = c.whiteColorTimer - 1
  elseif visualDash ~= 1 or c.dashColorTimer ~= 0 then
    if visualDash == 0 then
      if c.hairStyle then -- lerp from no dash color (usually light blue)
        c.currColor[HAIR] = lerp_color(c.baseColor[HAIR], c.noDashColor[HAIR],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
      else -- lerp from no dash color (usually swapping shirt/cap and pants)
        c.currColor[SHIRT] = lerp_color(c.baseColor[SHIRT], c.noDashColor[SHIRT],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
        c.currColor[CAP] = lerp_color(c.baseColor[CAP], c.noDashColor[CAP],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
        c.currColor[PANTS] = lerp_color(c.baseColor[PANTS], c.noDashColor[PANTS],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
      end
    elseif visualDash == 1 then -- lerp from pink / green
      if c.hairStyle then
        c.currColor[HAIR] = lerp_color(c.twoDashColor[HAIR], c.baseColor[HAIR],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
      else
        c.currColor[SHIRT] = lerp_color(c.twoDashColor[SHIRT], c.baseColor[SHIRT],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
        c.currColor[CAP] = lerp_color(c.twoDashColor[CAP], c.baseColor[CAP],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
        c.currColor[PANTS] = lerp_color(c.twoDashColor[PANTS], c.baseColor[PANTS],
          (DASH_COLOR_MAX - c.dashColorTimer) / DASH_COLOR_MAX)
      end
    else -- just pink / green
      if c.hairStyle then
        c.currColor[HAIR] = c.twoDashColor[HAIR]
      else
        c.currColor[SHIRT] = c.twoDashColor[SHIRT]
        c.currColor[CAP] = c.twoDashColor[CAP]
        c.currColor[PANTS] = c.twoDashColor[PANTS]
      end
    end
  end
  if c.dashColorTimer ~= 0 then
    c.dashColorTimer = c.dashColorTimer - 1
  end

  -- make metal color match hair color (this does mean that the default metal color ends up being different but oh well)
  if c.hairStyle and m.marioBodyState.modelState & MODEL_STATE_METAL ~= 0 then
    c.currColor[METAL] = c.currColor[HAIR]
  end

  -- flash when low stamina
  if c.stamina < 600 then
    local flashPart = SKIN
    if m.marioBodyState.modelState & MODEL_STATE_METAL ~= 0 then
      flashPart = METAL
    end

    c.flashTimer = c.flashTimer + 1
    if c.flashTimer ~= 1 and (c.flashTimer >= 5 or c.stamina <= 0) then
      c.flashTimer = 0
      c.currColor[flashPart] = { r = 255, g = 0, b = 0 }
    end
  end

  -- update the palette
  for i, part in ipairs(USED_PARTS) do
    network_player_set_override_palette_color(np, part, c.currColor[part])
  end
end

---@param m MarioState
function before_set_action(m, action, actionArg)
  local c = gCelesteStates[m.playerIndex]

  -- ban some vanila actions when moveset is nerfed
  if gGlobalSyncTable.nerfMoveset then
    if action == ACT_DOUBLE_JUMP or action == ACT_LONG_JUMP or action == ACT_BACKFLIP then
      return ACT_JUMP
    elseif action == ACT_DIVE then
      if m.action == ACT_STEEP_JUMP then
        return 1
      elseif m.action & ACT_FLAG_AIR ~= 0 then
        return ACT_JUMP_KICK
      else
        set_mario_action(m, ACT_MOVE_PUNCHING, 0) -- so it still does sound
        return 1
      end
    end
  end

  if action == ACT_THROWING then
    return ACT_THROWING_CUSTOM
  elseif (action == ACT_AIR_THROW) then
    return ACT_AIR_THROW_CUSTOM
  elseif (action == ACT_GROUND_POUND and (m.action == ACT_HOLD_FREEFALL or m.action == ACT_HOLD_JUMP)) then
    m.input = m.input & ~INPUT_Z_PRESSED
    c.regrabDelay = REGRAB_DELAY
    return ACT_FREEFALL
  elseif (action == ACT_WATER_PLUNGE and m.action == ACT_AIR_DASH) then -- particles dashing into water
    play_sound(SOUND_OBJ_DIVING_IN_WATER, m.marioObj.header.gfx.pos)
    set_mario_particle_flags(m, PARTICLE_WATER_SPLASH, 0)
    return ACT_WATER_DASH
  elseif action == ACT_BRAKING then -- cancel braking action
    m.forwardVel = math.max(0, m.forwardVel - 10)
    return ACT_DECELERATING
  elseif action == ACT_SIDE_FLIP or (action == ACT_JUMP and c.turnAroundLeniency ~= 0) then -- do skid jump
    m.particleFlags = m.particleFlags | PARTICLE_MIST_CIRCLE
    c.turnAroundLeniency = 0
    m.action = ACT_JUMP
    m.actionArg = 2
    set_mario_y_vel_based_on_fspeed(m, 62, 0)
    m.forwardVel = 14 -- bit faster than the normal side flip
    m.faceAngle.y = m.intendedYaw
    play_celeste_sound("skidJump", m, 2)
    return 1
  elseif action == ACT_AIR_HIT_WALL or (action == ACT_BACKWARD_AIR_KB and m.hurtCounter == 0 and m.wall) or (action == ACT_SOFT_BONK and m.action == ACT_LEDGE_GRAB and c.actionTimer > 1) then -- wall sliding
    local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
    m.faceAngle.y = limit_angle(wallYaw + 0x8000)

    if c.bufferJump and m.framesSinceA < BUFFER_JUMP_TIME and m.framesSinceA < c.actionTimer then
      m.vel.y = 52

      if m.forwardVel < 20.0 then
        m.forwardVel = 20.0
      end
      if m.heldObj then
        if gGlobalSyncTable.allowNeutral and (m.input & INPUT_NONZERO_ANALOG) == 0 then -- funny neutral jump
          m.forwardVel = -m.forwardVel
          m.actionArg = 1
        else
          m.faceAngle.y = m.faceAngle.y + 0x8000
          m.actionArg = 2
        end
        return ACT_HOLD_JUMP
      else
        m.faceAngle.y = m.faceAngle.y + 0x8000
        return ACT_WALL_KICK_AIR
      end
    end
    set_mario_particle_flags(m, PARTICLE_VERTICAL_STAR, 1)

    if m.heldObj then
      mario_set_forward_vel(m, 0.0)
      return 1
    end

    c.holdAwayFromWallTime = 0
    return ACT_WALL_SLIDE
  elseif (not gGlobalSyncTable.nerfMoveset) and action == ACT_JUMP_KICK and m.action == ACT_JUMP and m.actionArg == 2 then -- don't kick out of skid jump
    return ACT_DIVE
  elseif action == ACT_TURNING_AROUND then -- switch to custom turn action
    return ACT_CUSTOM_TURN
  elseif c.bufferJump and (not c.alreadyBufferedA) and (m.framesSinceA < BUFFER_JUMP_TIME)
      and m.action == ACT_DIVE and c.actionTimer < BUFFER_JUMP_TIME and action == ACT_DIVE_SLIDE and m.forwardVel > 43 then -- buffer dive jump
    m.framesSinceB = 0
    c.alreadyBufferedB = false
    m.forwardVel = 32
    if m.prevAction == ACT_JUMP or m.prevAction == ACT_FREEFALL then
      set_mario_y_vel_based_on_fspeed(m, 52, 0.25)
    elseif m.prevAction == ACT_DOUBLE_JUMP then
      set_mario_y_vel_based_on_fspeed(m, 69, 0)
    else
      set_mario_y_vel_based_on_fspeed(m, 42, 0.25)
    end
    local forwardVel = math.min(m.forwardVel + 15, 48)
    mario_set_forward_vel(m, forwardVel)
    refill_dash(m.playerIndex)
    return 1
  end
end

function on_set_action(m)
  local c = gCelesteStates[m.playerIndex]

  c.velXBeforeGroundPound = 0
  c.prevActionTimer = c.actionTimer
  c.actionTimer = 0
  c.bunnyHop = false
  if (m.action == ACT_AIR_DASH and m.prevAction == ACT_WATER_DASH) then
    play_sound(SOUND_OBJ_DIVING_IN_WATER, m.marioObj.header.gfx.pos)
    set_mario_particle_flags(m, PARTICLE_WATER_SPLASH, 0)
    if m.playerIndex == 0 then
      set_camera_mode(m.area.camera, m.area.camera.defMode, 0)
    end
    return
  elseif m.action == ACT_WALL_KICK_AIR then
    c.jumpFromDash = false
    if gGlobalSyncTable.allowNeutral and (m.input & INPUT_NONZERO_ANALOG) == 0 then
      -- funny neutral jump
      m.faceAngle.y = m.faceAngle.y + 0x8000
      m.forwardVel = -m.forwardVel
      m.actionTimer = 0
      m.actionArg = 1
    end
    return
  elseif m.action == ACT_GROUND_POUND then
    c.velXBeforeGroundPound = m.forwardVel
  elseif (m.prevAction == ACT_FREEFALL_LAND) and c.demoDash then -- when landing after dashing downwards, multiply speed (allows ultras to be performed)
    if m.vel.y > 0 then
      --djui_chat_message_create("ULTRA")
      m.forwardVel = m.forwardVel * ULTRA_MULTIPLIER * 1.25 -- 1.25 is because jumping multiplies momentum by 0.8
      c.jumpFromDash = true
    end
    c.demoDash = false
  elseif (m.prevAction == ACT_GROUND_DASH) and m.ceil and m.ceilHeight - m.floorHeight < 160 then
    -- prevent getting stuck in ceiling
    local LIMIT = 10
    while m.ceilHeight - m.floorHeight < 160 and LIMIT ~= 0 do
      local ceilAngle = atan2s(m.ceil.normal.z, m.ceil.normal.x);
      m.pos.x = m.pos.x + 10 * sins(ceilAngle)
      m.pos.z = m.pos.z + 10 * coss(ceilAngle)
      LIMIT = LIMIT - 1
    end
  elseif m.action == ACT_WALL_SLIDE or m.action == ACT_WALL_CLIMB then
    -- reset camera mode when climbing
    if m.playerIndex == 0 and m.area.camera.mode == CAMERA_MODE_WATER_SURFACE then
      set_camera_mode(m.area.camera, -1, 20)
      if m.area.camera.mode == CAMERA_MODE_WATER_SURFACE then
        set_camera_mode(m.area.camera, m.area.camera.defMode, 1)
      end
    end
  elseif c.jumpFromDash and m.prevAction & ACT_FLAG_AIR == 0 and m.action & ACT_FLAG_AIR ~= 0 then -- maintain more speed by jumping after a dash jump (sort of replicates hyperbhops)
    if m.vel.y > 0 and m.action & ACT_FLAG_SWIMMING_OR_FLYING == 0 then
      -- detect bunny hop and set state appropriately
      if c.demoDash and (not c.fragmentDash) and c.bunnyHopTimer ~= 0 then
        c.bunnyHop = true
        c.bunnyHopTimer = 0
        c.spawnRingTimer = 30
        m.forwardVel = HYPER_VELOCITY
        return
      end
      
      m.forwardVel = m.forwardVel * 1.25 -- 1.25 is because jumping multiplies momentum by 0.8
    else
      c.jumpFromDash = false
    end
    c.spawnRingTimer = 0
  end
end

-- update the throwing angle of the just-thrown object
function update_thrown_object()
  if justThrownObject == nil or justThrownObject.oHeldState ~= HELD_FREE then return end

  local o = justThrownObject
  justThrownObject = nil

  o.oVelY = 35
  o.oForwardVel = 35
  if o.oSyncID ~= 0 then network_send_object(o, true) end
end

function act_ground_dash(m)
  local c = gCelesteStates[m.playerIndex]
  m.marioBodyState.handState = MARIO_HAND_OPEN

  --m.forwardVel = approach_f32(m.forwardVel, dashVelX * c.dampening, 20, 20)

  if c.dashTimer < DASH_TIMER_MAX - DAMP_START then
    mario_set_forward_vel(m, m.forwardVel * DAMP_RATE)
    dash_adjust(m)
  elseif gGlobalSyncTable.superDash then
    dash_adjust(m)
  end

  local result = perform_ground_step(m)
  if (result == GROUND_STEP_LEFT_GROUND) then
    set_mario_action(m, ACT_AIR_DASH, 0)
  elseif result == GROUND_STEP_HIT_WALL then
    return set_mario_action(m, ACT_WALKING, 0)
  end
  set_mario_animation(m, MARIO_ANIM_FAST_LONGJUMP)
  set_anim_to_frame(m, 100)

  if (m.input & INPUT_A_PRESSED) ~= 0 then
    return jump_from_dash(m)
  elseif (m.input & INPUT_B_PRESSED) ~= 0 then -- attacks out of dash
    local action = ACT_JUMP_KICK
    if (m.input & INPUT_Z_DOWN) ~= 0 then
      action = ACT_SLIDE_KICK
    end
    
    local result = set_mario_action(m, action, 0)
    mario_set_forward_vel(m, MAX_AIR_SPEED)
    c.jumpFromDash = true
    return result
  end

  if m.action == ACT_GROUND_DASH and c.dashTimer <= 0 then
    m.forwardVel = math.min(m.forwardVel, ORTHO_VELOCITY_END)
    c.demoDash = false
    return set_mario_action(m, ACT_WALKING, 0)
  end
  return 0
end

function act_air_dash(m)
  local c = gCelesteStates[m.playerIndex]
  m.marioBodyState.handState = MARIO_HAND_OPEN

  --m.forwardVel = approach_f32(m.forwardVel, dashVelX * c.dampening, 20, 20)
  --m.vel.y = dashVelY * c.dampening
  if c.dashTimer < DASH_TIMER_MAX - DAMP_START and m.vel.y >= 0 then
    mario_set_forward_vel(m, m.forwardVel * DAMP_RATE)
    dash_adjust(m)
    --c.dampening = c.dampening * DAMP_RATE
  elseif gGlobalSyncTable.superDash then
    dash_adjust(m)
  end

  local land_act = ACT_GROUND_DASH
  if c.vertDash then
    m.faceAngle.y = m.intendedYaw
    if (m.input & INPUT_Z_DOWN) ~= 0 or (m.controller.buttonDown & D_JPAD) ~= 0 then
      land_act = ACT_GROUND_POUND_LAND
    else
      land_act = ACT_FREEFALL_LAND
    end
  end

  local stepResult = perform_air_step(m, AIR_STEP_CHECK_LEDGE_GRAB | AIR_STEP_CHECK_HANG)
  if stepResult == AIR_STEP_NONE then
    set_character_animation(m, CHAR_ANIM_FAST_LONGJUMP)
    set_anim_to_frame(m, 100)
  elseif stepResult == AIR_STEP_LANDED then
    if land_act == ACT_GROUND_POUND_LAND then -- ground pound effect
      play_mario_heavy_landing_sound(m, SOUND_ACTION_TERRAIN_HEAVY_LANDING)
      set_mario_particle_flags(m, (PARTICLE_MIST_CIRCLE | PARTICLE_HORIZONTAL_STAR), 0)
    elseif land_act == ACT_GROUND_DASH then
      -- 1.2 times speed boost meant to make downward dashes as long as horizontal when landing
      m.forwardVel = m.forwardVel * ULTRA_MULTIPLIER
      if m.vel.y < 0 then
        c.demoDash = true
      end
    end
    m.vel.y = 0
    return set_mario_action(m, land_act, 0)
  elseif stepResult == AIR_STEP_HIT_WALL then
    set_character_animation(m, CHAR_ANIM_FAST_LONGJUMP)
    set_anim_to_frame(m, 100)

    if (m.forwardVel > 16) then
      if (gServerSettings.bouncyLevelBounds == BOUNCY_LEVEL_BOUNDS_OFF or m.wall) then
        queue_rumble_data_mario(m, 5, 40);
        mario_bonk_reflection(m, 0);
        m.faceAngle.y = m.faceAngle.y + 0x8000;
      end

      if (m.wall) then
        set_mario_action(m, ACT_AIR_HIT_WALL, 0);
      else
        if (m.vel.y > 0) then
          m.vel.y = 0;
        end

        if (gServerSettings.bouncyLevelBounds == BOUNCY_LEVEL_BOUNDS_OFF) then
          if (m.forwardVel >= 38) then
            set_mario_particle_flags(m, PARTICLE_VERTICAL_STAR, 0);
            set_mario_action(m, ACT_BACKWARD_AIR_KB, 0);
          else
            if (m.forwardVel > 8) then
              mario_set_forward_vel(m, -8);
            end
            return set_mario_action(m, ACT_SOFT_BONK, 0);
          end
        end
      end
    else
      mario_set_forward_vel(m, 0);
    end
  elseif stepResult == AIR_STEP_GRABBED_LEDGE then
    set_character_animation(m, CHAR_ANIM_IDLE_ON_LEDGE);
    return drop_and_set_mario_action(m, ACT_LEDGE_GRAB, 0);
  elseif stepResult == AIR_STEP_GRABBED_CEILING then
    return set_mario_action(m, ACT_HANGING, 0);
  elseif stepResult == AIR_STEP_HIT_LAVA_WALL then
    return lava_boost_on_wall(m)
  end

  -- ceiling check, doesn't run for hanging ceilings
  if m.vel.y > 0 and m.ceil ~= nil and m.ceil.type ~= SURFACE_HANGABLE and math.floor(m.ceilHeight - (m.pos.y + m.vel.y)) <= 161 then
    m.vel.y = 0
  end

  -- Switch to down dash if we press Z or D-DPAD within the given leniency
  local allowDashAdjust = false
  if (m.input & INPUT_Z_PRESSED) ~= 0 or (m.controller.buttonPressed & D_JPAD) ~= 0 then
    if (DASH_TIMER_MAX - c.dashTimer <= DASH_DOWN_LENIENCY) and (m.vel.y >= 0) then
      local dashVelX = DIAG_VELOCITY
      local dashVelY = -DIAG_VELOCITY
      mario_set_forward_vel(m, dashVelX)
      m.vel.y = dashVelY
      c.demoDash = true
      allowDashAdjust = true
    end
  end

  if not allowDashAdjust then
    allowDashAdjust = super_vertical_adjust(m, c)
  end

  -- jumps / attacks out of dash
  if c.allowCoyoteTime and c.coyoteTime > 0 and (m.input & INPUT_A_PRESSED) ~= 0 then
    return jump_from_dash(m)
  elseif (m.input & INPUT_Z_PRESSED) ~= 0 and (not allowDashAdjust) and c.coyoteTime == 0 then
    set_mario_action(m, ACT_GROUND_POUND, 0)
    return 1
  end
  
  if (m.input & INPUT_B_PRESSED) ~= 0 and (not gGlobalSyncTable.nerfMoveset) then
    local newVel = ORTHO_VELOCITY_END
    if m.vel.y > newVel then
      m.vel.y = newVel
    end
    set_mario_action(m, ACT_DIVE, 0)
    return 1
  end

  if m.action == ACT_AIR_DASH and c.dashTimer <= 0 then
    if m.vel.y >= 0 then
      if m.vel.y == 0 then
        m.forwardVel = math.min(m.forwardVel, ORTHO_VELOCITY_END)
      else
        m.forwardVel = math.min(m.forwardVel, DIAG_VELOCITY_END)
        -- m.vel.y = math.min(m.vel.y, DIAG_VELOCITY_END)
      end
    end
    c.jumpFromDash = true
    return set_mario_action(m, ACT_FREEFALL, 0)
  end
  return 0
end

function act_water_dash(m)
  local c = gCelesteStates[m.playerIndex]
  m.marioBodyState.handState = MARIO_HAND_OPEN

  --m.forwardVel = approach_f32(m.forwardVel, ORTHO_VELOCITY * c.dampening * fast_swim, 20 * fast_swim, 20 * fast_swim)

  if c.dashTimer < DASH_TIMER_MAX - DAMP_START then
    m.forwardVel = m.forwardVel * DAMP_RATE
    m.vel.x = m.vel.x * DAMP_RATE
    m.vel.z = m.vel.z * DAMP_RATE
    dash_adjust(m, true)
  elseif gGlobalSyncTable.superDash then
    dash_adjust(m, true)
  end
  m.vel.x = m.vel.x * fast_swim
  m.vel.y = m.vel.y * fast_swim
  m.vel.z = m.vel.z * fast_swim

  local prevVelY = m.vel.y
  local stepResult = perform_water_step(m)
  if handle_dash_water_interacts(m, stepResult & WATER_STEP_HIT_WALL ~= 0) then
    stepResult = WATER_STEP_NONE
  end

  -- adjust up and down during super dash
  local allowDashAdjust = gGlobalSyncTable.superDash and not c.vertDash
  if allowDashAdjust and math.abs(m.controller.stickY) > 5 then
    m.faceAngle.x = clamp(m.faceAngle.x - m.controller.stickY * 8, -0x4000, 0x4000)
    m.vel.x = (m.forwardVel * coss(m.faceAngle.x) * sins(m.faceAngle.y))
    m.vel.y = m.forwardVel * sins(m.faceAngle.x)
    m.vel.z = (m.forwardVel * coss(m.faceAngle.x) * coss(m.faceAngle.y))
  end

  if stepResult == WATER_STEP_HIT_WALL and not c.vertDash then
    local nextPos = {x = m.pos.x + m.vel.x, y = m.pos.y + m.vel.y, z = m.pos.z + m.vel.z}
    local wcd = collision_get_temp_wall_collision_data()
    resolve_and_return_wall_collisions_data(nextPos, 10, 110, wcd)
    mario_update_wall(m, wcd)
    local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
    local wallAngleDiff = limit_angle(wallYaw - m.faceAngle.y)
    if wallAngleDiff <= 0x4000 and wallAngleDiff >= -0x4000 then
      -- do nothing
    elseif wallAngleDiff >= 0x6000 or wallAngleDiff <= -0x6000 then
      -- bonk if angled towards wall
      set_mario_particle_flags(m, PARTICLE_VERTICAL_STAR, 0)
      play_sound(SOUND_ACTION_HIT, m.marioObj.header.gfx.cameraToObject)
      set_mario_action(m, ACT_BACKWARD_WATER_KB, 0)
      m.forwardVel = -20
      return 1
    elseif wallAngleDiff > 0 then -- adjust angle to go across wall
      m.faceAngle.y = wallYaw - 0x4000
    else
      m.faceAngle.y = wallYaw + 0x4000
    end
  elseif stepResult == WATER_STEP_HIT_FLOOR then
    local floorPitch = -find_floor_slope(m, -0x8000)
    if (m.faceAngle.x < floorPitch) then
      m.faceAngle.x = floorPitch
      m.vel.x = (m.forwardVel * coss(m.faceAngle.x) * sins(m.faceAngle.y))
      m.vel.y = m.forwardVel * sins(m.faceAngle.x)
      m.vel.z = (m.forwardVel * coss(m.faceAngle.x) * coss(m.faceAngle.y))
    end
  elseif stepResult == WATER_STEP_HIT_CEILING then
    m.vel.y = 0
    m.faceAngle.x = 0
  end
  if prevVelY > 0 and m.waterLevel - m.pos.y <= 80 then
    m.vel.y = prevVelY / fast_swim
    --djui_chat_message_create(tostring(m.forwardVel))
    --m.forwardVel = m.forwardVel * coss(m.faceAngle.x)
    m.pos.y = m.waterLevel
    m.forwardVel = m.forwardVel * coss(m.faceAngle.x)
    return set_mario_action(m, ACT_AIR_DASH, 0)
  end

  -- attacks out of dash
  if (m.input & INPUT_B_PRESSED) ~= 0 then
    set_mario_action(m, ACT_WATER_PUNCH, 0)
    return 1
  end

  set_mario_animation(m, MARIO_ANIM_FAST_LONGJUMP)
  set_anim_to_frame(m, 100)

  if m.action == ACT_WATER_DASH and c.dashTimer <= 0 then
    return set_mario_action(m, ACT_WATER_ACTION_END, 0)
  end
  return 0
end

function act_metal_ground_water_dash(m)
  local c = gCelesteStates[m.playerIndex]
  m.marioBodyState.handState = MARIO_HAND_OPEN

  if (m.flags & MARIO_METAL_CAP) == 0 then
    return set_mario_action(m, ACT_WATER_DASH, 0)
  end

  --m.forwardVel = approach_f32(m.forwardVel, dashVelX * c.dampening, 20, 20)
  if c.dashTimer < DASH_TIMER_MAX - DAMP_START then
    mario_set_forward_vel(m, m.forwardVel * DAMP_RATE)
    dash_adjust(m)
  elseif gGlobalSyncTable.superDash then
    dash_adjust(m)
  end

  local stepResult = perform_ground_step(m)
  if handle_dash_water_interacts(m, stepResult & GROUND_STEP_HIT_WALL ~= 0) then
    stepResult = GROUND_STEP_NONE
  end

  if stepResult == GROUND_STEP_HIT_WALL then
    local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
    local wallAngleDiff = limit_angle(wallYaw - m.faceAngle.y)
    if wallAngleDiff <= 0x4000 and wallAngleDiff >= -0x4000 then
      -- do nothing
    elseif wallAngleDiff >= 0x6000 or wallAngleDiff <= -0x6000 then
      -- bonk if angled towards wall
      set_mario_particle_flags(m, PARTICLE_VERTICAL_STAR, 0)
      play_sound(SOUND_ACTION_HIT, m.marioObj.header.gfx.cameraToObject)
      set_mario_action(m, ACT_BACKWARD_WATER_KB, 0)
      m.forwardVel = -20
      return 1
    elseif wallAngleDiff > 0 then -- adjust angle to go across wall
      m.faceAngle.y = wallYaw - 0x4000
    else
      m.faceAngle.y = wallYaw + 0x4000
    end
  elseif stepResult == GROUND_STEP_LEFT_GROUND then
    set_mario_action(m, ACT_METAL_WATER_DASH, 0)
  end

  if m.vel.y > 0 and m.waterLevel - m.pos.y < 160 then
    m.pos.y = m.waterLevel
    return set_mario_action(m, ACT_AIR_DASH, 0)
  end

  -- jump out of dash
  if (m.input & INPUT_A_PRESSED) ~= 0 then
    return jump_from_dash(m, true)
  end

  set_mario_animation(m, MARIO_ANIM_FAST_LONGJUMP)
  set_anim_to_frame(m, 100)

  if m.action == ACT_METAL_GROUND_WATER_DASH and c.dashTimer <= 0 then
    return set_mario_action(m, ACT_METAL_WATER_WALKING, 0)
  end
  return 0
end

function act_metal_water_dash(m)
  local c = gCelesteStates[m.playerIndex]
  m.marioBodyState.handState = MARIO_HAND_OPEN

  if (m.flags & MARIO_METAL_CAP) == 0 then
    return set_mario_action(m, ACT_WATER_DASH, 0)
  end
  m.vel.y = m.vel.y + 1

  --m.forwardVel = approach_f32(m.forwardVel, dashVelX * c.dampening, 20, 20)
  --m.vel.y = dashVelY * c.dampening
  if c.dashTimer < DASH_TIMER_MAX - DAMP_START then
    mario_set_forward_vel(m, m.forwardVel * DAMP_RATE)
    dash_adjust(m)
    --c.dampening = c.dampening * DAMP_RATE
  elseif gGlobalSyncTable.superDash then
    dash_adjust(m)
  end

  local stepResult = perform_air_step(m, 0)
  if handle_dash_water_interacts(m, stepResult & AIR_STEP_HIT_WALL ~= 0) then
    stepResult = AIR_STEP_NONE
  end
  
  if stepResult == AIR_STEP_HIT_WALL then
    local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
    local wallAngleDiff = limit_angle(wallYaw - m.faceAngle.y)
    if wallAngleDiff <= 0x4000 and wallAngleDiff >= -0x4000 then
      -- do nothing
    elseif wallAngleDiff >= 0x6000 or wallAngleDiff <= -0x6000 then
      -- bonk if angled towards wall
      set_mario_particle_flags(m, PARTICLE_VERTICAL_STAR, 0)
      play_sound(SOUND_ACTION_HIT, m.marioObj.header.gfx.cameraToObject)
      set_mario_action(m, ACT_BACKWARD_WATER_KB, 0)
      m.forwardVel = -20
      return 1
    elseif wallAngleDiff > 0 then -- adjust angle to go across wall
      m.faceAngle.y = wallYaw - 0x4000
    else
      m.faceAngle.y = wallYaw + 0x4000
    end
  elseif stepResult == AIR_STEP_LANDED then
    set_mario_action(m, ACT_METAL_GROUND_WATER_DASH, 0)
  end

  super_vertical_adjust(m, c)

  if m.vel.y > 0 and m.waterLevel - m.pos.y < 160 then
    m.pos.y = m.waterLevel
    return set_mario_action(m, ACT_AIR_DASH, 0)
  end

  -- jump out of dash
  if c.allowCoyoteTime and c.coyoteTime > 0 and (m.input & INPUT_A_PRESSED) ~= 0 then
    return jump_from_dash(m, true)
  end

  set_mario_animation(m, MARIO_ANIM_FAST_LONGJUMP)
  set_anim_to_frame(m, 100)

  if m.action == ACT_METAL_WATER_DASH and c.dashTimer <= 0 then
    m.action = ACT_METAL_WATER_JUMP
    m.flags = m.flags | MARIO_ACTION_SOUND_PLAYED
    return 1
  end
  return 0
end

function gravity_dash(m)
  local c = gCelesteStates[m.playerIndex]
  if c.dashTimer < DASH_TIMER_MAX - DAMP_START then
    m.vel.y = m.vel.y * DAMP_RATE
  end
  m.peakHeight = m.pos.y
end

---@param m MarioState
function act_wall_slide(m)
  local c = gCelesteStates[m.playerIndex]
  if (m.controller.buttonDown & B_BUTTON) ~= 0 and c.stamina > 0 then
    c.holdAwayFromWallTime = 0
    m.forwardVel = 20
    c.climbYaw = 0.1
    return set_mario_action(m, ACT_WALL_CLIMB, 0)
  end

  local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
  if m.forwardVel < 0 then
    mario_set_forward_vel(m, 0)
  end
  m.faceAngle.y = wallYaw + 0x8000

  if (m.input & INPUT_A_PRESSED) ~= 0 then
    m.vel.y = 60.0

    m.faceAngle.y = m.faceAngle.y + 0x8000
    if m.forwardVel < 20.0 then
      m.forwardVel = 20.0
    end

    m.wallKickTimer = 0
    c.holdAwayFromWallTime = 0

    -- prevent ceiling clip
    if m.pos.y + 160 >= m.ceilHeight then
      m.pos.y = m.ceilHeight - 160
      m.marioObj.hitboxHeight = 160
    end

    return set_mario_action(m, ACT_WALL_KICK_AIR, 0)
  end
  m.forwardVel = 20

  m.particleFlags = m.particleFlags | PARTICLE_DUST

  m.terrainSoundAddend = get_surface_sound_addend(m, m.wall)
  play_sound(SOUND_MOVING_TERRAIN_SLIDE + m.terrainSoundAddend, m.marioObj.header.gfx.pos)
  if USE_CRAWL_ANIM then
    set_mario_animation(m, MARIO_ANIM_CRAWLING)
    set_anim_to_frame(m, 0)
  else
    set_mario_animation(m, MARIO_ANIM_IDLE_ON_POLE)
  end

  -- stick to wall a bit
  m.vel.x = approach_s32(m.vel.x, 0, 2, 2) + sins(m.faceAngle.y)
  m.vel.z = approach_s32(m.vel.z, 0, 2, 2) + coss(m.faceAngle.y)

  local result = perform_air_step(m, 0)
  if result == AIR_STEP_LANDED then
    mario_set_forward_vel(m, 0.0)
    c.holdAwayFromWallTime = 0
    return set_mario_action(m, ACT_FREEFALL_LAND, 0)
  elseif result == AIR_STEP_HIT_LAVA_WALL then
    lava_boost_on_wall(m)
    return
  end

  local stickForceY = coss(limit_angle(m.intendedYaw - m.faceAngle.y))
  if (stickForceY <= -0.8) then
    c.holdAwayFromWallTime = c.holdAwayFromWallTime + 1
  else
    c.holdAwayFromWallTime = 0
  end
  m.actionTimer = m.actionTimer + 1
  if ((not m.wall) and m.actionTimer > 2) or (c.holdAwayFromWallTime > 10) then
    mario_set_forward_vel(m, 0.0)
    c.holdAwayFromWallTime = 0
    return set_mario_action(m, ACT_FREEFALL, 0)
  end

  -- gravity
  m.peakHeight = m.pos.y
  --m.vel.y = m.vel.y - 1
  --if m.vel.y < -35 then m.vel.y = -35 end

  return 0
end

---@param m MarioState
function act_wall_climb(m)
  local c = gCelesteStates[m.playerIndex]
  local wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
  m.faceAngle.y = wallYaw + 0x8000

  if (m.controller.buttonDown & B_BUTTON) == 0 or c.stamina <= 0 then
    if m.vel.y > 0 then
      m.vel.y = 0
    end
    return set_mario_action(m, ACT_WALL_SLIDE, 0)
  end

  --[[if m.playerIndex == 0 and m.area.camera.mode ~= CAMERA_MODE_BEHIND_MARIO then
    set_camera_mode(m.area.camera, CAMERA_MODE_BEHIND_MARIO, 1)
  end]]

  m.actionTimer = m.actionTimer + 1

  if (m.input & INPUT_A_PRESSED) ~= 0 then
    local rc = 0
    if (m.input & INPUT_NONZERO_ANALOG) ~= 0 and abs_angle_diff(m.intendedYaw, wallYaw) < 0x2000 then -- wall kick
      rc = set_mario_action(m, ACT_WALL_KICK_AIR, 0)

      m.vel.y = 60.0

      m.faceAngle.y = m.faceAngle.y + 0x8000
      if m.forwardVel < 20.0 then
        m.forwardVel = 20.0
      end
      m.wallKickTimer = 0
    else -- climb jump
      rc = set_mario_action(m, ACT_JUMP, 1)

      m.vel.y = 50.0
      m.forwardVel = 0
      c.stamina = c.stamina - 703

      m.wallKickTimer = 0
    end

    -- prevent ceiling clip
    if m.pos.y + 160 >= m.ceilHeight then
      m.pos.y = m.ceilHeight - 160
      m.marioObj.hitboxHeight = 160
    end
    
    return rc
  end

  m.peakHeight = m.pos.y
  c.stamina = c.stamina - 10
  local stickForceX = 0
  local stickForceY = 0
  if (m.input & INPUT_NONZERO_ANALOG) == 0 then -- staying still
    if USE_CRAWL_ANIM then
      set_mario_animation(m, MARIO_ANIM_CRAWLING)
      set_anim_to_frame(m, 0)
    else
      set_mario_animation(m, MARIO_ANIM_IDLE_ON_POLE)
    end
    c.climbYaw = 0.1
  else
    local yaw = 0
    if c.climbYaw == 0.1 then
      c.climbXMultiplier = 1
      if c.relClimb then
        c.climbYaw = m.intendedYaw - atan2s(-m.controller.stickY, m.controller.stickX) - m.faceAngle.y
        yaw = m.intendedYaw - m.faceAngle.y
      else
        c.climbYaw = 0x8000
        if abs_angle_diff(m.area.camera.yaw, m.faceAngle.y) < 0x2000 then -- switch left/right if facing front of mario
          c.climbXMultiplier = -1
        end
        yaw = atan2s(m.controller.stickY, -m.controller.stickX * c.climbXMultiplier)
      end
    else
      yaw = c.climbYaw + atan2s(-m.controller.stickY, m.controller.stickX * c.climbXMultiplier)
    end
    stickForceX = sins(limit_angle(yaw))
    stickForceY = coss(limit_angle(yaw))
    if math.abs(stickForceX) < 0.3 then
      stickForceX = 0
    end
    if math.abs(stickForceY) < 0.3 then
      stickForceY = 0
    end

    if stickForceX == 0 and stickForceY < 0 then -- going down
      m.particleFlags = m.particleFlags | PARTICLE_DUST

      m.terrainSoundAddend = get_surface_sound_addend(m, m.wall)
      play_sound(SOUND_MOVING_TERRAIN_SLIDE + m.terrainSoundAddend, m.marioObj.header.gfx.pos)
      if USE_CRAWL_ANIM then
        set_mario_animation(m, MARIO_ANIM_CRAWLING)
        set_anim_to_frame(m, 0)
      else
        set_mario_animation(m, MARIO_ANIM_IDLE_ON_POLE)
      end
    elseif stickForceX ~= 0 or stickForceY ~= 0 then
      if is_anim_past_frame(m, 1) ~= 0 then
        play_sound(SOUND_ACTION_CLIMB_UP_POLE, m.marioObj.header.gfx.pos)
      end
      local anim = MARIO_ANIM_CLIMB_UP_POLE
      if USE_CRAWL_ANIM then
        anim = MARIO_ANIM_CRAWLING
      elseif stickForceX < 0 then
        anim = MARIO_ANIM_SIDESTEP_RIGHT
      elseif stickForceX > 0 then
        anim = MARIO_ANIM_SIDESTEP_LEFT
      end
      set_mario_anim_with_accel(m, anim, 0x2400 * m.controller.stickMag)
      c.stamina = c.stamina -
          math.max(10, math.floor(35 * stickForceY)) -- lose less stamina climbing sideways / downwards
    end
  end

  local climbSpeed = 20
  m.vel.y = stickForceY * climbSpeed
  m.vel.x = coss(m.faceAngle.y) * stickForceX * climbSpeed + sins(m.faceAngle.y)
  m.vel.z = sins(-m.faceAngle.y) * stickForceX * climbSpeed + coss(m.faceAngle.y)

  local moveResult = move_on_wall(m, wallYaw, stickForceX)
  if moveResult ~= 0 then
    -- prevent ceiling clip
    if m.pos.y + 160 >= m.ceilHeight then
      m.pos.y = m.ceilHeight - 160
      m.marioObj.hitboxHeight = 160
    end
    return moveResult
  end

  return 0
end

function move_on_wall(m, wallYaw, velX)
  -- for picking best wall
  if velX > 0 then
    m.faceAngle.y = m.faceAngle.y + 0x4000
  elseif velX < 0 then
    m.faceAngle.y = m.faceAngle.y - 0x4000
  end

  -- change collision settings just for this action
  local prevColBugs = gLevelValues.fixCollisionBugs
  prevColBugs = prevColBugs | (gLevelValues.fixCollisionBugsRoundedCorners << 1)
  prevColBugs = prevColBugs | (gLevelValues.fixCollisionBugsPickBestWall << 2)
  gLevelValues.fixCollisionBugs = 1
  gLevelValues.fixCollisionBugsRoundedCorners = 0
  gLevelValues.fixCollisionBugsPickBestWall = 1

  local result = perform_air_step(m, 0)

  m.faceAngle.y = wallYaw + 0x8000
  m.marioObj.header.gfx.angle.y = m.faceAngle.y

  if result == AIR_STEP_LANDED then
    mario_set_forward_vel(m, 0.0)
    -- change the settings back
    gLevelValues.fixCollisionBugs = prevColBugs & 1
    gLevelValues.fixCollisionBugsRoundedCorners = (prevColBugs & 2 ~= 0 and 1) or 0
    gLevelValues.fixCollisionBugsPickBestWall = (prevColBugs & 4 ~= 0 and 1) or 0

    gCelesteStates[m.playerIndex].holdAwayFromWallTime = 0
    return set_mario_action(m, ACT_FREEFALL_LAND, 0)
  elseif result == AIR_STEP_HIT_LAVA_WALL then
    -- change the settings back
    gLevelValues.fixCollisionBugs = prevColBugs & 1
    gLevelValues.fixCollisionBugsRoundedCorners = (prevColBugs & 2 ~= 0 and 1) or 0
    gLevelValues.fixCollisionBugsPickBestWall = (prevColBugs & 4 ~= 0 and 1) or 0

    lava_boost_on_wall(m)
    return 0
  end

  -- stick to walls, turning corners
  if not m.wall then
    local raydist = 100
    local pos = { m.pos.x, m.pos.y + 60, m.pos.z }
    local forwardPos = { sins(m.faceAngle.y) * raydist, coss(m.faceAngle.y) * raydist }
    local col = collision_find_surface_on_ray(pos[1], pos[2], pos[3], forwardPos[1], 0, forwardPos[2])
    if not surface_is_wall(col) then
      -- check 90 degrees
      local angle = m.faceAngle.y
      if velX < 0 then
        angle = angle + 0x4000
      else
        angle = angle - 0x4000
      end

      raydist = 81
      local sidePos = { sins(angle) * raydist, coss(angle) * raydist }
      raydist = 81
      forwardPos = { sins(m.faceAngle.y) * raydist, coss(m.faceAngle.y) * raydist }

      col = collision_find_surface_on_ray(pos[1] + forwardPos[1], pos[2], pos[3] + forwardPos[2], sidePos[1], 0,
        sidePos[2])
      if (not surface_is_wall(col)) then
        -- change the settings back
        gLevelValues.fixCollisionBugs = prevColBugs & 1
        gLevelValues.fixCollisionBugsRoundedCorners = (prevColBugs & 2 ~= 0 and 1) or 0
        gLevelValues.fixCollisionBugsPickBestWall = (prevColBugs & 4 ~= 0 and 1) or 0

        mario_set_forward_vel(m, 0.0)
        if m.vel.y > 0 then
          return set_mario_action(m, ACT_JUMP, 1)
        end
        return set_mario_action(m, ACT_FREEFALL, 0)
      end
    end
    wallYaw = atan2s(col.surface.normal.z, col.surface.normal.x)

    m.actionTimer = 0
    m.faceAngle.y = wallYaw + 0x8000
    m.wall = col.surface
    m.wallNormal.x = col.surface.normal.x
    m.wallNormal.z = col.surface.normal.z

    --col.hitPos.x = col.hitPos.x + sins(m.faceAngle.y)
    --col.hitPos.z = col.hitPos.z + coss(m.faceAngle.y)
    --col.hitPos.y = col.hitPos.y - 60

    --vec3f_copy(m.pos, col.hitPos)
    --[[m.vel.y = 0
    m.vel.x = coss(m.faceAngle.y) * stickForceX * climbSpeed + sins(m.faceAngle.y)
    m.vel.z = sins(-m.faceAngle.y) * stickForceX * climbSpeed + coss(m.faceAngle.y)
    perform_air_step(m, 0)
    m.wall = col.surface
    m.wallNormal.x = col.surface.normal.x
    m.wallNormal.z = col.surface.normal.z]]

    --return set_mario_action(m, ACT_FREEFALL, 0)
    local wcd = collision_get_temp_wall_collision_data()
    resolve_and_return_wall_collisions_data(col.hitPos, 30, 24, wcd)
    col.hitPos.y = col.hitPos.y - 60
    vec3f_copy(m.pos, col.hitPos)

    mario_update_wall(m, wcd)
    wallYaw = 0
    if m.wall then
      wallYaw = atan2s(m.wall.normal.z, m.wall.normal.x)
    else
      wallYaw = atan2s(m.wallNormal.z, m.wallNormal.x)
    end
    m.faceAngle.y = wallYaw + 0x8000
    return 0
  end

  -- change the settings back
  gLevelValues.fixCollisionBugs = prevColBugs & 1
  gLevelValues.fixCollisionBugsRoundedCorners = (prevColBugs & 2 ~= 0 and 1) or 0
  gLevelValues.fixCollisionBugsPickBestWall = (prevColBugs & 4 ~= 0 and 1) or 0

  -- move on object wall
  if m.wall and m.wall.object then
    local o = m.wall.object
    apply_platform_displacement(m.playerIndex, o)
  end
  return 0
end

-- copied from C code (modified to not support objects)
function apply_platform_displacement(playerIndex, platform)
  local x;
  local y;
  local z;
  local platformPosX;
  local platformPosY;
  local platformPosZ;
  local currentObjectOffset = { x = 0, y = 0, z = 0 }
  local relativeOffset = { x = 0, y = 0, z = 0 }
  local newObjectOffset = { x = 0, y = 0, z = 0 }
  local rotation = { x = 0, y = 0, z = 0 }
  local displaceMatrix = { m00 = 0, m01 = 0, m02 = 0, m03 = 0, m10 = 0, m11 = 0, m12 = 0, m13 = 0, m20 = 0, m21 = 0, m22 = 0, m23 = 0, m30 = 0, m31 = 0, m32 = 0, m33 = 0 }
  if not platform then return end

  rotation.x = platform.oAngleVelPitch;
  rotation.y = platform.oAngleVelYaw;
  rotation.z = platform.oAngleVelRoll;

  local m = gMarioStates[playerIndex]
  if not m then return end
  x = m.pos.x;
  y = m.pos.y;
  z = m.pos.z;

  x = x + platform.oVelX;
  -- not in original function; it has a threshold so climbing on whomp isn't weird
  if math.abs(platform.oVelY) > 2 then
    y = y + platform.oVelY
  end
  z = z + platform.oVelZ;

  if rotation.x ~= 0 or rotation.y ~= 0 or rotation.z ~= 0 then
    m.faceAngle.y = m.faceAngle.y + rotation.y;

    platformPosX = platform.oPosX;
    platformPosY = platform.oPosY;
    platformPosZ = platform.oPosZ;

    currentObjectOffset.x = x - platformPosX;
    currentObjectOffset.y = y - platformPosY;
    currentObjectOffset.z = z - platformPosZ;

    rotation.x = platform.oFaceAnglePitch - platform.oAngleVelPitch;
    rotation.y = platform.oFaceAngleYaw - platform.oAngleVelYaw;
    rotation.z = platform.oFaceAngleRoll - platform.oAngleVelRoll;

    mtxf_rotate_zxy_and_translate(displaceMatrix, currentObjectOffset, rotation);
    linear_mtxf_transpose_mul_vec3f(displaceMatrix, relativeOffset, currentObjectOffset);

    rotation.x = platform.oFaceAnglePitch;
    rotation.y = platform.oFaceAngleYaw;
    rotation.z = platform.oFaceAngleRoll;

    mtxf_rotate_zxy_and_translate(displaceMatrix, currentObjectOffset, rotation);
    linear_mtxf_mul_vec3f(displaceMatrix, newObjectOffset, relativeOffset);

    x = platformPosX + newObjectOffset.x;
    y = platformPosY + newObjectOffset.y;
    z = platformPosZ + newObjectOffset.z;
  end

  m.pos.x = x;
  m.pos.y = y;
  m.pos.z = z;
end

-- get the terrain sound addend by temporarily overriding mario's floor
function get_surface_sound_addend(m, surface)
  if not m then return SURFACE_CLASS_NOT_SLIPPERY end
  local prevFloor = m.floor
  local prevWaterLevel = m.waterLevel
  m.floor = surface
  m.waterLevel = m.floorHeight
  local result = mario_get_terrain_sound_addend(m)
  m.floor = prevFloor
  m.waterLevel = prevWaterLevel
  return result
end

-- turn faster, like in celeste 64
function act_custom_turn(m)
  if not m then return false end

  if m.input & INPUT_ABOVE_SLIDE ~= 0 then
    m.faceAngle.y = m.faceAngle.y + 0x8000
    return set_mario_action(m, ACT_BEGIN_SLIDING, 0)
  end

  -- side flip (converted to skid jump)
  if m.input & INPUT_A_PRESSED ~= 0 then
    return set_mario_action(m, ACT_SIDE_FLIP, 0)
  end

  if m.input & INPUT_ZERO_MOVEMENT ~= 0 or analog_stick_held_back(m) == 0 then
    m.faceAngle.y = m.faceAngle.y + 0x8000
    m.forwardVel = -m.forwardVel
    return set_mario_action(m, ACT_DECELERATING, 0)
  end

  apply_slope_decel(m, 2.0)

  play_sound(SOUND_MOVING_TERRAIN_SLIDE + m.terrainSoundAddend, m.marioObj.header.gfx.cameraToObject)
  adjust_sound_for_speed(m)

  local ground_step_result = perform_ground_step(m)
  if ground_step_result == GROUND_STEP_LEFT_GROUND then
    set_mario_action(m, ACT_FREEFALL, 0)
  elseif ground_step_result == GROUND_STEP_NONE then
    set_mario_particle_flags(m, PARTICLE_DUST, false)
  end

  if m.forwardVel > 1 then
    set_character_animation(m, CHAR_ANIM_TURNING_PART1)
    --m.marioObj.header.gfx.animInfo.animFrame = m.marioObj.header.gfx.animInfo.animFrame + 2
  else
    local c = gCelesteStates[m.playerIndex]
    c.turnAroundLeniency = TURN_AROUND_LENIENCY
    begin_walking_action(m, 8.0, ACT_WALKING, 0)
  end
  m.marioObj.header.gfx.angle.y = m.marioObj.header.gfx.angle.y + 0x8000
  return 0
end

function act_picking_up_stall(m)
  play_character_sound_if_no_flag(m, CHAR_SOUND_HRMM, MARIO_MARIO_SOUND_PLAYED)
  m.marioBodyState.grabPos = GRAB_POS_LIGHT_OBJ
  set_character_animation(m, CHAR_ANIM_PICK_UP_LIGHT_OBJ)
  m.marioObj.header.gfx.animInfo.animFrame = m.marioObj.header.gfx.animInfo.animFrame + 2
  if (is_anim_at_end(m)) ~= 0 then
    if m.prevAction & ACT_FLAG_AIR ~= 0 then
      m.action = ACT_HOLD_FREEFALL
    else
      m.action = ACT_HOLD_WALKING
    end
    return 1
  end
  return 0
end

function act_throwing_custom(m)
  if (not m) then return 0 end
  if (m.heldObj and (m.heldObj.oInteractionSubtype & INT_SUBTYPE_HOLDABLE_NPC ~= 0)) then
    return set_mario_action(m, ACT_PLACING_DOWN, 0);
  end

  if (m.input & INPUT_UNKNOWN_10 ~= 0) then
    return drop_and_set_mario_action(m, ACT_SHOCKWAVE_BOUNCE, 0);
  end

  if (m.input & INPUT_OFF_FLOOR ~= 0) then
    return drop_and_set_mario_action(m, ACT_FREEFALL, 0);
  end

  m.actionTimer = m.actionTimer + 1
  if (m.actionTimer == 1) then
    mario_set_forward_vel(m, 0)
  elseif (m.actionTimer == 2) then
    gCelesteStates[m.playerIndex].regrabDelay = REGRAB_DELAY
    if m.playerIndex == 0 then
      justThrownObject = m.heldObj
    end
    mario_throw_held_object(m);
    mario_set_forward_vel(m, -20)
    play_character_sound_if_no_flag(m, CHAR_SOUND_WAH2, MARIO_MARIO_SOUND_PLAYED);
    play_sound_if_no_flag(m, SOUND_ACTION_THROW, MARIO_ACTION_SOUND_PLAYED);
    queue_rumble_data_mario(m, 3, 50);
  elseif m.forwardVel < 0 then
    mario_set_forward_vel(m, m.forwardVel + 2)
  end

  perform_ground_step(m);
  set_character_animation(m, CHAR_ANIM_THROW_LIGHT_OBJECT);
  m.marioObj.header.gfx.animInfo.animFrame = m.marioObj.header.gfx.animInfo.animFrame + 1
  if (is_anim_past_end(m) ~= 0) then
    set_mario_action(m, ACT_IDLE, 0);
  end
  return 0;
end

function act_air_throw_custom(m)
  if (not m) then return 0 end
  m.actionTimer = m.actionTimer + 1
  if (m.actionTimer == 2) then
    gCelesteStates[m.playerIndex].regrabDelay = REGRAB_DELAY
    if m.playerIndex == 0 then
      justThrownObject = m.heldObj
    end
    mario_throw_held_object(m);
    m.forwardVel = m.forwardVel - 20;
  end

  play_character_sound_if_no_flag(m, CHAR_SOUND_WAH2, MARIO_MARIO_SOUND_PLAYED);
  set_character_animation(m, CHAR_ANIM_THROW_LIGHT_OBJECT);
  m.marioObj.header.gfx.animInfo.animFrame = m.marioObj.header.gfx.animInfo.animFrame + 1
  update_air_without_turn(m);

  local result = perform_air_step(m, 0)
  if result == AIR_STEP_LANDED then
    if (check_fall_damage_or_get_stuck(m, ACT_HARD_BACKWARD_GROUND_KB) == 0) then
      m.action = ACT_THROWING_CUSTOM;
    end
  elseif result == AIR_STEP_HIT_WALL then
    mario_set_forward_vel(m, 0.0);
  elseif result == AIR_STEP_HIT_LAVA_WALL then
    lava_boost_on_wall(m);
  end

  return 0;
end

-- jump out of dash
---@param m MarioState
function jump_from_dash(m, water)
  local c = gCelesteStates[m.playerIndex]
  local new_vel = SUPER_VELOCITY
  if c.fragmentDash then
    c.demoDash = true
  end
  if c.demoDash then
    play_celeste_sound("hyper", m)
    new_vel = HYPER_VELOCITY
  else
    play_celeste_sound("super", m)
  end

  -- adjust direction (allows for reverses, etc.)
  if not c.fragmentDash then
    m.faceAngle.y = m.intendedYaw
  end

  c.jumpFromDash = false
  m.forwardVel = 35 -- make sure jump heights are consistent
  if water then
    set_jumping_action(m, ACT_METAL_WATER_JUMP, 0)
  elseif gGlobalSyncTable.nerfMoveset then
    if c.demoDash and m.flags & MARIO_WING_CAP ~= 0 then
      -- Allow flight by performing a Hyper
      m.faceAngle.x = 0
      set_jumping_action(m, ACT_FLYING_TRIPLE_JUMP, 0)
    else
      set_jumping_action(m, ACT_JUMP, 0)
    end
  elseif (m.input & INPUT_Z_DOWN) ~= 0 then
    set_jumping_action(m, ACT_LONG_JUMP, 0)
    new_vel = new_vel + LONG_DASH_ADD
  elseif c.jumpCount < 1 then
    set_jumping_action(m, ACT_JUMP, 0)
  elseif c.jumpCount < 2 then
    set_jumping_action(m, ACT_DOUBLE_JUMP, 0)
  elseif m.flags & MARIO_WING_CAP ~= 0 then
    m.faceAngle.x = 0
    set_jumping_action(m, ACT_FLYING_TRIPLE_JUMP, 0)
  elseif m.specialTripleJump ~= 0 then
    m.vel.y = 69
    set_jumping_action(m, ACT_SPECIAL_TRIPLE_JUMP, 0)
  else
    set_jumping_action(m, ACT_TRIPLE_JUMP, 0)
  end

  if c.demoDash then
    m.vel.y = m.vel.y * HYPER_DAMP
  end

  c.jumpFromDash = true
  c.spawnRingTimer = 30
  mario_set_forward_vel(m, new_vel)
  return 1
end

-- allow adjusting slightly during a dash (more for super dashes)
function dash_adjust(m, inWater)
  if m.input & INPUT_NONZERO_ANALOG ~= 0 then
    local intendedDYaw = m.intendedYaw - m.faceAngle.y
    local intendedMag = m.intendedMag / 32
    
    local sidewaysSpeed = intendedMag * sins(intendedDYaw) * 10
    if not inWater then
      local prevForwardVel = m.forwardVel
      m.forwardVel = m.forwardVel + intendedMag * coss(intendedDYaw) * 3
      if prevForwardVel < m.forwardVel and not gCelesteStates[m.playerIndex].vertDash then
        m.forwardVel = prevForwardVel
      end
      m.slideVelX = m.forwardVel * sins(m.faceAngle.y)
      m.slideVelZ = m.forwardVel * coss(m.faceAngle.y)
    else
      m.slideVelX = m.vel.x
      m.slideVelZ = m.vel.z
      sidewaysSpeed = sidewaysSpeed / 2
    end
    -- allow turning in super dash only
    if gGlobalSyncTable.superDash then
      m.faceAngle.y = m.faceAngle.y + 512 * sins(intendedDYaw) * intendedMag
      if inWater then
        m.slideVelX = m.forwardVel * sins(m.faceAngle.y) * coss(m.faceAngle.x)
        m.slideVelZ = m.forwardVel * coss(m.faceAngle.y) * coss(m.faceAngle.x)
      end
    else
      m.slideVelX = m.slideVelX + sidewaysSpeed * sins(m.faceAngle.y + 0x4000);
      m.slideVelZ = m.slideVelZ + sidewaysSpeed * coss(m.faceAngle.y + 0x4000)
    end
    m.vel.x = m.slideVelX
    m.vel.z = m.slideVelZ
  end
end

-- adjust up and down during super dash (swimming uses its own function)
function super_vertical_adjust(m, c)
  if gGlobalSyncTable.superDash and not c.fragmentDash then
    -- get pitch and vector size so we can do better math
    local pitch = calculate_pitch({x = 0, y = 0, z = 0}, {x = m.forwardVel, y = m.vel.y, z = 0})
    local velocity = math.sqrt(m.forwardVel ^ 2 + m.vel.y ^ 2)

    -- set goal angle based on inputs
    local goalPitch = 0
    if ((m.controller.buttonDown & Z_TRIG) ~= 0 and (m.controller.buttonDown & U_JPAD) == 0) or (m.controller.buttonDown & D_JPAD) ~= 0 then
      goalPitch = -0x2000
    elseif m.controller.buttonDown & (A_BUTTON | U_JPAD) ~= 0 then
      goalPitch = 0x2000
    end
    if m.input & INPUT_NONZERO_ANALOG == 0 then
      goalPitch = goalPitch * 2 -- straight up, down, or forward
    end

    if pitch ~= goalPitch and (goalPitch ~= 0 or m.input & INPUT_NONZERO_ANALOG ~= 0) then
      pitch = approach_s16_symmetric(pitch, goalPitch, 0x200)
      m.forwardVel = velocity * coss(pitch)
      m.vel.y = velocity * sins(pitch)
      c.vertDash = (pitch < 0x4800 and pitch > 0x3800) or (pitch > -0x4800 and pitch < -0x3800)
      m.vel.x = m.forwardVel * sins(m.faceAngle.y)
      m.vel.z = m.forwardVel * coss(m.faceAngle.y)
    end
    return true
  end
  return false
end

-- hit underwater switches and other stuff
function handle_dash_water_interacts(m, hitWall)
  if m.playerIndex == 0 and m.vel.y < 0 and m.floor and m.floor.object and (m.pos.y - m.floorHeight < 10) then
    local o = m.floor.object
    if (m.floor.type == SURFACE_SWITCH or obj_has_behavior_id(o, id_bhvBlueCoinSwitch) ~= 0) and o.oAction == 0 then
      o.oAction = 1
      if m.floor.type ~= SURFACE_SWITCH then
        -- Recede at a rate of 20 units/frame.
        o.oVelY = -20
        -- Set gravity to 0 so it doesn't accelerate when receding.
        o.oGravity = 0

        cur_obj_play_sound_2(SOUND_GENERAL_SWITCH_DOOR_OPEN)
      end
      if o.oSyncID ~= 0 then
        network_send_object(o, true)
      end
    end
  end

  if hitWall then
    local nextPos = {x = m.pos.x + m.vel.x, y = m.pos.y + m.vel.y, z = m.pos.z + m.vel.z}
    local wcd = collision_get_temp_wall_collision_data()
    resolve_and_return_wall_collisions_data(nextPos, 10, 110, wcd)
    mario_update_wall(m, wcd)
    local o = m.wall and m.wall.object
    if o and o.oInteractType == INTERACT_BREAKABLE then
      interact_breakable(m, INT_PUNCH, o)
      return true
    end
  end
end

-- return the value decreased by 1, or 0 if it is 0 or less
function decrease_until_zero(value)
  if value <= 1 then return 0 end
  return value - 1
end

-- check if this surface is a wall
function surface_is_wall(col)
  return (col and col.surface and col.surface.normal.y > -0.01 and col.surface.normal.y < 0.01)
end

-- dash particle effect
---@param o Object
function dash_particle_init(o)
  local index = network_local_index_from_global(o.globalPlayerIndex) or 255
  if index == 255 then
    obj_mark_for_deletion(o)
    return
  end
  local m = gMarioStates[index]
  o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
  o.oOpacity = 0

  o.oPosX = m.marioObj.header.gfx.pos.x
  o.oPosY = m.marioObj.header.gfx.pos.y
  o.oPosZ = m.marioObj.header.gfx.pos.z
  o.oFaceAnglePitch = m.marioObj.header.gfx.angle.x
  o.oFaceAngleYaw = m.marioObj.header.gfx.angle.y
  o.oFaceAngleRoll = m.marioObj.header.gfx.angle.z
  o.header.gfx.animInfo.animID = m.marioObj.header.gfx.animInfo.animID
  o.header.gfx.animInfo.curAnim = m.marioObj.header.gfx.animInfo.curAnim
  o.header.gfx.animInfo.animYTrans = m.unkB0
  o.header.gfx.animInfo.animAccel = 0            --m.marioObj.header.gfx.animInfo.animAccel
  o.header.gfx.animInfo.animFrame = m.marioObj.header.gfx.animInfo.animFrame
  o.header.gfx.animInfo.animTimer = 0            --m.marioObj.header.gfx.animInfo.animTimer
  o.header.gfx.animInfo.animFrameAccelAssist = 0 --m.marioObj.header.gfx.animInfo.animFrameAccelAssist
  o.header.gfx.scale.x = m.marioObj.header.gfx.scale.x
  o.header.gfx.scale.y = m.marioObj.header.gfx.scale.y
  o.header.gfx.scale.z = m.marioObj.header.gfx.scale.z
end

function dash_particle_loop(o)
  o.oAnimState = 1 -- one new line here
  o.oOpacity = 200 - (o.oTimer * 200) // DASH_TIMER_MAX
  o.header.gfx.animInfo.animFrame = o.header.gfx.animInfo.animFrame - 1
  if o.oTimer >= DASH_TIMER_MAX then
    obj_mark_for_deletion(o)
  end
end

id_bhvDashParticle = hook_behavior(nil, OBJ_LIST_UNIMPORTANT, true, dash_particle_init, dash_particle_loop,
  "bhvDashParticle")

-- ring particle effect
---@param o Object
function ring_particle_init(o)
  local index = network_local_index_from_global(o.globalPlayerIndex) or 255
  if index == 255 then
    obj_mark_for_deletion(o)
    return
  end
  local m = gMarioStates[index]
  o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
  o.oOpacity = 200

  o.oPosX = m.marioObj.header.gfx.pos.x
  o.oPosY = m.marioObj.header.gfx.pos.y
  o.oPosZ = m.marioObj.header.gfx.pos.z
  local pos1, pos2 = {x = o.oPosX, y = o.oPosY, z = o.oPosZ}, {x = o.oPosX + m.vel.x, y = o.oPosY + m.vel.y, z = o.oPosZ + m.vel.z}
  o.oFaceAnglePitch, o.oFaceAngleYaw = calculate_pitch(pos1, pos2), calculate_yaw(pos1, pos2) + 0x8000
  o.oFaceAngleRoll = 0
  cur_obj_scale(0.25)
end

function ring_particle_loop(o)
  o.oOpacity = o.oOpacity - 10
  cur_obj_scale_over_time(0, 20, 0.25, 1)
  cur_obj_scale_over_time(1, 20, 0.25, 1)
  cur_obj_scale_over_time(2, 20, 0.25, 1)
  if o.oOpacity <= 0 then
    o.oOpacity = 0
    obj_mark_for_deletion(o)
  end
end

id_bhvRingParticle = hook_behavior(nil, OBJ_LIST_UNIMPORTANT, true, ring_particle_init, ring_particle_loop,
  "bhvRingParticle")

-- hud stamina bar
local staminaBarData = {
  prevX = 0,
  prevY = 0,
  prevScale = 0,
  prevWidth = 0,
  rendered = false,
}
function on_hud_render_behind()
  local m = gMarioStates[0]
  local c = gCelesteStates[0]
  if RENDER_BAR and (not gGlobalSyncTable.infStamina) and c.stamina and (c.stamina < MAX_STAMINA - 100 or m.action == ACT_WALL_CLIMB) then
    djui_hud_set_resolution(RESOLUTION_N64)
    local pos = { x = 0, y = 0, z = 0 }
    local out = { x = 0, y = 0, z = 0 }
    vec3f_copy(pos, m.marioBodyState.headPos);
    pos.y = pos.y + 120
    if djui_hud_world_pos_to_screen_pos(pos, out) and out.z < 0 then
      local scale = -800 / out.z * djui_hud_get_fov_coeff()
      local barWidth = 50
      local width = (c.stamina / MAX_STAMINA) * barWidth
      local x = out.x - (barWidth * scale) / 2
      local y = out.y
      if not staminaBarData.rendered then
        staminaBarData.prevX = x
        staminaBarData.prevY = y
        staminaBarData.prevScale = scale
        staminaBarData.prevWidth = width
        staminaBarData.rendered = true
      end
      djui_hud_set_color(0, 0, 0, 100)
      djui_hud_render_rect_interpolated(staminaBarData.prevX, staminaBarData.prevY,
        barWidth * staminaBarData.prevScale, 10 * staminaBarData.prevScale,
        x, y, barWidth * scale, 10 * scale)
      local color = { r = 0, g = 255, b = 0 }
      -- lerp to red when stamina is low
      if c.stamina < 1200 then
        color = lerp_color({ r = 255, g = 0, b = 0 }, color, (c.stamina / 1200))
      end
      djui_hud_set_color(color.r, color.g, color.b, 200)
      djui_hud_render_rect_interpolated(staminaBarData.prevX, staminaBarData.prevY,
        staminaBarData.prevWidth * staminaBarData.prevScale, 10 * staminaBarData.prevScale,
        x, y, width * scale, 10 * scale)
      staminaBarData.prevX = x
      staminaBarData.prevY = y
      staminaBarData.prevScale = scale
      staminaBarData.prevWidth = width
    end
  else
    staminaBarData.rendered = false
  end
end

function on_interact(m, o, type, value)
  local c = gCelesteStates[m.playerIndex]

  -- dashes will grab objects too
  if type == INTERACT_GRABBABLE and o.oInteractionSubtype & INT_SUBTYPE_NOT_GRABBABLE == 0
  and m.heldObj == nil and (c.dashTimer ~= 0 or c.jumpFromDash) and c.regrabDelay == 0 then
    if m.playerIndex ~= 0 then return end

    local isBowser = false
    if obj_has_behavior_id(o, id_bhvBowser) ~= 0 then
      isBowser = true
      local tail = obj_get_nearest_object_with_behavior_id(m.marioObj, id_bhvBowserTailAnchor)
      if not obj_check_hitbox_overlap(m.marioObj, tail) then
        return
      end
    end

    if (o.oInteractionSubtype & INT_SUBTYPE_GRABS_MARIO == 0) or m.action & ACT_FLAG_AIR == 0 then
      if o.oInteractionSubtype & INT_SUBTYPE_KICKABLE ~= 0 and m.forwardVel < 0 then
        m.forwardVel = -m.forwardVel
        o.oInteractStatus = o.oInteractStatus & ~(INT_KICK | INT_TRIP | INT_STATUS_INTERACTED | INT_STATUS_WAS_ATTACKED)
        c.dashCooldown = 0
      end
      
      if dashAction[m.action] then
        if c.vertDash then
          m.forwardVel = 0
          m.vel.y = sign(m.vel.y) * ORTHO_VELOCITY
        elseif m.vel.y ~= 0 then
          m.forwardVel = DIAG_VELOCITY
          m.vel.y = sign(m.vel.y) * DIAG_VELOCITY
        else
          m.forwardVel = ORTHO_VELOCITY
        end
      end

      c.jumpFromDash = false
      m.interactObj = o
      m.input = m.input | INPUT_INTERACT_OBJ_GRABBABLE
      if (o.oSyncID ~= 0) then
        network_send_object(o, true)
      end
      m.usedObj = m.interactObj
      mario_grab_used_object(m)
      if isBowser then
        m.marioBodyState.grabPos = GRAB_POS_BOWSER
      elseif (o.oInteractionSubtype & INT_SUBTYPE_GRABS_MARIO ~= 0) then
        m.marioBodyState.grabPos = GRAB_POS_HEAVY_OBJ
      else
        m.marioBodyState.grabPos = GRAB_POS_LIGHT_OBJ
      end

      if m.action & ACT_FLAG_METAL_WATER ~= 0 then
        set_mario_action(m, ACT_HOLD_METAL_WATER_FALLING, 1)
      elseif m.action & ACT_FLAG_WATER_OR_TEXT ~= 0 then
        if obj_has_behavior_id(o, id_bhvKoopaShellUnderwater) ~= 0 then
          if (m.playerIndex == 0) then play_shell_music() end
          set_mario_action(m, ACT_WATER_SHELL_SWIMMING, 0)
        else
          set_mario_action(m, ACT_HOLD_WATER_ACTION_END, 1)
        end
      elseif isBowser then
        m.faceAngle.y = obj_angle_to_object(m.marioObj, o)
        set_mario_action(m, ACT_PICKING_UP_BOWSER, 0)
      elseif o.oInteractionSubtype & INT_SUBTYPE_GRABS_MARIO == 0 then
        m.prevAction = m.action
        m.action = ACT_PICKING_UP_STALL
      else
        set_mario_action(m, ACT_PICKING_UP, 1)
        play_character_sound_if_no_flag(m, CHAR_SOUND_HRMM, MARIO_MARIO_SOUND_PLAYED);
        m.actionState = 1
      end
    end
  elseif c.dashTimer ~= 0 and m.forwardVel < 0 and o.oInteractStatus & INT_STATUS_ATTACK_MASK == ATTACK_KICK_OR_TRIP then -- Check if we've bumped into an object
    c.dashCooldown = DASH_COOLDOWN -- set cooldown to make pvp less OP
    if m.action & ACT_FLAG_WATER_OR_TEXT == 0 then
      -- Switch to air action and do a little jump (like when you break a wall in celeste)
      m.forwardVel = -30
      m.vel.y = 40
      c.jumpFromDash = true
      if m.action & ACT_FLAG_METAL_WATER == 0 then
        set_mario_action(m, ACT_FREEFALL, 0)
      else
        set_mario_action(m, ACT_METAL_WATER_FALLING, 0)
      end
    end
  end
end

function on_pvp_attack(attacker, victim, interaction)
  if attacker.playerIndex ~= 0 then return end

  local m = attacker
  local c = gCelesteStates[m.playerIndex]
  if c.movesetDisabled then return end
  
  if c.dashTimer ~= 0 and m.forwardVel < 0 then
    -- Switch to air action and do a little jump (like when you break a wall in celeste)
    m.forwardVel = -30
    m.vel.y = 40
    c.jumpFromDash = true
    if m.action & ACT_FLAG_METAL_WATER == 0 then
      set_mario_action(m, ACT_FREEFALL, 0)
    else
      set_mario_action(m, ACT_METAL_WATER_FALLING, 0)
    end
  end
end

-- reset all values on warp
function on_warp()
  for i=0,MAX_PLAYERS-1 do
    reset_celeste_fields(i)
  end
end

-- returns a new color using linear interpretation
function lerp_color(c1, c2, t)
  if t > 1 then
    t = 1
  elseif t < 0 then
    t = 0
  end
  local color = { r = 0, g = 0, b = 0 }
  color.r = math.floor(c1.r + (c2.r - c1.r) * t)
  color.g = math.floor(c1.g + (c2.g - c1.g) * t)
  color.b = math.floor(c1.b + (c2.b - c1.b) * t)
  return color
end

-- compares the r, g, and b values of each color and returns TRUE if all three are identical
function compare_color(c1, c2)
  return (c1.r == c2.r and c1.g == c2.g and c1.b == c2.b)
end

-- returns c1, unless origC is similar to c1, in which case it picks c2
function pick_color_or_alt_if_similar(origC, c1, c2)
  if colors_are_similar(origC, c1) then
    return c2
  end
  return c1
end

-- same as above, but with a third color
function pick_color_or_alt_if_similar_x2(origC, c1, c2, c3)
  if colors_are_similar(origC, c1) then
    if colors_are_similar(origC, c2) then
      return c3
    else
      return c2
    end
  end
  return c1
end

-- same as above, but it also checks origC2
function pick_color_or_alt_if_either_are_similar_x2(origC, origC2, c1, c2, c3)
  if colors_are_similar(origC, c1) or colors_are_similar(origC2, c1) then
    if colors_are_similar(origC, c2) or colors_are_similar(origC2, c2) then
      return c3
    else
      return c2
    end
  end
  return c1
end

-- returns true if r, g, and b are all within 50 for each color
function colors_are_similar(c1, c2)
  return (math.abs(c1.r - c2.r) < 50 and math.abs(c1.g - c2.g) < 50 and math.abs(c1.b - c2.b) < 50)
end

-- Converts string into a table using a determiner (but stop splitting after a certain amount)
function split(s, delimiter, limit_)
  local limit = limit_ or 999
  local result = {}
  local finalmatch = ""
  local i = 0
  for match in (s):gmatch(string.format("[^%s]+", delimiter)) do
    --djui_chat_message_create(match)
    i = i + 1
    if i >= limit then
      finalmatch = finalmatch .. match .. delimiter
    else
      table.insert(result, match)
    end
  end
  if i >= limit then
    finalmatch = string.sub(finalmatch, 1, string.len(finalmatch) - string.len(delimiter))
    table.insert(result, finalmatch)
  end
  return result
end

-- removes color string
function remove_color(text, get_color)
  local start = text:find("\\")
  local next = 1
  while (next) and (start) do
    start = text:find("\\")
    if start then
      next = text:find("\\", start + 1)
      if not next then
        next = text:len() + 1
      end

      if get_color then
        local color = text:sub(start, next)
        local render = text:sub(1, start - 1)
        text = text:sub(next + 1)
        return text, color, render
      else
        text = text:sub(1, start - 1) .. text:sub(next + 1)
      end
    end
  end
  return text
end

-- converts hex string to RGB values
function convert_color(text)
  if text:sub(2, 2) ~= "#" then
    return nil
  end
  text = text:sub(3, -2)
  local rstring, gstring, bstring = "", "", ""
  if text:len() ~= 3 and text:len() ~= 6 then return 255, 255, 255, 255 end
  if text:len() == 6 then
    rstring = text:sub(1, 2) or "ff"
    gstring = text:sub(3, 4) or "ff"
    bstring = text:sub(5, 6) or "ff"
  else
    rstring = text:sub(1, 1) .. text:sub(1, 1)
    gstring = text:sub(2, 2) .. text:sub(2, 2)
    bstring = text:sub(3, 3) .. text:sub(3, 3)
  end
  local r = tonumber("0x" .. rstring) or 255
  local g = tonumber("0x" .. gstring) or 255
  local b = tonumber("0x" .. bstring) or 255
  return r, g, b, 255 -- alpha is no longer writeable
end

-- prints text on the screen... with color!
function djui_hud_print_text_with_color(text, x, y, scale, alpha)
  --djui_hud_set_color(255, 255, 255, alpha or 255)
  local space = 0
  local color = ""
  local render = ""
  text, color, render = remove_color(text, true)
  while render do
      local r, g, b, a = convert_color(color)
      djui_hud_print_text(render, x + space, y, scale);
      if r then djui_hud_set_color(r, g, b, alpha or a) end
      space = space + djui_hud_measure_text(render) * scale
      text, color, render = remove_color(text, true)
  end
  djui_hud_print_text(text, x + space, y, scale);
end

function play_celeste_sound(soundName, m, volume_)
  -- don't play sounds for inactive players
  if m.playerIndex ~= 0 and is_player_active(m) == 0 then
    return
  end

  local c = gCelesteStates[m.playerIndex]
  local volume = volume_ or 0.5
  local sound = sfx[soundName]
  if sound ~= nil then
    audio_sample_play(sound, m.pos, volume)
    local soundNumber = 0
    if c.lastPlayedSound == soundName then
      soundNumber = (c.lastPlayedRepeat or -1) + 1
      if soundNumber >= 65536 then -- failsafe
        soundNumber = 0
      end
    end
    c.lastPlayedSound = soundName
    c.lastPlayedVolume = volume
    c.lastPlayedRepeat = soundNumber
  else
    log_to_console("Couldn't play " .. soundName .. "! Is the file missing?")
  end
end

-- from extended moveset
function limit_angle(a)
  return (a + 0x8000) % 0x10000 - 0x8000
end

-- gets sign of number (positive for 0)
function sign(num)
  if num < 0 then return -1 end
  return 1
end

--hook_event(HOOK_MARIO_UPDATE, madeline_update) -- hook later
hook_event(HOOK_ON_WARP, on_warp) -- Run for all players
hook_event(HOOK_UPDATE, update_thrown_object) -- Run for all players

hook_mario_action(ACT_GROUND_DASH, act_ground_dash, INT_KICK)
hook_mario_action(ACT_AIR_DASH, { every_frame = act_air_dash, gravity = gravity_dash }, INT_KICK)
hook_mario_action(ACT_WATER_DASH, act_water_dash, INT_PUNCH)
hook_mario_action(ACT_METAL_WATER_DASH, act_metal_water_dash, INT_PUNCH)
hook_mario_action(ACT_METAL_GROUND_WATER_DASH, act_metal_ground_water_dash, INT_PUNCH)
hook_mario_action(ACT_WALL_SLIDE, act_wall_slide)
hook_mario_action(ACT_WALL_CLIMB, act_wall_climb)
hook_mario_action(ACT_CUSTOM_TURN, act_custom_turn)
hook_mario_action(ACT_PICKING_UP_STALL, act_picking_up_stall)
hook_mario_action(ACT_THROWING_CUSTOM, act_throwing_custom)
hook_mario_action(ACT_AIR_THROW_CUSTOM, act_air_throw_custom)

-- reduce dash count if the global count is reduced
function on_dash_count_change(tag, oldVal, newVal)
  if oldVal == nil or newVal == nil then return end
  if oldVal > newVal then
    for i = 0, MAX_PLAYERS - 1 do
      local c = gCelesteStates[i]
      if c.dashes > newVal then
        c.dashes = newVal
      end
    end
  end
end

hook_on_sync_table_change(gGlobalSyncTable, "dashCount", "dashChange", on_dash_count_change)

-- Add MANY options to the CS menu
function host_locked()
  if not network_is_server() then
    return "Host Only"
  end
end

local OPTION_DASH_BIND = charSelect.add_option("Dash Bind", 0, 2, {"X", "Y", "L"}, {"Use this button to dash"}, true)
local OPTION_FRAGMENT_DASH = charSelect.add_option("Celeste 64 Style Dash", 0, nil, nil, {"Simplified dash controls", "based on Celeste 64"}, true)
local OPTION_STAMINA_BAR = charSelect.add_option("Show stamina bar", 0, nil, nil, {"Show stamina bar", "when climbing"}, true)
local OPTION_REL_CLIMB = charSelect.add_option("Climb rel. to camera", 0, nil, nil, {"Climb towards a wall to", "climb upwards rather", "than pressing UP"}, true)
local OPTION_BUFFER_JUMP = charSelect.add_option("Buffer actions", 1, nil, nil, {"Buffer Jumps, rollouts,", "and dashes"}, true)
local OPTION_COYOTE_TIME = charSelect.add_option("Coyote time", 1, nil, nil, {"Allow jumping shortly", "after falling off of", "a platform"}, true)

-- Host options
local OPTION_NEUTRAL_JUMPS = charSelect.add_option("Allow neutral jumps", 0, nil, nil, {"Allow scaling walls", "using an advanced Celeste", "technique (Host Only)"}, true)
charSelect.get_option(OPTION_NEUTRAL_JUMPS).lock = host_locked
local OPTION_DASH_COUNT = charSelect.add_option("Dash Count", 1, 10, {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}, {"Set the amount of dashes", "Madeline can perform", "(Host Only)"}, true)
charSelect.get_option(OPTION_DASH_COUNT).lock = host_locked
local OPTION_INFINITE_STAMINA = charSelect.add_option("Infinite stamina", 0, nil, nil, {"Removes stamina when", "climbing (Host Only)"}, true)
charSelect.get_option(OPTION_INFINITE_STAMINA).lock = host_locked
local OPTION_SUPER_DASH = charSelect.add_option("Super Dash", 0, nil, nil, {"More powerful dash that", "can be adjusted mid-air", "(Host Only)"}, true)
charSelect.get_option(OPTION_SUPER_DASH).lock = host_locked
local OPTION_NERF_MOVESET = charSelect.add_option("Nerf Madeline", 1, nil, nil, {"Madeline loses access", "to many vanilla moves", "(Host Only)"}, true)
charSelect.get_option(OPTION_NERF_MOVESET).lock = host_locked

function update_cs_options()
  local c = gCelesteStates[0]
  c.dashBind = charSelect.get_options_status(OPTION_DASH_BIND) or 0
  c.fragmentDash = (charSelect.get_options_status(OPTION_FRAGMENT_DASH) == 1)
  RENDER_BAR = (charSelect.get_options_status(OPTION_STAMINA_BAR) == 1)
  c.relClimb = (charSelect.get_options_status(OPTION_REL_CLIMB) == 1)
  c.allowBufferJump = (charSelect.get_options_status(OPTION_BUFFER_JUMP) == 1)
  c.allowCoyoteTime = (charSelect.get_options_status(OPTION_COYOTE_TIME) == 1)

  if network_is_server() then
    gGlobalSyncTable.allowNeutral = (charSelect.get_options_status(OPTION_NEUTRAL_JUMPS) == 1)
    gGlobalSyncTable.dashCount = charSelect.get_options_status(OPTION_DASH_COUNT)
    gGlobalSyncTable.infStamina = (charSelect.get_options_status(OPTION_INFINITE_STAMINA) == 1)
    gGlobalSyncTable.superDash = (charSelect.get_options_status(OPTION_SUPER_DASH) == 1)
    gGlobalSyncTable.nerfMoveset = (charSelect.get_options_status(OPTION_NERF_MOVESET) == 1)
  end
end
hook_event(HOOK_UPDATE, update_cs_options)

-- hook some functions last (charact select support)
function on_mods_loaded()
  hook_event(HOOK_MARIO_UPDATE, madeline_update) -- Run for all players

  -- Moveset hooks
  hook_celeste_moveset(HOOK_BEFORE_MARIO_UPDATE, before_madeline_update)
  hook_celeste_moveset(HOOK_BEFORE_SET_MARIO_ACTION, before_set_action)
  hook_celeste_moveset(HOOK_ON_SET_MARIO_ACTION, on_set_action)
  hook_celeste_moveset(HOOK_ON_INTERACT, on_interact)
  hook_celeste_moveset(HOOK_ON_PVP_ATTACK, on_pvp_attack)
  hook_celeste_moveset(HOOK_ON_HUD_RENDER_BEHIND, on_hud_render_behind)
  hook_celeste_moveset(HOOK_BEFORE_MARIO_UPDATE, attempt_early_dash)
end

hook_event(HOOK_ON_MODS_LOADED, on_mods_loaded)
