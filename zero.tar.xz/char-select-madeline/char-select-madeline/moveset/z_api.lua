-- Same API that the base celeste moveset also has.

_G.celesteOn = true
_G.celesteMadeline = true
_G.celeste = {
    moveset_enabled = celeste_moveset_enabled,

    fragment_enabled = function(index)
        return gCelesteStates[index].fragmentDash or false
    end,

    inf_stamina_enabled = function()
        return gGlobalSyncTable.infStamina or false
    end,

    super_enabled = function()
        return gGlobalSyncTable.superDash or false
    end,

    nerf_moveset_enabled = function()
        return gGlobalSyncTable.nerfMoveset or false
    end,

    get_max_dashes = function()
        return gGlobalSyncTable.dashCount or 1
    end,

    get_dashes = function(index)
        return gCelesteStates[index].dashes or 0
    end,

    set_dashes = function(index, dashes)
        gCelesteStates[index].dashes = dashes
    end,

    get_stamina = function(index)
        return gCelesteStates[index].stamina or MAX_STAMINA
    end,

    set_stamina = function(index, stamina)
        gCelesteStates[index].stamina = stamina
    end,

    -- Always true in this version
    do_hair_style = function(index)
        return true
    end,

    -- see moveset.lua for all fields
    get_field = function(index, field)
        return gCelesteStates[index][field]
    end,

    -- see moveset.lua for all fields
    set_field = function(index, field, value)
        gCelesteStates[index][field] = value
    end,

    get_celeste_state = function(index)
        return gCelesteStates[index]
    end,

    is_dash_allowed = function(index)
        local m = gMarioStates[index]
        local c = gCelesteStates[index]
        local DASH_KEY = X_BUTTON
        if c.dashBind == 1 then
            DASH_KEY = Y_BUTTON
        elseif c.dashBind == 2 then
            DASH_KEY = L_TRIG
        end
        return c.dashes > 0 and m.health > 0xFF and (c.dashCooldown == 0)
        and ((m.controller.buttonPressed & DASH_KEY) ~= 0 or c.dashBuffer ~= 0)
        and (m.action & (ACT_GROUP_CUTSCENE | ACT_FLAG_INTANGIBLE | ACT_FLAG_INVULNERABLE | ACT_FLAG_RIDING_SHELL)) == 0 and m.heldObj == nil
        and dashBanned[m.action] == nil
    end,

    is_dashing = function(index)
        local m = gMarioStates[index]
        return (dashAction[m.action] ~= nil)
    end,

    refill_dash = refill_dash, -- moveset.lua

    add_dash_banned_action = function(action)
        dashBanned[action] = 1
    end,

    jump_from_dash = jump_from_dash, -- moveset.lua

    setup_dash_settings = function(charNum, normalModel, hairModel, forceHair)
        -- Do nothing in this mod, since only Madeline uses the moveset anyway
    end,
}