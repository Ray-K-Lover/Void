--- bytestring packets for player data ---

-- values which are synced
SYNC_CEL_FIELDS = {
  "dashes",
  "dashTimer",
  "dashAttackTimer",
  "dashCooldown",
  "stamina",
  "spawnRingTimer",
  "climbYaw",
  "bunnyHop",
  "jumpFromDash",
  "climbXMultiplier",
  -- "hairStyle", -- Always true here
  "dashBind",
  "fragmentDash",
  "relClimb",
  "allowBufferJump",
  "allowCoyoteTime",
  -- "movesetDisabled", -- Using CS field instead
  "lastPlayedSound",
  "lastPlayedVolume",
  "lastPlayedRepeat",
}

-- Unlisted use unsigned byte
SYNC_CEL_FIELD_TYPE = {
    ["stamina"] = "<h",
    ["climbYaw"] = "<i4", -- s32
    ["climbXMultiplier"] = "<b",
    ["lastPlayedSound"] = "<z",
    ["lastPlayedVolume"] = "<f", -- check with OSes
    ["lastPlayedRepeat"] = "<H",
}

function on_byte_packet_cel_state(bytestring)
    local offset = 1
    local function unpack(fmt)
        local value
        value, offset = string.unpack(fmt, bytestring, offset)
        return value
    end

    local packet_id = unpack("<B") -- needed to offset
    local gIndex = unpack("<B") or 255
    if gIndex == 255 then return end
    
    local index = network_local_index_from_global(gIndex)
    local c = gCelesteStates[index]
    if index == 0 then return end -- failsafe for receiving our own, somehow

    local prevSound, prevRepeat = c.lastPlayedSound, c.lastPlayedRepeat

    for a,field in ipairs(SYNC_CEL_FIELDS) do
        local byteType = SYNC_CEL_FIELD_TYPE[field] or "<B"
        local value = unpack(byteType)

        if type(c[field]) == "boolean" then
            c[field] = (value and value ~= 0)
        elseif type(c[field]) == type(value) then
            c[field] = value
        end
    end

    -- play sound if it hasn't been played yet for us
    if c.lastPlayedSound ~= "" and (prevSound ~= c.lastPlayedSound or prevRepeat < c.lastPlayedRepeat) and c.validForPlaySound then
        --log_to_console(tostring(prevSound)..tostring(prevRepeat)..tostring(c.lastPlayedSound)..tostring(c.lastPlayedRepeat))
        local newSound = c.lastPlayedSound
        c.lastPlayedSound, c.lastPlayedRepeat = prevSound, prevRepeat
        play_celeste_sound(newSound, gMarioStates[index], c.lastPlayedVolume)
    end
    c.validForPlaySound = true
end

BYTE_PACKET_CEL_STATE = 0
local sBytePacketTable = {
    [BYTE_PACKET_CEL_STATE] = on_byte_packet_cel_state,
}
function on_packet_bytestring_receive(bytestring)
    local packet_id = string.unpack("<B", bytestring, 1)
    if sBytePacketTable[packet_id] ~= nil then
        sBytePacketTable[packet_id](bytestring)
    end
end

hook_event(HOOK_ON_PACKET_BYTESTRING_RECEIVE, on_packet_bytestring_receive)

-- sends bytestring packet to every player in our current area (does not run for ourselves)
function network_send_bytestring_to_all_in_area(reliable, bytestring)
    for i=1,MAX_PLAYERS-1 do
        local np = gNetworkPlayers[i]
        if np.connected and (np.currLevelNum == gNetworkPlayers[0].currLevelNum and np.currAreaIndex == gNetworkPlayers[0].currAreaIndex and np.currActNum == gNetworkPlayers[0].currActNum) and np.currLevelSyncValid and np.currAreaSyncValid then
            network_send_bytestring_to(i, reliable, bytestring)
        end
    end
end