-- name: [CS] Pingu
-- description: NOOT NOOT\\#ff7777\\This Pack requires Character Select\nto use as a Library!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation
]]

local TEXT_MOD_NAME = "Pingu"
-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local MODEL_PINGU = smlua_model_util_get_id("pingu_geo")

local PINGU_ICON = get_texture_info("pingu_icon")
	  
      PINGU_GRAFFITTI = get_texture_info("pingu_graffiti")
	
-- All Located in "sound" Name them whatever you want. Remember to include the .ogg extension
local VOICETABLE_PINGU = {
    [CHAR_SOUND_OKEY_DOKEY] = 'nootnoot1.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] = 'nootnoot1.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] = 'punch.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] = 'punch.ogg', -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] = 'punch.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] = {'punch.ogg', 'punch.ogg', 'punch.ogg'}, -- First/Second jump sounds
	[CHAR_SOUND_HOOHOO] = 'punch.ogg', -- Third jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'jump3.ogg', 'jump3.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] = 'Silent.ogg', -- Wall bonk
	[CHAR_SOUND_UH2] = 'Silent.ogg', -- Landing after long jump
	[CHAR_SOUND_UH2_2] = 'Silent.ogg', -- Same sound as UH2; jumping onto ledge
	[CHAR_SOUND_HAHA] = 'wahwah.ogg', -- Landing triple jump
	[CHAR_SOUND_YAHOO] = 'punch.ogg', -- Long jump
	[CHAR_SOUND_DOH] = 'Silent.ogg', -- Long jump wall bonk
	[CHAR_SOUND_WHOA] = 'Silent.ogg', -- Grabbing ledge
	[CHAR_SOUND_EEUH] = 'Silent.ogg', -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] = 'nootnoot2.ogg', -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] = 'punch.ogg', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] = 'Silent.ogg', 
	[CHAR_SOUND_HRMM] = 'Silent.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] = 'nootnoot2.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] = 'nootnoot1.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] = 'booted.ogg', -- Damaged
	[CHAR_SOUND_PANTING] = 'Silent.ogg', -- Low health
	[CHAR_SOUND_ON_FIRE] = 'nootnoot2.ogg', -- Burned
--SLEEP SOUNDS
	[CHAR_SOUND_IMA_TIRED] = 'Silent.ogg', -- Mario feeling tired
	[CHAR_SOUND_YAWNING] = 'Silent.ogg', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] = 'Silent.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] = 'Silent.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] = 'Silent.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] = 'Silent.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] = 'Silent.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] = 'Silent.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] = 'booted.ogg', -- Dying from damage
	[CHAR_SOUND_DROWNING] = 'booted.ogg', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] = 'booted.ogg' -- Booted out of level
}

-- All Located in "actors"
local CAPTABLE_PINGU = {
    normal = smlua_model_util_get_id("pingu_cap_geo"),
    wing = smlua_model_util_get_id("pingu_wcap_geo"),
    metal = smlua_model_util_get_id("pingu_mcap_geo"),
}

local CSloaded = false
local function on_character_select_load()
    CT_PINGU = _G.charSelect.character_add(
        "Pingu",                                                                                                                                                                -- Character Name
        "NOOT NOOT",                                                                                                                                                      -- Description
        "Tails Gamer",                                                                                                                                                                   -- Credits
        "646464",                                                                                                                                                                    -- Menu Color
        MODEL_PINGU,                                                                                                                                                           -- Character Model
        CT_PINGU,                                                                                                                                                                -- Override Character
        PINGU_ICON                                                                                                                                                                -- Life Icon
   )

	--CAPS
    _G.charSelect.character_add_caps(MODEL_PINGU, CAPTABLE_PINGU)
	
	--VOICES
    _G.charSelect.character_add_voice(MODEL_PINGU, VOICETABLE_PINGU)
	
	--GRAFFITI
	_G.charSelect.character_add_graffiti(CT_PINGU, PINGU_GRAFFITTI)
	
    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_PINGU then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_PINGU then return _G.charSelect.voice.snore(m) end
end


hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)