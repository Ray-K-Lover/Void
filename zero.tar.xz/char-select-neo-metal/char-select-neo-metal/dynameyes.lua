if not _G.charSelectExists then return end

mikueyes = mod_storage_load_bool("mikueyes")

local function s16(x)
    x = (math.floor(x) & 0xFFFF)
    if x >= 32768 then return x - 65536 end
    return x
end

local function dynameyes(m)
    if mikueyes then
        local charNum = _G.charSelect.character_get_current_number()
        if charNum == CT_NEOMETAL then
            if (m.marioBodyState.eyeState ~= 8) then
                if (abs_angle_diff(m.faceAngle.y, m.intendedYaw) > 500 and m.action & ACT_FLAG_AIR == 0) then
                    if (m.action & ACT_FLAG_SWIMMING_OR_FLYING == 0) then
                        if s16(m.intendedYaw - m.faceAngle.y) > 0 then
                            m.marioBodyState.eyeState = 5
                        else
                            m.marioBodyState.eyeState = 4
                        end
                        if m.vel.y > 10 then
                            m.marioBodyState.eyeState = 6
                        end
                        
                        if m.action ~= ACT_IDLE then
                            if m.vel.y < -25 then
                                m.marioBodyState.eyeState = 7
                            end
                        end
                    else
                        if s16(m.intendedYaw - m.faceAngle.y) > 0 then
                            m.marioBodyState.eyeState = 4
                        else
                            m.marioBodyState.eyeState = 5
                        end
                    end
                else
                    if m.vel.y > 10 then
                        m.marioBodyState.eyeState = 6
                    end
                end

                if m.action ~= ACT_JUMBO_STAR_CUTSCENE and m.action ~= ACT_IDLE then
                    if m.vel.y < -25 then
                        m.marioBodyState.eyeState = 7
                    end
                end
            end
        end
    end
end

hook_event(HOOK_MARIO_UPDATE, dynameyes)

local function mikueyesToggle(index, value)
    mikueyes = value
    mod_storage_save_bool("mikueyes", value)
end

hook_mod_menu_checkbox("Dynamic Eyes", mod_storage_load_bool("mikueyes"), mikueyesToggle)

-- Code from Triple Baka Pack
-- Original Dynamic Eyes Code by Radishcatish
-- Revised Dynamic Eyes Code by Baconator
