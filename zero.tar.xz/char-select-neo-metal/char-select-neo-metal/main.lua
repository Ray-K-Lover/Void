-- name: [CS] Neo Metal Sonic
-- description: The REAL Sonic! The mad machine created by the evil Dr. Eggman was freed from his strings to cause havoc on everyone, those lower tiers in the Mushroom Kingdom, won't be able to handle this machine!\n\nMade by: You!\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

local TEXT_MOD_NAME = get_active_mod().name

-- Stops mod from loading if Character Select isn't on, Does not need to be touched
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

--- Load Models ---
local E_MODEL_NEOMETAL = smlua_model_util_get_id("neometal_violet_geo")      -- Located in "actors"
local E_MODEL_SUPERNEOMETAL = smlua_model_util_get_id("superneometal_violet_geo")

--- Load Textures ---
local TEX_NEOMETAL_ICON = get_texture_info("neometal_violet_icon") -- Located in "textures"

local VOICETABLE_NEOMETAL = {
    [CHAR_SOUND_OKEY_DOKEY] = 'NeoMetalOkieDokie.ogg',
    [CHAR_SOUND_ATTACKED] = 'NeoMetalAttacked.ogg',
    [CHAR_SOUND_COUGHING1] = 'NeoMetalCoughing1.ogg',
    [CHAR_SOUND_COUGHING2] = 'NeoMetalCoughing2.ogg',
    [CHAR_SOUND_COUGHING3] = 'NeoMetalCoughing3.ogg',
    [CHAR_SOUND_DOH] = 'NeoMetalDoh.ogg',
    [CHAR_SOUND_DROWNING] = 'NeoMetalDrowning.ogg',
    [CHAR_SOUND_DYING] = 'NeoMetalDying.ogg',
    [CHAR_SOUND_EEUH] = 'NeoMetalEeuh.ogg',
    [CHAR_SOUND_GROUND_POUND_WAH] = 'NeoMetalGroundPoundWah.ogg',
    [CHAR_SOUND_WAH2] = 'NeoMetalWah2.ogg',
    [CHAR_SOUND_HAHA] = 'NeoMetalHaha.ogg',
    [CHAR_SOUND_HAHA_2] = 'NeoMetalHaha2.ogg',
    [CHAR_SOUND_HERE_WE_GO] = 'NeoMetalHereWeGo.ogg',
    [CHAR_SOUND_HOOHOO] = 'NeoMetalHoohoo.ogg',
    [CHAR_SOUND_HRMM] = 'NeoMetalHrmm.ogg',
    [CHAR_SOUND_IMA_TIRED] = 'NeoMetalImaTired.ogg',
    [CHAR_SOUND_LETS_A_GO] = 'NeoMetalLetsAGo.ogg',
    [CHAR_SOUND_MAMA_MIA] = 'NeoMetalMamaMia.ogg',
    [CHAR_SOUND_ON_FIRE] = 'NeoMetalBurning.ogg',
    [CHAR_SOUND_OOOF] = 'NeoMetalOoof.ogg',
    [CHAR_SOUND_OOOF2] = 'NeoMetalOoof2.ogg',
    [CHAR_SOUND_PANTING] = 'NeoMetalPanting.ogg',
    [CHAR_SOUND_PANTING_COLD] = 'NeoMetalPantingCold.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'NeoMetalPunchHoo.ogg',
    [CHAR_SOUND_PUNCH_WAH] = 'NeoMetalPunchWah.ogg',
    [CHAR_SOUND_PUNCH_YAH] = 'NeoMetalPunchYah.ogg',
    [CHAR_SOUND_SNORING1] = 'NeoMetalSnoring1.ogg',
    [CHAR_SOUND_SNORING2] = 'NeoMetalSnoring2.ogg',
    [CHAR_SOUND_SNORING3] = 'NeoMetalSnoring3.ogg',
    [CHAR_SOUND_SO_LONGA_BOWSER] = 'NeoMetalBowser.ogg',
    [CHAR_SOUND_TWIRL_BOUNCE] = 'NeoMetalBoing.ogg',
    [CHAR_SOUND_UH] = 'NeoMetalUh.ogg',
    [CHAR_SOUND_UH2] = 'NeoMetalUh2.ogg',
    [CHAR_SOUND_UH2_2] = 'NeoMetalUh22.ogg',
    [CHAR_SOUND_WAAAOOOW] = 'NeoMetalFalling.ogg',
    [CHAR_SOUND_WHOA] = 'NeoMetalWoah.ogg',
    [CHAR_SOUND_YAHOO] = 'NeoMetalYahoo.ogg',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = { 'NeoMetalYahoo.ogg', 'NeoMetalWaha.ogg', 'NeoMetalYippee.ogg' },
    [CHAR_SOUND_YAH_WAH_HOO] = { 'NeoMetalYah.ogg', 'NeoMetalWah.ogg', 'NeoMetalHoo.ogg' },
    [CHAR_SOUND_YAWNING] = 'NeoMetalYawning.ogg',
}

local PALETTE_NEOMETAL = {
    [PANTS]  = "1B1B1B",
    [SHIRT]  = "FFFFFF",
    [GLOVES] = "CFCFCF",
    [SHOES]  = "FF0000",
    [HAIR]   = "0C00FF",
    [SKIN]   = "CFCFCF",
    [CAP]    = "FFB600",
	[EMBLEM] = "FFFFFF"
}

local PALETTE_SUPERNEOMETAL = {
    [PANTS]  = "1B1B1B",
    [SHIRT]  = "FFFFFF",
    [GLOVES] = "CFCFCF",
    [SHOES]  = "FF0000",
    [HAIR]   = "FFE600",
    [SKIN]   = "CFCFCF",
    [CAP]    = "FFB600",
	[EMBLEM] = "FFFFFF"
}

local HEALTH_METER_NEOMETAL = {
    label = {
        left = get_texture_info("NeoLeft"),
        right = get_texture_info("NeoRight"),
    },
    pie = {
        [1] = get_texture_info("Neo1"),
        [2] = get_texture_info("Neo2"),
        [3] = get_texture_info("Neo3"),
        [4] = get_texture_info("Neo4"),
        [5] = get_texture_info("Neo5"),
        [6] = get_texture_info("Neo6"),
        [7] = get_texture_info("Neo7"),
        [8] = get_texture_info("Neo8"),
    }
}

local ANIMTABLE_NEOMETAL = {
    [CHAR_ANIM_WALKING] = 'NeoMetalWalk',
    [CHAR_ANIM_RUNNING] = 'NeoMetalRun',
    [CHAR_ANIM_SINGLE_JUMP] = 'NeoMetalJump',
    [CHAR_ANIM_LAND_FROM_SINGLE_JUMP] = 'NeoMetalJump',
    [_G.charSelect.CS_ANIM_MENU] = 'NeoMetalCS',
    [CHAR_ANIM_IDLE_HEAD_CENTER] = 'NeoMetalIdle',
    [CHAR_ANIM_IDLE_HEAD_LEFT] = 'NeoMetalIdle',
    [CHAR_ANIM_IDLE_HEAD_RIGHT] = 'NeoMetalIdle',
    [CHAR_ANIM_FIRST_PERSON] = 'NeoMetalIdle',
    [CHAR_ANIM_TURNING_PART1] = 'NeoMetalTurnAround',
    [CHAR_ANIM_TURNING_PART2] = 'NeoMetalTurnAround',
}

local EYETABLE_NEOMETAL = {
    [_G.charSelect.CS_ANIM_MENU] = MARIO_EYES_LOOK_RIGHT,
}

local function neo_health_render(localIndex, health, prevX, prevY, prevScaleW, prevScaleH, x, y, scaleW, scaleH)
    local prevScaleW = prevScaleW / 64
    local prevScaleH = prevScaleH / 64
    local scaleW = scaleW / 64
    local scaleH = scaleH / 64

    djui_hud_render_texture_interpolated(HEALTH_METER_NEOMETAL.label.left, prevX, prevY, prevScaleW, prevScaleH, x, y, scaleW, scaleH)
    djui_hud_render_texture_interpolated(HEALTH_METER_NEOMETAL.label.right, prevX + 32*prevScaleW, prevY, prevScaleW, prevScaleH, x + 32*scaleW, y, scaleW, scaleH)

    local healthSeg = math.clamp(health >> 8, 0, 8)
    if healthSeg > 0 then
        for i = 1, healthSeg do
            djui_hud_render_texture_interpolated(HEALTH_METER_NEOMETAL.pie[i], prevX, prevY, prevScaleW, prevScaleH, x, y, scaleW, scaleH)
        end
    end
end

local function on_character_select_load()
    -- Adds the custom character to the Character Select Menu
    CT_NEOMETAL = _G.charSelect.character_add(
        "Neo Metal Sonic", -- Character Name
        "The REAL Sonic! The mad machine created by the evil Dr. Eggman was freed from his strings to cause havoc on everyone, those lower tiers in the Mushroom Kingdom, won't be able to handle this machine!", -- Description
        "VioletSM64", -- Credits
        "0C00FF",           -- Menu Color
        E_MODEL_NEOMETAL,       -- Character Model
        CT_MARIO,           -- Override Character
        TEX_NEOMETAL_ICON, -- Life Icon
        1                   -- Camera Scale
    )
    
    meter = neo_health_render,

    _G.charSelect.character_add_costume(CT_NEOMETAL, "Super Neo Metal Sonic", nil, "VioletSM64", nil, E_MODEL_SUPERNEOMETAL)

    _G.charSelect.character_add_voice(E_MODEL_NEOMETAL, VOICETABLE_NEOMETAL)
    _G.charSelect.character_add_voice(E_MODEL_SUPERNEOMETAL, VOICETABLE_NEOMETAL)

    _G.charSelect.character_add_palette_preset(E_MODEL_NEOMETAL, PALETTE_NEOMETAL)
    _G.charSelect.character_add_palette_preset(E_MODEL_SUPERNEOMETAL, PALETTE_SUPERNEOMETAL)

    _G.charSelect.character_add_animations(E_MODEL_NEOMETAL, ANIMTABLE_NEOMETAL, EYETABLE_NEOMETAL, nil)
    _G.charSelect.character_add_animations(E_MODEL_SUPERNEOMETAL, ANIMTABLE_NEOMETAL, EYETABLE_NEOMETAL, nil)

    _G.charSelect.character_add_graffiti(CT_NEOMETAL, TEX_NEOMETAL_ICON)
    if meter then charSelect.character_add_health_meter(CT_NEOMETAL, meter) end

    _G.charSelect.character_set_category(CT_NEOMETAL, TEXT_MOD_NAME)

    _G.charSelect.credit_add(TEXT_MOD_NAME, "VioletSM64", "Pack")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "Baconator2558", "Coding/Help")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "JioTheAegis", "Neo Metal VA")
end

-- Waits until the API is fully loaded before adding chars, just to be safe
hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)