local function s32(x)
    x = (math.floor(x) & 0xFFFFFFFF)
    if x >= 2147483648 then return x - 4294967296 end
    return x
end

local function s16(x)
    x = (math.floor(x) & 0xFFFF)
    if x >= 32768 then return x - 65536 end
    return x
end

local isInReferenceWalk = {}
for i = 0, (MAX_PLAYERS - 1) do
    isInReferenceWalk[i] = false
end

ACT_METALSONIC_WALK = allocate_mario_action(ACT_GROUP_MOVING | ACT_FLAG_ALLOW_FIRST_PERSON | ACT_FLAG_MOVING | ACT_FLAG_CUSTOM_ACTION)

local function anim_and_audio_for_walk(m)
    local val14 = 0
    local marioObj = m.marioObj
    local val0C = true
    local targetPitch = 0
    local val04 = 0.0
    
    if (m.intendedMag > m.forwardVel) then
        val04 = m.intendedMag
    else
        val04 = m.forwardVel
    end
    if (val04 < 4.0) then
        val04 = 4.0
    end
    if (m.quicksandDepth > 50) then
        val14 = s32(val04 / 4.0 * 0x10000)
        set_character_anim_with_accel(m, CHAR_ANIM_MOVE_IN_QUICKSAND, val14)
        m.actionState = 0
    else
        while (val0C) do
            if (m.actionState == 0) then
                if (val04 > 8.0) then
                    m.actionState = 2
                else
                    --! (Speed Crash) If Mario's speed is more than 2^17.
                    val14 = s32(val04 / 4.0 * 0x10000)
                    if (val14 < 0x1000) then
                        val14 = 0x1000
                    end
                    set_character_anim_with_accel(m, CHAR_ANIM_START_TIPTOE, val14)
                    play_step_sound(m, 7, 22)
                    if (is_anim_past_frame(m, 23)) then
                        m.actionState = 2
                    end
                    
                    val0C = false
                end
            elseif (m.actionState == 1) then
                if (val04 > 8.0) then
                    m.actionState = 2
                else
                    --! (Speed Crash) If Mario's speed is more than 2^17.
                    val14 = s32(val04 / 4.0 * 0x10000)
                    if (val14 < 0x1000) then
                        val14 = 0x1000
                    end
                    set_character_anim_with_accel(m, CHAR_ANIM_TIPTOE, val14)
                    play_step_sound(m, 14, 72)
                    
                    val0C = false
                end
            elseif (m.actionState == 2) then
                if (val04 < 5.0) then
                    m.actionState = 1
                elseif (val04 > 22.0) then
                    m.actionState = 3
                else
                    --! (Speed Crash) If Mario's speed is more than 2^17.
                    val14 = s32(val04 / 4.0 * 0x10000)
                    set_character_anim_with_accel(m, CHAR_ANIM_WALKING, val14)
                    
                    val0C = false
                end
            elseif (m.actionState == 3) then
                if (val04 < 18.0) then
                    m.actionState = 2
                else
                    --! (Speed Crash) If Mario's speed is more than 2^17.
                    val14 = s32(val04 / 4.0 * 0x10000)
                    set_character_anim_with_accel(m, CHAR_ANIM_RUNNING, val14)

                    targetPitch = tilt_body_running(m)
                    
                    val0C = false
                end
            else
                val0C = false
            end
        end
    end
    
    m.marioObj.oMarioWalkingPitch = s16(approach_s32(m.marioObj.oMarioWalkingPitch, targetPitch, 0x800, 0x800))
    m.marioObj.header.gfx.angle.x = m.marioObj.oMarioWalkingPitch
end

function act_metalsonic_walk(m)    
    isInReferenceWalk[m.playerIndex] = true
    local startPos = m.pos;
    local startYaw = m.faceAngle.y;

    mario_drop_held_object(m);

    if (should_begin_sliding(m) ~= 0) then
        return set_mario_action(m, ACT_BEGIN_SLIDING, 0);
    end

    if (m.input & INPUT_FIRST_PERSON ~= 0) then
        return begin_braking_action(m);
    end

    if (m.input & INPUT_A_PRESSED ~= 0) then
        return set_jump_from_landing(m);
    end

    if (check_ground_dive_or_punch(m) ~= 0) then
        return 1;
    end

    if (m.input & INPUT_ZERO_MOVEMENT ~= 0) then
        return begin_braking_action(m);
    end
    
    if (analog_stick_held_back(m) ~= 0 and m.forwardVel >= 16.0) then
        return set_mario_action(m, ACT_TURNING_AROUND, 0);
    end

    if (m.input & INPUT_Z_PRESSED ~= 0) then
        return set_mario_action(m, ACT_CROUCH_SLIDE, 0);
    end

    m.actionState = 0;

    vec3f_copy(startPos, m.pos);
    update_walking_speed(m);

    local stepResult = perform_ground_step(m)
    if (stepResult == GROUND_STEP_LEFT_GROUND) then
        set_mario_action(m, ACT_FREEFALL, 0);
        set_character_animation(m, CHAR_ANIM_GENERAL_FALL);    
    elseif (stepResult == GROUND_STEP_NONE) then
        anim_and_audio_for_walk(m);
        if ((m.intendedMag - m.forwardVel) > 16.0) then
            set_mario_particle_flags(m, PARTICLE_DUST, false);
        end
    elseif (stepResult == GROUND_STEP_HIT_WALL) then
        push_or_sidle_wall(m, startPos);
        m.actionTimer = 0;
    end

    check_ledge_climb_down(m);
    tilt_body_walking(m, startYaw);
    m.marioBodyState.allowPartRotation = 1
    return 0;
end

hook_mario_action(ACT_METALSONIC_WALK, { every_frame = act_metalsonic_walk, gravity = nil } )

local function reset_rotation(m, nextAct, actionArg)
    if isInReferenceWalk[m.playerIndex] then
        m.marioBodyState.allowPartRotation = 0
        isInReferenceWalk[m.playerIndex] = false
    end
end

hook_event(HOOK_BEFORE_SET_MARIO_ACTION, reset_rotation)

local function reset_pitch(m)
    if m.action == act_metalsonic_walk then
        m.marioObj.oMarioWalkingPitch = 0
    end
end

hook_event(HOOK_ON_SET_MARIO_ACTION, reset_pitch)

local function fix_interactions(m, obj, interactType)
    if (m.action == ACT_METALSONIC_WALK) then
        if (interactType == INTERACT_WARP_DOOR) then
            m.action = ACT_WALKING
            local interaction = interact_warp_door(m, INTERACT_WARP_DOOR, obj)
            if (interaction == 0 and m.action ~= ACT_READING_AUTOMATIC_DIALOG) then
                m.action = ACT_METALSONIC_WALK
            end
        end
        if (interactType == INTERACT_DOOR) then
            m.action = ACT_WALKING
            local interaction = interact_door(m, INTERACT_DOOR, obj)
            if (interaction == 0 and m.action ~= ACT_READING_AUTOMATIC_DIALOG) then
                m.action = ACT_METALSONIC_WALK
            end
        end
        if (interactType == INTERACT_KOOPA_SHELL) then
            m.action = ACT_WALKING
            local interaction = interact_koopa_shell(m, INTERACT_KOOPA_SHELL, obj)
            if (interaction == 0) then
                m.action = ACT_METALSONIC_WALK
            end
        end
    end
end

hook_event(HOOK_ALLOW_INTERACT, fix_interactions)

function before_set_metalsonic_action(m, nextAct, actionArg)
    if (CT_NEOMETAL == charSelect.character_get_current_number(m.playerIndex)) then
        if (nextAct == ACT_WALKING) then
            return ACT_METALSONIC_WALK
        end
    end
end

hook_event(HOOK_BEFORE_SET_MARIO_ACTION, before_set_metalsonic_action)