TEX_CAKE = get_texture_info("duo_end")

function render_end()
    if render_end then

        local x = djui_hud_get_screen_width() / 2 - TEX_CAKE.width / 2
        local y = djui_hud_get_screen_height() / 2 - TEX_CAKE.height / 2

        if gNetworkPlayers[0].currLevelNum ~= LEVEL_ENDING then
            return
        end
            djui_hud_set_color(255, 255, 255, 255)
            djui_hud_render_texture(TEX_CAKE, x, y, 1, 1)
        end
    end

hook_event(HOOK_ON_HUD_RENDER_BEHIND, function()
    djui_hud_set_resolution(RESOLUTION_N64)
    render_end()
end)