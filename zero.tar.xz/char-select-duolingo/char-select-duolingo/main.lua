-- name: \\#58cc02\\[CS] Duolingo
-- description: WABBIN!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation
]]

local TEXT_MOD_NAME = "Duolingo"
-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local MODEL_DUOLINGO = smlua_model_util_get_id("duolingo_geo")

local DUOLINGO_ICON = get_texture_info("duolingo_icon")
	  
      DUOLINGO_GRAFFITTI = get_texture_info("duolingo_graffiti")
	
-- All Located in "sound" Name them whatever you want. Remember to include the .ogg extension
local VOICETABLE_DUOLINGO = {
    [CHAR_SOUND_OKEY_DOKEY] = 'wabbin.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] = 'wabbin.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] = 'wrong.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] = 'wrong.ogg', -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] = 'wrong.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] = {'wabbin.ogg', 'wabbin.ogg', 'wabbin.ogg'}, -- First/Second jump sounds
	[CHAR_SOUND_HOOHOO] = 'wabbin.ogg', -- Third jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'wabbin.ogg', 'correct.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] = 'wrong.ogg', -- Wall bonk
	[CHAR_SOUND_UH2] = 'wrong.ogg', -- Landing after long jump
	[CHAR_SOUND_UH2_2] = 'wrong.ogg', -- Same sound as UH2; jumping onto ledge
	[CHAR_SOUND_HAHA] = 'correct.ogg', -- Landing triple jump
	[CHAR_SOUND_YAHOO] = 'wabbin.ogg', -- Long jump
	[CHAR_SOUND_DOH] = 'wrong.ogg', -- Long jump wall bonk
	[CHAR_SOUND_WHOA] = 'correct.ogg', -- Grabbing ledge
	[CHAR_SOUND_EEUH] = 'Silent.ogg', -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] = 'wrong.ogg', -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] = 'correct.ogg', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] = 'wrong.ogg', 
	[CHAR_SOUND_HRMM] = 'Silent.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] = 'end.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] = 'wabbin2.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] = 'wrong.ogg', -- Damaged
	[CHAR_SOUND_PANTING] = 'Silent.ogg', -- Low health
	[CHAR_SOUND_ON_FIRE] = 'wrong.ogg', -- Burned
--SLEEP SOUNDS
	[CHAR_SOUND_IMA_TIRED] = 'Silent.ogg', -- Mario feeling tired
	[CHAR_SOUND_YAWNING] = 'Silent.ogg', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] = 'Silent.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] = 'Silent.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] = 'Silent.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] = 'Silent.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] = 'Silent.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] = 'Silent.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] = 'wrong.ogg', -- Dying from damage
	[CHAR_SOUND_DROWNING] = 'wrong.ogg', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] = 'wrong.ogg' -- Booted out of level
}

-- All Located in "actors"
local CAPTABLE_DUOLINGO = {
    normal = smlua_model_util_get_id("duo_cap_geo"),
    wing = smlua_model_util_get_id("duo_wcap_geo"),
    metal = smlua_model_util_get_id("duo_mcap_geo"),
}

local CSloaded = false
local function on_character_select_load()
    CT_DUOLINGO = _G.charSelect.character_add(
        "Duolingo",                                                                                                                                                                -- Character Name
        "WABBIN!",                                                                                                                                                      -- Description
        "Tails Gamer",                                                                                                                                                                   -- Credits
        "58cc02",                                                                                                                                                                    -- Menu Color
        MODEL_DUOLINGO,                                                                                                                                                           -- Character Model
        CT_DUOLINGO,                                                                                                                                                                -- Override Character
        DUOLINGO_ICON                                                                                                                                                                -- Life Icon
   )

	--CAPS
    _G.charSelect.character_add_caps(MODEL_DUOLINGO, CAPTABLE_DUOLINGO)
	
	--VOICES
    _G.charSelect.character_add_voice(MODEL_DUOLINGO, VOICETABLE_DUOLINGO)
	
	--GRAFFITI
	_G.charSelect.character_add_graffiti(CT_DUOLINGO, DUOLINGO_GRAFFITTI)
	
    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_DUOLINGO then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_DUOLINGO then return _G.charSelect.voice.snore(m) end
end


hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)