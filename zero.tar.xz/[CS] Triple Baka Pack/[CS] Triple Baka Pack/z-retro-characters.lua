if not retroCharAPI then return end

SMB_RED = retroCharAPI.SMB_RED
SMB_WHITE = retroCharAPI.SMB_WHITE
SMB_DEFAULT_SKIN = retroCharAPI.SMB_DEFAULT_SKIN
SMB_PINK = retroCharAPI.SMB_PINK

function setup_retro_sprites()
    retroCharAPI.add_cs_character_sprites(CT_MIKU, get_texture_info("miku_0"), get_texture_info("miku_1"))
    retroCharAPI.add_cs_character_sprites(CT_TETO, get_texture_info("teto_0"), get_texture_info("teto_1"))
    retroCharAPI.add_cs_character_sprites(CT_NERU, get_texture_info("neru_0"), get_texture_info("neru_1"))

    retroCharAPI.add_cs_character_palette(CT_MIKU, {SKIN, PANTS, HAIR}, {SKIN, SMB_DEFAULT_SKIN, SMB_RED}, 1, 2)
    retroCharAPI.add_cs_character_palette(CT_TETO, {SKIN, SHIRT, HAIR}, {SKIN, SMB_RED, SMB_DEFAULT_SKIN}, 1, 2)
    retroCharAPI.add_cs_character_palette(CT_NERU, {SKIN, SHIRT, HAIR}, {SKIN, SMB_DEFAULT_SKIN, SMB_RED}, 1, 2)
end

hook_event(HOOK_ON_MODS_LOADED, setup_retro_sprites)