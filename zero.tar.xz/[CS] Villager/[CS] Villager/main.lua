-- name: [CS] Villager
-- description: HMMM...\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation

    Use this if you're curious on how anything here works >v<
	(This is an edited version of the Template File by Squishy)
]]

local TEXT_MOD_NAME = "Villager"

-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_CUSTOM_MODEL = smlua_model_util_get_id("villager_geo") -- Located in "actors"

local TEX_CUSTOM_LIFE_ICON = get_texture_info("villager_icon") -- Located in "textures"

TEX_VILLAGER_CS_MENU_GRAFFITI = get_texture_info("villager_graffiti") -- Located in "textures"

-- All Located in "sound" Name them whatever you want. Remember to include the .ogg extension
local VOICETABLE_VILLAGER = {
    --[CHAR_SOUND_OKEY_DOKEY] = 'star.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] = 'star.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] = 'punch1.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] = 'punch2.ogg', -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] = 'punch3.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] = {'jump1.ogg', 'jump2.ogg', 'jump3.ogg'}, -- First/Second jump sounds
	[CHAR_SOUND_HOOHOO] = 'jump2.ogg', -- Third jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'jump1.ogg', 'jump2.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] = 'hit2.ogg', -- Wall bonk
	[CHAR_SOUND_UH2] = 'Silent.ogg', -- Landing after long jump
	[CHAR_SOUND_UH2_2] = 'Silent.ogg', -- Same sound as UH2; jumping onto ledge
	[CHAR_SOUND_HAHA] = 'Silent.ogg', -- Landing triple jump
	[CHAR_SOUND_YAHOO] = 'jump1.ogg', -- Long jump
	[CHAR_SOUND_DOH] = 'hit2.ogg', -- Long jump wall bonk
	[CHAR_SOUND_WHOA] = 'Silent.ogg', -- Grabbing ledge
	[CHAR_SOUND_EEUH] = 'Silent.ogg', -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] = 'punch3.ogg', -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] = 'jump3.ogg', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] = 'Silent.ogg', 
	[CHAR_SOUND_HRMM] = 'Silent.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] = 'star.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] = 'star.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] = 'hit.ogg', -- Damaged
	[CHAR_SOUND_PANTING] = 'no.ogg', -- Low health
	[CHAR_SOUND_ON_FIRE] = 'hit2.ogg', -- Burned
--SLEEP SOUNDS
	[CHAR_SOUND_IMA_TIRED] = 'Silent.ogg', -- Mario feeling tired
	[CHAR_SOUND_YAWNING] = 'Silent.ogg', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] = 'Silent.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] = 'Silent.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] = 'Silent.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] = 'hit.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] = 'hit.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] = 'hit.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] = 'Silent.ogg', -- Dying from damage
	[CHAR_SOUND_DROWNING] = 'Silent.ogg', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] = 'no.ogg' -- Booted out of level
}

-- All Located in "actors"
local CAPTABLE_VILLAGER = {
    normal = smlua_model_util_get_id("villager_cap_geo"),
    wing = smlua_model_util_get_id("villager_wcap_geo"),
    metal = smlua_model_util_get_id("villager_mcap_geo"),
}

local CSloaded = false
local function on_character_select_load()
    CT_CHARNAME2 = _G.charSelect.character_add("Villager", {"HMMM..."}, "Tails Gamer", {r = 71, g = 40, b = 0}, E_MODEL_CUSTOM_MODEL, CT_CHARNAME2, TEX_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_CUSTOM_MODEL, CAPTABLE_VILLAGER)
    _G.charSelect.character_add_voice(E_MODEL_CUSTOM_MODEL, VOICETABLE_VILLAGER)
    _G.charSelect.character_add_celebration_star(E_MODEL_CUSTOM_MODEL, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_graffiti(CT_VILLAGER, TEX_VILLAGER_CS_MENU_GRAFFITI)
    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_VILLAGER then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_VILLAGER then return _G.charSelect.voice.snore(m) end
end

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)