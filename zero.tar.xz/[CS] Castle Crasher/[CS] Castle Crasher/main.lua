-- name: [CS] Castle Crashers Pack
-- description: The four valorant yet huggable knights are here in COOPDX! Enjoy the Green, Red, Blue, and Orange knights! \n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation

    Use this if you're curious on how anything here works >v<
	(This is an edited version of the Template File by Squishy)
]]

local TEXT_MOD_NAME = "[CS] Castle Crashers Pack"

-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_RED_CRASHER = smlua_model_util_get_id("crasher_geo") -- Located in "actors"
local E_MODEL_BLUE_CRASHER = smlua_model_util_get_id("crasher_blue_geo")
local E_MODEL_GREEN_CRASHER = smlua_model_util_get_id("crasher_green_geo")
local E_MODEL_ORANGE_CRASHER = smlua_model_util_get_id("crasher_orange_geo")

local TEX_RED_CUSTOM_LIFE_ICON = get_texture_info("red_knight_icon") -- Located in "textures"
local TEX_BLUE_CUSTOM_LIFE_ICON = get_texture_info("blue_knight_icon") -- Located in "textures"
local TEX_GREEN_CUSTOM_LIFE_ICON = get_texture_info("green_knight_icon") -- Located in "textures"
local TEX_ORANGE_CUSTOM_LIFE_ICON = get_texture_info("orange_knight_icon") -- Located in "textures"

-- All Located in "actors"
local CAPTABLE_CHAR = {
    normal = smlua_model_util_get_id("crasher_cap_geo"),
    wing = smlua_model_util_get_id("crasher_wing_cap_geo"),
    metal = smlua_model_util_get_id("crasher_metal_cap_geo"),
}


local PALETTE_CHAR = {
    [PANTS]  = "ffffff",
    [SHIRT]  = "ffffff",
    [GLOVES] = "7A7A7A",
    [SHOES]  = "7A7A7A",
    [HAIR]   = "ffffff",
    [SKIN]   = "46A410",
    [CAP]    = "7A7A7A",
	[EMBLEM] = "94FF5F"
}

local ANIMTABLE_CHAR = {
	[CHAR_ANIM_FIRST_PUNCH]		  = 'swingplus',		-- 67
}


local CSloaded = false
local function on_character_select_load()
    CT_CHARNAME2 = _G.charSelect.character_add("Red Knight", {"Sounds Shocky"}, "SkyCaster09", {r = 255, g = 0, b = 0}, E_MODEL_RED_CRASHER, CT_MARIO, TEX_RED_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_RED_CRASHER, CAPTABLE_CHAR)
    _G.charSelect.character_add_celebration_star(E_MODEL_RED_CRASHER, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_RED_CRASHER, PALETTE_CHAR)
		_G.charSelect.character_add_animations(E_MODEL_RED_CRASHER, ANIMTABLE_CHAR, {}, {})

		CT_CHARNAME3 = _G.charSelect.character_add("Blue Knight", {"Sounds Chilly"}, "SkyCaster09", {r = 0, g = 0, b = 255}, E_MODEL_BLUE_CRASHER, CT_TOAD, TEX_BLUE_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_BLUE_CRASHER, CAPTABLE_CHAR)
    _G.charSelect.character_add_celebration_star(E_MODEL_BLUE_CRASHER, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_BLUE_CRASHER, PALETTE_CHAR)
		_G.charSelect.character_add_animations(E_MODEL_BLUE_CRASHER, ANIMTABLE_CHAR, {}, {})

		CT_CHARNAME4 = _G.charSelect.character_add("Green Knight", {"Sounds Sickly"}, "SkyCaster09", {r = 0, g = 255, b = 0}, E_MODEL_GREEN_CRASHER, CT_LUIGI, TEX_GREEN_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_GREEN_CRASHER, CAPTABLE_CHAR)
    _G.charSelect.character_add_celebration_star(E_MODEL_GREEN_CRASHER, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_GREEN_CRASHER, PALETTE_CHAR)
		_G.charSelect.character_add_animations(E_MODEL_GREEN_CRASHER, ANIMTABLE_CHAR, {}, {})

		CT_CHARNAME5 = _G.charSelect.character_add("Orange Knight", {"Sounds Toasty"}, "SkyCaster09", {r = 254, g = 152, b = 0}, E_MODEL_ORANGE_CRASHER, CT_WARIO, TEX_ORANGE_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_ORANGE_CRASHER, CAPTABLE_CHAR)
    _G.charSelect.character_add_celebration_star(E_MODEL_ORANGE_CRASHER, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_ORANGE_CRASHER, PALETTE_CHAR)
		_G.charSelect.character_add_animations(E_MODEL_ORANGE_CRASHER, ANIMTABLE_CHAR, {}, {})

    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == SOUND_BANK_LUIGI_VOICE then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == SOUND_BANK_LUIGI_VOICE then return _G.charSelect.voice.snore(m) end
end


hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)