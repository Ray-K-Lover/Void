extern const GeoLayout crasher_cap_6_Cap_Anim_State_Switch_opt1[];
extern const GeoLayout crasher_cap_geo[];
extern Lights1 crasher_cap_f3dlite_material_lights;
extern Vtx crasher_cap_Cap_DL_mesh_layer_1_vtx_0[96];
extern Gfx crasher_cap_Cap_DL_mesh_layer_1_tri_0[];
extern Gfx mat_crasher_cap_f3dlite_material[];
extern Gfx mat_revert_crasher_cap_f3dlite_material[];
extern Gfx crasher_cap_Cap_DL_mesh_layer_1[];
