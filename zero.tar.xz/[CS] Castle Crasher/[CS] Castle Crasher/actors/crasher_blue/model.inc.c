Lights1 crasher_blue_NumB_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFF, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Metal__METAL__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFF, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Half_Closed_Eyes__SKIN__lights = gdSPDefLights1(
	0x7F, 0x69, 0x4E,
	0xFE, 0xD5, 0xA1, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Closed_Eyes__SKIN__lights = gdSPDefLights1(
	0x7F, 0x69, 0x4E,
	0xFE, 0xD5, 0xA1, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Left_Eyes__SKIN__lights = gdSPDefLights1(
	0x7F, 0x69, 0x4E,
	0xFE, 0xD5, 0xA1, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Right_Eyes__SKIN__lights = gdSPDefLights1(
	0x7F, 0x69, 0x4E,
	0xFE, 0xD5, 0xA1, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Up_Eyes__SKIN__lights = gdSPDefLights1(
	0x7F, 0x69, 0x4E,
	0xFE, 0xD5, 0xA1, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Down_Eyes__SKIN__lights = gdSPDefLights1(
	0x7F, 0x69, 0x4E,
	0xFE, 0xD5, 0xA1, 0x28, 0x28, 0x28);

Lights1 crasher_blue_Dead_Eyes__SKIN__lights = gdSPDefLights1(
	0x7F, 0x69, 0x4E,
	0xFE, 0xD5, 0xA1, 0x28, 0x28, 0x28);

Lights1 crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFF, 0x28, 0x28, 0x28);

Lights1 crasher_blue_NumE_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFF, 0x28, 0x28, 0x28);

Lights1 crasher_blue_NumA_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFF, 0x28, 0x28, 0x28);

Lights1 crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFF, 0x28, 0x28, 0x28);

Gfx crasher_blue_castle_body_blue_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_body_blue_rgba16[] = {
	#include "actors/crasher_blue/castle_body_blue.rgba16.inc.c"
};

Gfx crasher_blue_Metal_Shade_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_Metal_Shade_rgba16_rgba16[] = {
	#include "actors/crasher_blue/Metal_Shade.rgba16.inc.c"
};

Gfx crasher_blue_Metal_Light_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_Metal_Light_rgba16_rgba16[] = {
	#include "actors/crasher_blue/Metal_Light.rgba16.inc.c"
};

Gfx crasher_blue_custom_toad_eyes_half_closed_ia16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_eyes_half_closed_ia16[] = {
	#include "actors/crasher_blue/custom_toad_eyes_half_closed.ia16.inc.c"
};

Gfx crasher_blue_custom_toad_face_neutral_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_face_neutral_rgba16[] = {
	#include "actors/crasher_blue/custom_toad_face_neutral.rgba16.inc.c"
};

Gfx crasher_blue_custom_toad_eyes_closed_ia16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_eyes_closed_ia16[] = {
	#include "actors/crasher_blue/custom_toad_eyes_closed.ia16.inc.c"
};

Gfx crasher_blue_custom_toad_eyes_left_ia16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_eyes_left_ia16[] = {
	#include "actors/crasher_blue/custom_toad_eyes_left.ia16.inc.c"
};

Gfx crasher_blue_custom_toad_eyes_right_ia16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_eyes_right_ia16[] = {
	#include "actors/crasher_blue/custom_toad_eyes_right.ia16.inc.c"
};

Gfx crasher_blue_custom_toad_eyes_up_ia16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_eyes_up_ia16[] = {
	#include "actors/crasher_blue/custom_toad_eyes_up.ia16.inc.c"
};

Gfx crasher_blue_custom_toad_eyes_down_ia16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_eyes_down_ia16[] = {
	#include "actors/crasher_blue/custom_toad_eyes_down.ia16.inc.c"
};

Gfx crasher_blue_custom_toad_eyes_dead_ia16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_eyes_dead_ia16[] = {
	#include "actors/crasher_blue/custom_toad_eyes_dead.ia16.inc.c"
};

Gfx crasher_blue_custom_toad_face_dead_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_custom_toad_face_dead_rgba16[] = {
	#include "actors/crasher_blue/custom_toad_face_dead.rgba16.inc.c"
};

Gfx crasher_blue_mario_wing_tip_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_mario_wing_tip_rgba16[] = {
	#include "actors/crasher_blue/mario_wing_tip.rgba16.inc.c"
};

Gfx crasher_blue_mario_wing_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_mario_wing_rgba16[] = {
	#include "actors/crasher_blue/mario_wing.rgba16.inc.c"
};

Gfx crasher_blue_castle_arm_ci4_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_arm_ci4[] = {
	#include "actors/crasher_blue/castle_arm.ci4.inc.c"
};

Gfx crasher_blue_castle_arm_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_arm_pal_rgba16[] = {
	#include "actors/crasher_blue/castle_arm.rgba16.pal"
};

Gfx crasher_blue_castle_shield_blue_ci4_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_shield_blue_ci4[] = {
	#include "actors/crasher_blue/castle_shield_blue.ci4.inc.c"
};

Gfx crasher_blue_castle_shield_blue_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_shield_blue_pal_rgba16[] = {
	#include "actors/crasher_blue/castle_shield_blue.rgba16.pal"
};

Gfx crasher_blue_castle_sheathed_ci4_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_sheathed_ci4[] = {
	#include "actors/crasher_blue/castle_sheathed.ci4.inc.c"
};

Gfx crasher_blue_castle_sheathed_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_sheathed_pal_rgba16[] = {
	#include "actors/crasher_blue/castle_sheathed.rgba16.pal"
};

Gfx crasher_blue_castle_foot_ia8_aligner[] = {gsSPEndDisplayList()};
u8 crasher_blue_castle_foot_ia8[] = {
	#include "actors/crasher_blue/castle_foot.ia8.inc.c"
};

Vtx crasher_blue_Torso_mesh_layer_1_vtx_0[98] = {
	{{{-64, -5, -116}, 0, {12, 379}, {0x86, 0x0D, 0x22, 0xFF}}},
	{{{-58, -102, -58}, 0, {185, 648}, {0x86, 0x0D, 0x22, 0xFF}}},
	{{{-30, 11, 0}, 0, {352, 321}, {0x86, 0x0D, 0x22, 0xFF}}},
	{{{-23, 125, -58}, 0, {188, 0}, {0x87, 0x18, 0x20, 0xFF}}},
	{{{-64, -5, -116}, 0, {12, 379}, {0x87, 0x18, 0x20, 0xFF}}},
	{{{-30, 11, 0}, 0, {352, 321}, {0x87, 0x18, 0x20, 0xFF}}},
	{{{-23, 125, 58}, 0, {516, 0}, {0x81, 0x08, 0x00, 0xFF}}},
	{{{-23, 125, -58}, 0, {188, 0}, {0x81, 0x08, 0x00, 0xFF}}},
	{{{-30, 11, 0}, 0, {352, 321}, {0x81, 0x08, 0x00, 0xFF}}},
	{{{-64, -5, 116}, 0, {692, 379}, {0x87, 0x18, 0xE0, 0xFF}}},
	{{{-23, 125, 58}, 0, {516, 0}, {0x87, 0x18, 0xE0, 0xFF}}},
	{{{-30, 11, 0}, 0, {352, 321}, {0x87, 0x18, 0xE0, 0xFF}}},
	{{{-58, -102, 58}, 0, {519, 648}, {0x86, 0x0D, 0xDE, 0xFF}}},
	{{{-64, -5, 116}, 0, {692, 379}, {0x86, 0x0D, 0xDE, 0xFF}}},
	{{{-30, 11, 0}, 0, {352, 321}, {0x86, 0x0D, 0xDE, 0xFF}}},
	{{{-58, -102, -58}, 0, {192, 652}, {0x85, 0x1E, 0x00, 0xFF}}},
	{{{-58, -102, 58}, 0, {519, 648}, {0x85, 0x1E, 0x00, 0xFF}}},
	{{{-30, 11, 0}, 0, {352, 321}, {0x85, 0x1E, 0x00, 0xFF}}},
	{{{-47, 68, -47}, 0, {2444, 0}, {0x91, 0x3B, 0x12, 0xFF}}},
	{{{-92, 0, -105}, 0, {2277, 228}, {0x91, 0x3B, 0x12, 0xFF}}},
	{{{-70, 11, 0}, 0, {2576, 172}, {0x91, 0x3B, 0x12, 0xFF}}},
	{{{-47, 68, 47}, 0, {2708, 0}, {0x8A, 0x2F, 0x00, 0xFF}}},
	{{{-47, 68, -47}, 0, {2444, 0}, {0x8A, 0x2F, 0x00, 0xFF}}},
	{{{-70, 11, 0}, 0, {2576, 172}, {0x8A, 0x2F, 0x00, 0xFF}}},
	{{{-92, 0, 105}, 0, {2875, 228}, {0x91, 0x3B, 0xEE, 0xFF}}},
	{{{-47, 68, 47}, 0, {2708, 0}, {0x91, 0x3B, 0xEE, 0xFF}}},
	{{{-70, 11, 0}, 0, {2576, 172}, {0x91, 0x3B, 0xEE, 0xFF}}},
	{{{-47, -68, 47}, 0, {2564, 960}, {0x8F, 0xCE, 0xE2, 0xFF}}},
	{{{-92, 0, 105}, 0, {2736, 735}, {0x8F, 0xCE, 0xE2, 0xFF}}},
	{{{-70, 11, 0}, 0, {2432, 727}, {0x8F, 0xCE, 0xE2, 0xFF}}},
	{{{-47, -68, -47}, 0, {2300, 960}, {0x86, 0xDD, 0x00, 0xFF}}},
	{{{-47, -68, 47}, 0, {2564, 960}, {0x86, 0xDD, 0x00, 0xFF}}},
	{{{-70, 11, 0}, 0, {2432, 727}, {0x86, 0xDD, 0x00, 0xFF}}},
	{{{-92, 0, -105}, 0, {2128, 735}, {0x8F, 0xCE, 0x1E, 0xFF}}},
	{{{-47, -68, -47}, 0, {2300, 960}, {0x8F, 0xCE, 0x1E, 0xFF}}},
	{{{-70, 11, 0}, 0, {2432, 727}, {0x8F, 0xCE, 0x1E, 0xFF}}},
	{{{-58, -102, -58}, 0, {352, 2453}, {0x0F, 0xC0, 0x93, 0xFF}}},
	{{{-64, -5, -116}, 0, {672, 2453}, {0x0F, 0xC0, 0x93, 0xFF}}},
	{{{101, 11, -104}, 0, {668, 1984}, {0x0F, 0xC0, 0x93, 0xFF}}},
	{{{101, -75, -52}, 0, {385, 1999}, {0x0F, 0xC0, 0x93, 0xFF}}},
	{{{-58, -102, 58}, 0, {800, 2567}, {0x16, 0x83, 0x00, 0xFF}}},
	{{{-58, -102, -58}, 0, {1128, 2567}, {0x16, 0x83, 0x00, 0xFF}}},
	{{{101, -75, -52}, 0, {1110, 2112}, {0x16, 0x83, 0x00, 0xFF}}},
	{{{101, -74, 52}, 0, {818, 2112}, {0x16, 0x83, 0x00, 0xFF}}},
	{{{-64, -5, -116}, 0, {2384, 1842}, {0x0C, 0x30, 0x8B, 0xFF}}},
	{{{-23, 125, -58}, 0, {2270, 1440}, {0x0C, 0x30, 0x8B, 0xFF}}},
	{{{101, 109, -52}, 0, {1920, 1472}, {0x0C, 0x30, 0x8B, 0xFF}}},
	{{{101, 11, -104}, 0, {1920, 1781}, {0x0C, 0x30, 0x8B, 0xFF}}},
	{{{-23, 125, -58}, 0, {1475, 359}, {0x1C, 0x7C, 0x00, 0xFF}}},
	{{{-23, 125, 58}, 0, {1802, 359}, {0x1C, 0x7C, 0x00, 0xFF}}},
	{{{101, 96, 52}, 0, {1784, 11}, {0x1C, 0x7C, 0x00, 0xFF}}},
	{{{101, 109, -52}, 0, {1492, 11}, {0x1C, 0x7C, 0x00, 0xFF}}},
	{{{-23, 125, 58}, 0, {1998, 1969}, {0x04, 0x33, 0x74, 0xFF}}},
	{{{-64, -5, 116}, 0, {1879, 2385}, {0x04, 0x33, 0x74, 0xFF}}},
	{{{101, 11, 104}, 0, {2359, 2324}, {0x04, 0x33, 0x74, 0xFF}}},
	{{{101, 96, 52}, 0, {2359, 2036}, {0x04, 0x33, 0x74, 0xFF}}},
	{{{-64, -5, 116}, 0, {1216, 2197}, {0x10, 0xC0, 0x6D, 0xFF}}},
	{{{-58, -102, 58}, 0, {1233, 2516}, {0x10, 0xC0, 0x6D, 0xFF}}},
	{{{101, -74, 52}, 0, {1684, 2457}, {0x10, 0xC0, 0x6D, 0xFF}}},
	{{{101, 11, 104}, 0, {1684, 2176}, {0x10, 0xC0, 0x6D, 0xFF}}},
	{{{-47, -68, -47}, 0, {4, 2527}, {0x08, 0xB1, 0x9D, 0xFF}}},
	{{{-92, 0, -105}, 0, {256, 2656}, {0x08, 0xB1, 0x9D, 0xFF}}},
	{{{44, 0, -94}, 0, {238, 2271}, {0x08, 0xB1, 0x9D, 0xFF}}},
	{{{44, -68, -47}, 0, {6, 2271}, {0x08, 0xB1, 0x9D, 0xFF}}},
	{{{-47, -68, 47}, 0, {2016, 2624}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{-47, -68, -47}, 0, {2272, 2624}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{44, -68, -47}, 0, {2272, 2368}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{44, -68, 47}, 0, {2016, 2368}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{-92, 0, -105}, 0, {2752, 1596}, {0x00, 0x52, 0x9F, 0xFF}}},
	{{{-47, 68, -47}, 0, {2624, 1344}, {0x00, 0x52, 0x9F, 0xFF}}},
	{{{44, 68, -47}, 0, {2368, 1344}, {0x00, 0x52, 0x9F, 0xFF}}},
	{{{44, 0, -94}, 0, {2368, 1576}, {0x00, 0x52, 0x9F, 0xFF}}},
	{{{-47, 68, -47}, 0, {2432, 1888}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{-47, 68, 47}, 0, {2688, 1888}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{44, 68, 47}, 0, {2688, 1632}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{44, 68, -47}, 0, {2432, 1632}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{-47, 68, 47}, 0, {1980, 2465}, {0x08, 0x4F, 0x63, 0xFF}}},
	{{{-92, 0, 105}, 0, {1728, 2336}, {0x08, 0x4F, 0x63, 0xFF}}},
	{{{44, 0, 94}, 0, {1746, 2720}, {0x08, 0x4F, 0x63, 0xFF}}},
	{{{44, 68, 47}, 0, {1978, 2720}, {0x08, 0x4F, 0x63, 0xFF}}},
	{{{-92, 0, 105}, 0, {2272, 288}, {0x00, 0xAE, 0x61, 0xFF}}},
	{{{-47, -68, 47}, 0, {2400, 544}, {0x00, 0xAE, 0x61, 0xFF}}},
	{{{44, -68, 47}, 0, {2656, 544}, {0x00, 0xAE, 0x61, 0xFF}}},
	{{{44, 0, 94}, 0, {2656, 309}, {0x00, 0xAE, 0x61, 0xFF}}},
	{{{101, -75, -52}, 0, {962, 1061}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{101, 11, -104}, 0, {1108, 818}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{101, 11, 0}, 0, {816, 818}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{101, 109, -52}, 0, {962, 544}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{101, 96, 52}, 0, {670, 578}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{101, 11, 104}, 0, {524, 818}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{101, -74, 52}, 0, {670, 1058}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{44, -68, -47}, 0, {2292, 1376}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{44, 0, -94}, 0, {2424, 1184}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{44, 0, 0}, 0, {2160, 1184}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{44, 68, -47}, 0, {2292, 992}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{44, 68, 47}, 0, {2028, 992}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{44, 0, 94}, 0, {1896, 1184}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{44, -68, 47}, 0, {2028, 1376}, {0x7F, 0x00, 0x00, 0xFF}}},
};

Gfx crasher_blue_Torso_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Torso_mesh_layer_1_vtx_0 + 0, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
	gsSPVertex(crasher_blue_Torso_mesh_layer_1_vtx_0 + 30, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 16, 17, 0),
	gsSP2Triangles(18, 19, 20, 0, 18, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSPVertex(crasher_blue_Torso_mesh_layer_1_vtx_0 + 60, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 25, 27, 26, 0),
	gsSP2Triangles(27, 28, 26, 0, 28, 29, 26, 0),
	gsSP2Triangles(29, 30, 26, 0, 30, 24, 26, 0),
	gsSPVertex(crasher_blue_Torso_mesh_layer_1_vtx_0 + 91, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(3, 4, 2, 0, 4, 5, 2, 0),
	gsSP2Triangles(5, 6, 2, 0, 6, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Head_DL_mesh_layer_1_vtx_0[76] = {
	{{{86, 128, -23}, 0, {1120, 947}, {0x00, 0x46, 0x96, 0xFF}}},
	{{{-5, 128, -23}, 0, {1376, 947}, {0x00, 0x46, 0x96, 0xFF}}},
	{{{30, 162, 0}, 0, {1280, 832}, {0x00, 0x46, 0x96, 0xFF}}},
	{{{86, 128, 23}, 0, {867, 1276}, {0x41, 0x6D, 0x00, 0xFF}}},
	{{{86, 128, -23}, 0, {989, 1317}, {0x41, 0x6D, 0x00, 0xFF}}},
	{{{30, 162, 0}, 0, {989, 1120}, {0x41, 0x6D, 0x00, 0xFF}}},
	{{{-5, 128, -23}, 0, {326, 1536}, {0xA6, 0x5A, 0x00, 0xFF}}},
	{{{-5, 128, 23}, 0, {442, 1590}, {0xA6, 0x5A, 0x00, 0xFF}}},
	{{{30, 162, 0}, 0, {442, 1440}, {0xA6, 0x5A, 0x00, 0xFF}}},
	{{{-5, 128, 23}, 0, {1408, 947}, {0x00, 0x46, 0x6A, 0xFF}}},
	{{{86, 128, 23}, 0, {1664, 947}, {0x00, 0x46, 0x6A, 0xFF}}},
	{{{30, 162, 0}, 0, {1504, 832}, {0x00, 0x46, 0x6A, 0xFF}}},
	{{{-19, 98, -107}, 0, {1248, 1556}, {0x85, 0x00, 0xE2, 0xFF}}},
	{{{-19, -52, -104}, 0, {1256, 1980}, {0x85, 0x00, 0xE2, 0xFF}}},
	{{{-44, 34, 0}, 0, {1558, 1735}, {0x85, 0x00, 0xE2, 0xFF}}},
	{{{-57, 151, 0}, 0, {1566, 1402}, {0x87, 0xF3, 0xDB, 0xFF}}},
	{{{-19, 98, -107}, 0, {1248, 1556}, {0x87, 0xF3, 0xDB, 0xFF}}},
	{{{-44, 34, 0}, 0, {1558, 1735}, {0x87, 0xF3, 0xDB, 0xFF}}},
	{{{-19, 98, 106}, 0, {320, 1620}, {0x87, 0xF3, 0x25, 0xFF}}},
	{{{-57, 151, 0}, 0, {5, 1466}, {0x87, 0xF3, 0x25, 0xFF}}},
	{{{-44, 34, 0}, 0, {13, 1799}, {0x87, 0xF3, 0x25, 0xFF}}},
	{{{-19, -52, 106}, 0, {319, 2044}, {0x85, 0x00, 0x1E, 0xFF}}},
	{{{-19, 98, 106}, 0, {320, 1620}, {0x85, 0x00, 0x1E, 0xFF}}},
	{{{-44, 34, 0}, 0, {13, 1799}, {0x85, 0x00, 0x1E, 0xFF}}},
	{{{-31, -111, 0}, 0, {19, 2208}, {0x83, 0xF5, 0x15, 0xFF}}},
	{{{-19, -52, 106}, 0, {319, 2044}, {0x83, 0xF5, 0x15, 0xFF}}},
	{{{-44, 34, 0}, 0, {13, 1799}, {0x83, 0xF5, 0x15, 0xFF}}},
	{{{-19, -52, -104}, 0, {1256, 1980}, {0x83, 0xF5, 0xEB, 0xFF}}},
	{{{-31, -111, 0}, 0, {1552, 2144}, {0x83, 0xF5, 0xEB, 0xFF}}},
	{{{-44, 34, 0}, 0, {1558, 1735}, {0x83, 0xF5, 0xEB, 0xFF}}},
	{{{223, -52, -102}, 0, {2235, 583}, {0x78, 0xFA, 0xD8, 0xFF}}},
	{{{230, 86, -102}, 0, {2240, 191}, {0x78, 0xFA, 0xD8, 0xFF}}},
	{{{261, 34, 0}, 0, {1935, 330}, {0x78, 0xFA, 0xD8, 0xFF}}},
	{{{230, 86, -102}, 0, {2240, 191}, {0x79, 0x20, 0xEB, 0xFF}}},
	{{{233, 139, 0}, 0, {1962, 25}, {0x79, 0x20, 0xEB, 0xFF}}},
	{{{261, 34, 0}, 0, {1935, 330}, {0x79, 0x20, 0xEB, 0xFF}}},
	{{{233, 139, 0}, 0, {1879, 1370}, {0x79, 0x20, 0x17, 0xFF}}},
	{{{228, 86, 102}, 0, {1600, 1535}, {0x79, 0x20, 0x17, 0xFF}}},
	{{{261, 34, 0}, 0, {1907, 1674}, {0x79, 0x20, 0x17, 0xFF}}},
	{{{228, 86, 102}, 0, {1600, 1535}, {0x78, 0xFC, 0x29, 0xFF}}},
	{{{223, -52, 102}, 0, {1607, 1927}, {0x78, 0xFC, 0x29, 0xFF}}},
	{{{261, 34, 0}, 0, {1907, 1674}, {0x78, 0xFC, 0x29, 0xFF}}},
	{{{223, -52, 102}, 0, {1607, 1927}, {0x79, 0xDF, 0x11, 0xFF}}},
	{{{223, -105, 0}, 0, {1892, 2080}, {0x79, 0xDF, 0x11, 0xFF}}},
	{{{261, 34, 0}, 0, {1907, 1674}, {0x79, 0xDF, 0x11, 0xFF}}},
	{{{223, -105, 0}, 0, {1950, 736}, {0x79, 0xDF, 0xEF, 0xFF}}},
	{{{223, -52, -102}, 0, {2235, 583}, {0x79, 0xDF, 0xEF, 0xFF}}},
	{{{261, 34, 0}, 0, {1935, 330}, {0x79, 0xDF, 0xEF, 0xFF}}},
	{{{-5, 128, -23}, 0, {2432, 2624}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{86, 128, -23}, 0, {2432, 2368}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{86, 128, 23}, 0, {2304, 2368}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{-5, 128, 23}, 0, {2304, 2624}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{-19, -52, -104}, 0, {0, 1390}, {0x02, 0xFE, 0x81, 0xFF}}},
	{{{-19, 98, -107}, 0, {384, 1390}, {0x02, 0xFE, 0x81, 0xFF}}},
	{{{230, 86, -102}, 0, {355, 706}, {0x02, 0xFE, 0x81, 0xFF}}},
	{{{223, -52, -102}, 0, {0, 725}, {0x02, 0xFE, 0x81, 0xFF}}},
	{{{-31, -111, 0}, 0, {872, 2112}, {0x01, 0x91, 0xC2, 0xFF}}},
	{{{-19, -52, -104}, 0, {1208, 2077}, {0x01, 0x91, 0xC2, 0xFF}}},
	{{{223, -52, -102}, 0, {1203, 1396}, {0x01, 0x91, 0xC2, 0xFF}}},
	{{{223, -105, 0}, 0, {879, 1396}, {0x01, 0x91, 0xC2, 0xFF}}},
	{{{-19, 98, -107}, 0, {1745, 1312}, {0x05, 0x72, 0xC8, 0xFF}}},
	{{{-57, 151, 0}, 0, {1856, 992}, {0x05, 0x72, 0xC8, 0xFF}}},
	{{{233, 139, 0}, 0, {1056, 992}, {0x05, 0x72, 0xC8, 0xFF}}},
	{{{230, 86, -102}, 0, {1059, 1302}, {0x05, 0x72, 0xC8, 0xFF}}},
	{{{-57, 151, 0}, 0, {800, 1120}, {0x06, 0x72, 0x38, 0xFF}}},
	{{{-19, 98, 106}, 0, {480, 1228}, {0x06, 0x72, 0x38, 0xFF}}},
	{{{228, 86, 102}, 0, {480, 1907}, {0x06, 0x72, 0x38, 0xFF}}},
	{{{233, 139, 0}, 0, {791, 1920}, {0x06, 0x72, 0x38, 0xFF}}},
	{{{-19, 98, 106}, 0, {741, 0}, {0x02, 0x00, 0x7F, 0xFF}}},
	{{{-19, -52, 106}, 0, {741, 416}, {0x02, 0x00, 0x7F, 0xFF}}},
	{{{223, -52, 102}, 0, {1422, 416}, {0x02, 0x00, 0x7F, 0xFF}}},
	{{{228, 86, 102}, 0, {1435, 32}, {0x02, 0x00, 0x7F, 0xFF}}},
	{{{-19, -52, 106}, 0, {1199, 448}, {0x02, 0x91, 0x3D, 0xFF}}},
	{{{-31, -111, 0}, 0, {1160, 800}, {0x02, 0x91, 0x3D, 0xFF}}},
	{{{223, -105, 0}, 0, {1877, 800}, {0x02, 0x91, 0x3D, 0xFF}}},
	{{{223, -52, 102}, 0, {1880, 464}, {0x02, 0x91, 0x3D, 0xFF}}},
};

Gfx crasher_blue_Head_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Head_DL_mesh_layer_1_vtx_0 + 0, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
	gsSPVertex(crasher_blue_Head_DL_mesh_layer_1_vtx_0 + 30, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(18, 19, 20, 0, 18, 20, 21, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSPVertex(crasher_blue_Head_DL_mesh_layer_1_vtx_0 + 60, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Wing_DL_mesh_layer_4_vtx_0[4] = {
	{{{96, -22, 8}, 0, {-16, 1978}, {0xE9, 0x00, 0x7D, 0xFF}}},
	{{{200, -22, 27}, 0, {974, 1978}, {0xE9, 0x00, 0x7D, 0xFF}}},
	{{{200, 190, 27}, 0, {974, -34}, {0xE9, 0x00, 0x7D, 0xFF}}},
	{{{96, 190, 8}, 0, {-16, -34}, {0xE9, 0x00, 0x7D, 0xFF}}},
};

Gfx crasher_blue_Left_Wing_DL_mesh_layer_4_tri_0[] = {
	gsSPVertex(crasher_blue_Left_Wing_DL_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Wing_DL_mesh_layer_4_vtx_1[4] = {
	{{{-7, 190, -11}, 0, {-16, -34}, {0xE9, 0x00, 0x7D, 0xFF}}},
	{{{96, -22, 8}, 0, {974, 1978}, {0xE9, 0x00, 0x7D, 0xFF}}},
	{{{96, 190, 8}, 0, {974, -34}, {0xE9, 0x00, 0x7D, 0xFF}}},
	{{{-7, -22, -11}, 0, {-16, 1978}, {0xE9, 0x00, 0x7D, 0xFF}}},
};

Gfx crasher_blue_Left_Wing_DL_mesh_layer_4_tri_1[] = {
	gsSPVertex(crasher_blue_Left_Wing_DL_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Wing_DL_mesh_layer_4_vtx_0[4] = {
	{{{94, -19, -2}, 0, {-16, 1978}, {0xE9, 0x00, 0x83, 0xFF}}},
	{{{198, 193, -21}, 0, {974, -34}, {0xE9, 0x00, 0x83, 0xFF}}},
	{{{198, -19, -21}, 0, {974, 1978}, {0xE9, 0x00, 0x83, 0xFF}}},
	{{{94, 193, -2}, 0, {-16, -34}, {0xE9, 0x00, 0x83, 0xFF}}},
};

Gfx crasher_blue_Right_Wing_DL_mesh_layer_4_tri_0[] = {
	gsSPVertex(crasher_blue_Right_Wing_DL_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Wing_DL_mesh_layer_4_vtx_1[4] = {
	{{{-9, 193, 17}, 0, {-16, -34}, {0xE9, 0x00, 0x83, 0xFF}}},
	{{{94, 193, -2}, 0, {974, -34}, {0xE9, 0x00, 0x83, 0xFF}}},
	{{{94, -19, -2}, 0, {974, 1978}, {0xE9, 0x00, 0x83, 0xFF}}},
	{{{-9, -19, 17}, 0, {-16, 1978}, {0xE9, 0x00, 0x83, 0xFF}}},
};

Gfx crasher_blue_Right_Wing_DL_mesh_layer_4_tri_1[] = {
	gsSPVertex(crasher_blue_Right_Wing_DL_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Arm_Color_mesh_layer_1_vtx_0[17] = {
	{{{12, -26, -27}, 0, {263, 368}, {0x90, 0xC4, 0x00, 0xFF}}},
	{{{12, -26, 19}, 0, {263, 368}, {0x90, 0xC4, 0x00, 0xFF}}},
	{{{-11, 17, -4}, 0, {199, 488}, {0x90, 0xC4, 0x00, 0xFF}}},
	{{{-11, 60, 19}, 0, {199, 609}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-11, 60, -27}, 0, {199, 609}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-11, 17, -4}, 0, {199, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-11, 60, -27}, 0, {199, 609}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{12, 17, -49}, 0, {263, 488}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{-11, 17, -4}, 0, {199, 488}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{12, -26, -27}, 0, {263, 368}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{12, -26, 19}, 0, {263, 368}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{12, 17, 42}, 0, {263, 488}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{-11, 17, -4}, 0, {199, 488}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{-11, 60, 19}, 0, {199, 609}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{69, -24, 18}, 0, {423, 373}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{12, -26, 19}, 0, {263, 368}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{12, -26, -27}, 0, {263, 368}, {0x04, 0x81, 0x00, 0xFF}}},
};

Gfx crasher_blue_Left_Arm_Color_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Left_Arm_Color_mesh_layer_1_vtx_0 + 0, 17, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 7, 9, 8, 0),
	gsSP2Triangles(10, 11, 12, 0, 11, 13, 12, 0),
	gsSP1Triangle(14, 15, 16, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Forearm_skinned_mesh_layer_1_vtx_0[17] = {
	{{{69, -24, 18}, 0, {423, 373}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{12, -26, -27}, 0, {263, 368}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{12, 17, -49}, 0, {263, 488}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{69, -24, 18}, 0, {423, 373}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{12, -26, -27}, 0, {263, 368}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{69, -24, 18}, 0, {423, 373}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{69, -24, 18}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{12, 17, -49}, 0, {263, 488}, {0x04, 0x3D, 0x91, 0xFF}}},
	{{{-11, 60, -27}, 0, {199, 609}, {0x04, 0x3D, 0x91, 0xFF}}},
	{{{-11, 60, -27}, 0, {199, 609}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{-11, 60, 19}, 0, {199, 609}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{-11, 60, 19}, 0, {199, 609}, {0x03, 0x3D, 0x70, 0xFF}}},
	{{{12, 17, 42}, 0, {263, 488}, {0x03, 0x3D, 0x70, 0xFF}}},
	{{{69, -24, 18}, 0, {423, 373}, {0x16, 0xC4, 0x6E, 0xFF}}},
	{{{12, 17, 42}, 0, {263, 488}, {0x04, 0xC4, 0x70, 0xFF}}},
	{{{12, -26, 19}, 0, {263, 368}, {0x04, 0xC4, 0x70, 0xFF}}},
	{{{69, -24, 18}, 0, {423, 373}, {0x04, 0xC4, 0x70, 0xFF}}},
};

Gfx crasher_blue_Left_Forearm_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Left_Forearm_skinned_mesh_layer_1_vtx_0 + 0, 17, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Forearm_mesh_layer_1_vtx_0[22] = {
	{{{-4, -24, -26}, 0, {423, 373}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{-4, -24, -26}, 0, {423, 373}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, -4}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, 40}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, -24, -26}, 0, {423, 373}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{-4, 17, -47}, 0, {423, 488}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{-4, -24, -26}, 0, {423, 373}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{41, -16, 13}, 0, {551, 397}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{-4, 17, -47}, 0, {423, 488}, {0x04, 0x3D, 0x91, 0xFF}}},
	{{{-4, 58, -26}, 0, {423, 604}, {0x04, 0x3D, 0x91, 0xFF}}},
	{{{-4, 58, -26}, 0, {423, 604}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{-4, 58, 18}, 0, {423, 604}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{-4, 58, 18}, 0, {423, 604}, {0x03, 0x3D, 0x70, 0xFF}}},
	{{{-4, 17, 40}, 0, {423, 488}, {0x03, 0x3D, 0x70, 0xFF}}},
	{{{-4, 58, 18}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, 40}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 58, -26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, -24, -26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{41, -16, 13}, 0, {551, 397}, {0x16, 0xC4, 0x6E, 0xFF}}},
	{{{41, 17, 31}, 0, {551, 488}, {0x16, 0xC4, 0x6E, 0xFF}}},
	{{{-4, 17, 40}, 0, {423, 488}, {0x16, 0xC4, 0x6E, 0xFF}}},
	{{{-4, 17, 40}, 0, {423, 488}, {0x04, 0xC4, 0x70, 0xFF}}},
};

Gfx crasher_blue_Left_Forearm_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Left_Forearm_mesh_layer_1_vtx_0 + 0, 14, 17),
	gsSP2Triangles(3, 4, 17, 0, 0, 18, 19, 0),
	gsSP2Triangles(20, 0, 19, 0, 21, 1, 2, 0),
	gsSP2Triangles(21, 2, 22, 0, 23, 24, 5, 0),
	gsSP2Triangles(25, 7, 8, 0, 25, 8, 26, 0),
	gsSP2Triangles(27, 9, 10, 0, 27, 10, 28, 0),
	gsSP2Triangles(29, 11, 12, 0, 29, 12, 30, 0),
	gsSPVertex(crasher_blue_Left_Forearm_mesh_layer_1_vtx_0 + 14, 8, 17),
	gsSP2Triangles(17, 18, 6, 0, 17, 6, 19, 0),
	gsSP2Triangles(20, 19, 6, 0, 13, 21, 22, 0),
	gsSP2Triangles(13, 22, 23, 0, 24, 14, 15, 0),
	gsSP1Triangle(24, 15, 16, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Forearm_mesh_layer_1_vtx_1[37] = {
	{{{-4, 17, -47}, 0, {423, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-4, -24, -26}, 0, {423, 373}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, -4}, 0, {423, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-4, -24, -26}, 0, {423, 373}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{41, -16, -23}, 0, {551, 397}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{41, -16, 13}, 0, {551, 397}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{-4, -24, -26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, -47}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 58, -26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, -47}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 58, -26}, 0, {423, 604}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, -4}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 58, 18}, 0, {423, 604}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, 40}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-4, 17, -47}, 0, {423, 488}, {0x27, 0xDD, 0x8C, 0xFF}}},
	{{{41, -16, -23}, 0, {551, 397}, {0x27, 0xDD, 0x8C, 0xFF}}},
	{{{-4, -24, -26}, 0, {423, 373}, {0x27, 0xDD, 0x8C, 0xFF}}},
	{{{41, 17, -32}, 0, {551, 488}, {0x27, 0xDD, 0x8C, 0xFF}}},
	{{{-4, 58, -26}, 0, {423, 604}, {0x0F, 0x24, 0x87, 0xFF}}},
	{{{41, 17, -32}, 0, {551, 488}, {0x0F, 0x24, 0x87, 0xFF}}},
	{{{-4, 17, -47}, 0, {423, 488}, {0x0F, 0x24, 0x87, 0xFF}}},
	{{{41, 50, -23}, 0, {551, 580}, {0x0F, 0x24, 0x87, 0xFF}}},
	{{{-4, 58, 18}, 0, {423, 604}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{41, 50, 13}, 0, {551, 580}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{41, 50, -23}, 0, {551, 580}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{-4, 58, -26}, 0, {423, 604}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{-4, 17, 40}, 0, {423, 488}, {0x14, 0x3D, 0x6E, 0xFF}}},
	{{{41, 17, 31}, 0, {551, 488}, {0x14, 0x3D, 0x6E, 0xFF}}},
	{{{41, 50, 13}, 0, {551, 580}, {0x14, 0x3D, 0x6E, 0xFF}}},
	{{{-4, 58, 18}, 0, {423, 604}, {0x14, 0x3D, 0x6E, 0xFF}}},
	{{{41, -16, -23}, 0, {551, 397}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{41, 17, -32}, 0, {551, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{41, 17, -5}, 0, {551, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{41, 50, -23}, 0, {551, 580}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{41, 50, 13}, 0, {551, 580}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{41, 17, 31}, 0, {551, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{41, -16, 13}, 0, {551, 397}, {0x7F, 0x00, 0x00, 0xFF}}},
};

Gfx crasher_blue_Left_Forearm_mesh_layer_1_tri_1[] = {
	gsSPVertex(crasher_blue_Left_Forearm_mesh_layer_1_vtx_1 + 0, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(10, 12, 11, 0, 12, 13, 11, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 17, 15, 0),
	gsSP2Triangles(18, 19, 20, 0, 18, 21, 19, 0),
	gsSP2Triangles(22, 23, 24, 0, 22, 24, 25, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSPVertex(crasher_blue_Left_Forearm_mesh_layer_1_vtx_1 + 30, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(3, 4, 2, 0, 4, 5, 2, 0),
	gsSP2Triangles(5, 6, 2, 0, 6, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_vtx_0[4] = {
	{{{41, 17, -32}, 0, {551, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{41, 17, -32}, 0, {551, 488}, {0xE0, 0x28, 0x8C, 0xFF}}},
	{{{41, 17, -32}, 0, {68, 177}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{41, 17, -32}, 0, {551, 488}, {0xEA, 0xD8, 0x8A, 0xFF}}},
};

Gfx crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_vtx_0 + 0, 4, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_0[10] = {
	{{{37, 47, 0}, 0, {669, 488}, {0xE0, 0x7B, 0xFC, 0xFF}}},
	{{{-5, 37, 38}, 0, {551, 577}, {0xE0, 0x7B, 0xFC, 0xFF}}},
	{{{-5, 37, 38}, 0, {157, 147}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 15, -21}, 0, {-20, 147}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{29, 21, -24}, 0, {647, 398}, {0xEA, 0x60, 0xB0, 0xFF}}},
	{{{37, 47, 0}, 0, {669, 488}, {0xEA, 0x60, 0xB0, 0xFF}}},
	{{{-5, 15, -21}, 0, {551, 400}, {0xEA, 0x60, 0xB0, 0xFF}}},
	{{{-5, 37, 38}, 0, {551, 577}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 10, 14}, 0, {551, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 15, -21}, 0, {551, 400}, {0x81, 0x00, 0x00, 0xFF}}},
};

Gfx crasher_blue_Left_Hand_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_0 + 0, 10, 4),
	gsSP2Triangles(4, 1, 5, 0, 6, 2, 7, 0),
	gsSP2Triangles(8, 3, 9, 0, 8, 10, 3, 0),
	gsSP2Triangles(11, 0, 12, 0, 0, 13, 12, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_1[56] = {
	{{{37, 47, 0}, 0, {669, 488}, {0xE0, 0x7B, 0xFC, 0xFF}}},
	{{{-5, 37, 38}, 0, {551, 577}, {0xE0, 0x7B, 0xFC, 0xFF}}},
	{{{29, 48, 47}, 0, {647, 613}, {0xE0, 0x7B, 0xFC, 0xFF}}},
	{{{29, 3, 64}, 0, {647, 613}, {0x4A, 0x25, 0x60, 0xFF}}},
	{{{63, 6, 37}, 0, {742, 544}, {0x4A, 0x25, 0x60, 0xFF}}},
	{{{29, 48, 47}, 0, {647, 613}, {0x4A, 0x25, 0x60, 0xFF}}},
	{{{37, 47, 0}, 0, {669, 488}, {0x2E, 0x47, 0xA2, 0xFF}}},
	{{{75, 31, 6}, 0, {774, 488}, {0x2E, 0x47, 0xA2, 0xFF}}},
	{{{29, 21, -24}, 0, {647, 398}, {0x2E, 0x47, 0xA2, 0xFF}}},
	{{{29, -28, -18}, 0, {647, 364}, {0x1F, 0x85, 0xF9, 0xFF}}},
	{{{67, -20, 13}, 0, {752, 454}, {0x1F, 0x85, 0xF9, 0xFF}}},
	{{{29, -31, 30}, 0, {647, 488}, {0x1F, 0x85, 0xF9, 0xFF}}},
	{{{63, 6, 37}, 0, {742, 544}, {0x7A, 0xF1, 0x21, 0xFF}}},
	{{{67, -20, 13}, 0, {752, 454}, {0x7A, 0xF1, 0x21, 0xFF}}},
	{{{75, 31, 6}, 0, {774, 488}, {0x7A, 0xF1, 0x21, 0xFF}}},
	{{{-5, 15, -21}, 0, {551, 400}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, -17, -9}, 0, {551, 400}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 10, 14}, 0, {551, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, -22, 27}, 0, {551, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 5, 50}, 0, {551, 577}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 37, 38}, 0, {551, 577}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{29, -31, 30}, 0, {647, 488}, {0xE3, 0x86, 0xEF, 0xFF}}},
	{{{-5, -22, 27}, 0, {551, 488}, {0xE3, 0x86, 0xEF, 0xFF}}},
	{{{-5, -17, -9}, 0, {551, 400}, {0xE3, 0x86, 0xEF, 0xFF}}},
	{{{29, -28, -18}, 0, {647, 364}, {0xE3, 0x86, 0xEF, 0xFF}}},
	{{{29, 3, 64}, 0, {647, 613}, {0xD6, 0xB3, 0x5B, 0xFF}}},
	{{{-5, 5, 50}, 0, {551, 577}, {0xD6, 0xB3, 0x5B, 0xFF}}},
	{{{-5, -22, 27}, 0, {551, 488}, {0xD6, 0xB3, 0x5B, 0xFF}}},
	{{{29, -31, 30}, 0, {647, 488}, {0xD6, 0xB3, 0x5B, 0xFF}}},
	{{{-5, -17, -9}, 0, {-20, 49}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, -22, 27}, 0, {68, 0}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 5, 50}, 0, {157, 49}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, -17, -9}, 0, {-20, 49}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 5, 50}, 0, {157, 49}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 15, -21}, 0, {-20, 147}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-5, 37, 38}, 0, {157, 147}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{29, 48, 47}, 0, {647, 613}, {0xD3, 0x2A, 0x6F, 0xFF}}},
	{{{-5, 37, 38}, 0, {551, 577}, {0xD3, 0x2A, 0x6F, 0xFF}}},
	{{{-5, 5, 50}, 0, {551, 577}, {0xD3, 0x2A, 0x6F, 0xFF}}},
	{{{29, 3, 64}, 0, {647, 613}, {0xD3, 0x2A, 0x6F, 0xFF}}},
	{{{29, 48, 47}, 0, {647, 613}, {0x58, 0x35, 0x4B, 0xFF}}},
	{{{63, 6, 37}, 0, {742, 544}, {0x58, 0x35, 0x4B, 0xFF}}},
	{{{75, 31, 6}, 0, {774, 488}, {0x58, 0x35, 0x4B, 0xFF}}},
	{{{37, 47, 0}, 0, {669, 488}, {0x58, 0x35, 0x4B, 0xFF}}},
	{{{29, -28, -18}, 0, {647, 364}, {0xD3, 0xD6, 0x91, 0xFF}}},
	{{{-5, -17, -9}, 0, {551, 400}, {0xD3, 0xD6, 0x91, 0xFF}}},
	{{{-5, 15, -21}, 0, {551, 400}, {0xD3, 0xD6, 0x91, 0xFF}}},
	{{{29, 21, -24}, 0, {647, 398}, {0xD3, 0xD6, 0x91, 0xFF}}},
	{{{29, 21, -24}, 0, {647, 398}, {0x49, 0xE8, 0x9B, 0xFF}}},
	{{{75, 31, 6}, 0, {774, 488}, {0x49, 0xE8, 0x9B, 0xFF}}},
	{{{67, -20, 13}, 0, {752, 454}, {0x49, 0xE8, 0x9B, 0xFF}}},
	{{{29, -28, -18}, 0, {647, 364}, {0x49, 0xE8, 0x9B, 0xFF}}},
	{{{29, -31, 30}, 0, {647, 488}, {0x3C, 0xB9, 0x57, 0xFF}}},
	{{{67, -20, 13}, 0, {752, 454}, {0x3C, 0xB9, 0x57, 0xFF}}},
	{{{63, 6, 37}, 0, {742, 544}, {0x3C, 0xB9, 0x57, 0xFF}}},
	{{{29, 3, 64}, 0, {647, 613}, {0x3C, 0xB9, 0x57, 0xFF}}},
};

Gfx crasher_blue_Left_Hand_DL_mesh_layer_1_tri_1[] = {
	gsSPVertex(crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(16, 18, 17, 0, 18, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 21, 22, 23, 0),
	gsSP2Triangles(21, 23, 24, 0, 25, 26, 27, 0),
	gsSP2Triangles(25, 27, 28, 0, 29, 30, 31, 0),
	gsSPVertex(crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_1 + 32, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_2[50] = {
	{{{38, 87, -90}, 0, {659, 24}, {0x81, 0xFE, 0xFB, 0xFF}}},
	{{{38, -108, -28}, 0, {621, 600}, {0x81, 0xFE, 0xFB, 0xFF}}},
	{{{34, 30, 19}, 0, {886, 288}, {0x81, 0xFE, 0xFB, 0xFF}}},
	{{{38, -108, -28}, 0, {621, 600}, {0x81, 0xFC, 0x01, 0xFF}}},
	{{{38, -86, 63}, 0, {881, 637}, {0x81, 0xFC, 0x01, 0xFF}}},
	{{{34, 30, 19}, 0, {886, 288}, {0x81, 0xFC, 0x01, 0xFF}}},
	{{{38, -86, 63}, 0, {881, 637}, {0x81, 0xFC, 0x02, 0xFF}}},
	{{{38, -42, 145}, 0, {1143, 608}, {0x81, 0xFC, 0x02, 0xFF}}},
	{{{34, 30, 19}, 0, {886, 288}, {0x81, 0xFC, 0x02, 0xFF}}},
	{{{38, -42, 145}, 0, {1143, 608}, {0x81, 0x02, 0x05, 0xFF}}},
	{{{38, 146, 62}, 0, {1121, 30}, {0x81, 0x02, 0x05, 0xFF}}},
	{{{34, 30, 19}, 0, {886, 288}, {0x81, 0x02, 0x05, 0xFF}}},
	{{{38, 146, 62}, 0, {1120, 30}, {0x81, 0x05, 0xFE, 0xFF}}},
	{{{38, 87, -90}, 0, {659, 24}, {0x81, 0x05, 0xFE, 0xFF}}},
	{{{34, 30, 19}, 0, {886, 288}, {0x81, 0x05, 0xFE, 0xFF}}},
	{{{77, -119, -33}, 0, {574, 635}, {0x7F, 0xFD, 0xF8, 0xFF}}},
	{{{77, 93, -101}, 0, {540, 9}, {0x7F, 0xFD, 0xF8, 0xFF}}},
	{{{83, -3, 31}, 0, {288, 395}, {0x7F, 0xFD, 0xF8, 0xFF}}},
	{{{77, -94, 66}, 0, {289, 672}, {0x7F, 0xF8, 0x02, 0xFF}}},
	{{{77, -119, -33}, 0, {574, 635}, {0x7F, 0xF8, 0x02, 0xFF}}},
	{{{83, -3, 31}, 0, {288, 395}, {0x7F, 0xF8, 0x02, 0xFF}}},
	{{{77, -46, 156}, 0, {2, 635}, {0x7F, 0xF9, 0x04, 0xFF}}},
	{{{77, -94, 66}, 0, {287, 672}, {0x7F, 0xF9, 0x04, 0xFF}}},
	{{{83, -3, 31}, 0, {288, 395}, {0x7F, 0xF9, 0x04, 0xFF}}},
	{{{77, 157, 66}, 0, {36, 9}, {0x7F, 0x03, 0x08, 0xFF}}},
	{{{77, -46, 156}, 0, {2, 635}, {0x7F, 0x03, 0x08, 0xFF}}},
	{{{83, -3, 31}, 0, {288, 395}, {0x7F, 0x03, 0x08, 0xFF}}},
	{{{77, 93, -101}, 0, {540, 9}, {0x7F, 0x06, 0xFE, 0xFF}}},
	{{{77, 157, 66}, 0, {36, 9}, {0x7F, 0x06, 0xFE, 0xFF}}},
	{{{83, -3, 31}, 0, {288, 395}, {0x7F, 0x06, 0xFE, 0xFF}}},
	{{{77, -119, -33}, 0, {17, 1331}, {0xE6, 0xDA, 0x8A, 0xFF}}},
	{{{38, -108, -28}, 0, {128, 1307}, {0xE6, 0xDA, 0x8A, 0xFF}}},
	{{{38, 87, -90}, 0, {128, 729}, {0xE6, 0xDA, 0x8A, 0xFF}}},
	{{{77, 93, -101}, 0, {17, 704}, {0xE6, 0xDA, 0x8A, 0xFF}}},
	{{{77, 93, -101}, 0, {668, 928}, {0xE2, 0x73, 0xD4, 0xFF}}},
	{{{38, 87, -90}, 0, {647, 832}, {0xE2, 0x73, 0xD4, 0xFF}}},
	{{{38, 146, 62}, 0, {185, 832}, {0xE2, 0x73, 0xD4, 0xFF}}},
	{{{77, 157, 66}, 0, {164, 928}, {0xE2, 0x73, 0xD4, 0xFF}}},
	{{{77, -94, 66}, 0, {992, 951}, {0xE3, 0x88, 0x1D, 0xFF}}},
	{{{38, -86, 63}, 0, {992, 840}, {0xE3, 0x88, 0x1D, 0xFF}}},
	{{{38, -108, -28}, 0, {728, 832}, {0xE3, 0x88, 0x1D, 0xFF}}},
	{{{77, -119, -33}, 0, {704, 943}, {0xE3, 0x88, 0x1D, 0xFF}}},
	{{{77, -46, 156}, 0, {177, 1247}, {0xE2, 0x93, 0x3A, 0xFF}}},
	{{{38, -42, 145}, 0, {288, 1223}, {0xE2, 0x93, 0x3A, 0xFF}}},
	{{{38, -86, 63}, 0, {280, 960}, {0xE2, 0x93, 0x3A, 0xFF}}},
	{{{77, -94, 66}, 0, {169, 960}, {0xE2, 0x93, 0x3A, 0xFF}}},
	{{{77, 157, 66}, 0, {1203, 783}, {0xE6, 0x32, 0x72, 0xFF}}},
	{{{38, 146, 62}, 0, {1178, 672}, {0xE6, 0x32, 0x72, 0xFF}}},
	{{{38, -42, 145}, 0, {600, 672}, {0xE6, 0x32, 0x72, 0xFF}}},
	{{{77, -46, 156}, 0, {576, 783}, {0xE6, 0x32, 0x72, 0xFF}}},
};

Gfx crasher_blue_Left_Hand_DL_mesh_layer_1_tri_2[] = {
	gsSPVertex(crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_2 + 0, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 27, 28, 29, 0),
	gsSPVertex(crasher_blue_Left_Hand_DL_mesh_layer_1_vtx_2 + 30, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Arm_Color_mesh_layer_1_vtx_0[20] = {
	{{{15, -26, -19}, 0, {263, 368}, {0x90, 0xC4, 0x00, 0xFF}}},
	{{{15, -26, 27}, 0, {263, 368}, {0x90, 0xC4, 0x00, 0xFF}}},
	{{{-8, 17, 4}, 0, {199, 488}, {0x90, 0xC4, 0x00, 0xFF}}},
	{{{-8, 60, 27}, 0, {199, 609}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-8, 60, -19}, 0, {199, 609}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-8, 17, 4}, 0, {199, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{15, 17, 49}, 0, {263, 488}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{-8, 60, 27}, 0, {199, 609}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{-8, 17, 4}, 0, {199, 488}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{15, -26, 27}, 0, {263, 368}, {0x91, 0xE3, 0x37, 0xFF}}},
	{{{15, 17, -42}, 0, {263, 488}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{15, -26, -19}, 0, {263, 368}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{-8, 17, 4}, 0, {199, 488}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{-8, 60, -19}, 0, {199, 609}, {0x91, 0xE3, 0xC9, 0xFF}}},
	{{{15, -26, 27}, 0, {263, 368}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{15, -26, -19}, 0, {263, 368}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{72, -24, -18}, 0, {423, 373}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{15, 17, -42}, 0, {263, 488}, {0x03, 0x3D, 0x90, 0xFF}}},
	{{{-8, 60, -19}, 0, {199, 609}, {0x03, 0x3D, 0x90, 0xFF}}},
	{{{72, 58, -18}, 0, {423, 604}, {0x03, 0x3D, 0x90, 0xFF}}},
};

Gfx crasher_blue_Right_Arm_Color_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Right_Arm_Color_mesh_layer_1_vtx_0 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 6, 8, 0),
	gsSP2Triangles(10, 11, 12, 0, 13, 10, 12, 0),
	gsSP2Triangles(14, 15, 16, 0, 17, 18, 19, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Forearm_skinned_mesh_layer_1_vtx_0[23] = {
	{{{15, 17, 49}, 0, {263, 488}, {0x04, 0xC4, 0x70, 0xFF}}},
	{{{15, -26, 27}, 0, {263, 368}, {0x04, 0xC4, 0x70, 0xFF}}},
	{{{72, 17, 4}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{15, -26, 27}, 0, {263, 368}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{72, -24, -18}, 0, {423, 373}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{72, -24, -18}, 0, {423, 373}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{72, -24, -18}, 0, {423, 373}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{72, -24, -18}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-8, 60, 27}, 0, {199, 609}, {0x04, 0x3D, 0x6F, 0xFF}}},
	{{{15, 17, 49}, 0, {263, 488}, {0x04, 0x3D, 0x6F, 0xFF}}},
	{{{72, 58, -18}, 0, {423, 604}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{-8, 60, -19}, 0, {199, 609}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{-8, 60, 27}, 0, {199, 609}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{72, 58, -18}, 0, {423, 604}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{72, 58, -18}, 0, {423, 604}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{72, 58, -18}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{72, 58, -18}, 0, {423, 604}, {0x14, 0x3D, 0x92, 0xFF}}},
	{{{72, -24, -18}, 0, {423, 373}, {0x16, 0xC4, 0x92, 0xFF}}},
	{{{15, -26, -19}, 0, {263, 368}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{15, 17, -42}, 0, {263, 488}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{72, -24, -18}, 0, {423, 373}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{15, 17, -42}, 0, {263, 488}, {0x03, 0x3D, 0x90, 0xFF}}},
	{{{72, 58, -18}, 0, {423, 604}, {0x03, 0x3D, 0x90, 0xFF}}},
};

Gfx crasher_blue_Right_Forearm_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Right_Forearm_skinned_mesh_layer_1_vtx_0 + 0, 23, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Forearm_mesh_layer_1_vtx_0[25] = {
	{{{-7, -24, 26}, 0, {423, 373}, {0x04, 0x81, 0x00, 0xFF}}},
	{{{-7, 17, -40}, 0, {423, 488}, {0x03, 0x3D, 0x90, 0xFF}}},
	{{{-7, -24, 26}, 0, {423, 373}, {0x04, 0xC4, 0x70, 0xFF}}},
	{{{-7, 17, 47}, 0, {423, 488}, {0x04, 0xC4, 0x70, 0xFF}}},
	{{{39, -16, -13}, 0, {551, 397}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{-7, -24, 26}, 0, {423, 373}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{-7, 17, 47}, 0, {423, 488}, {0x04, 0x3D, 0x6F, 0xFF}}},
	{{{-7, 58, 26}, 0, {423, 604}, {0x04, 0x3D, 0x6F, 0xFF}}},
	{{{39, 50, 23}, 0, {551, 580}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{39, 50, -13}, 0, {551, 580}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{-7, 58, 26}, 0, {423, 604}, {0x17, 0x7D, 0x00, 0xFF}}},
	{{{-7, 58, 26}, 0, {423, 604}, {0x03, 0x7F, 0x00, 0xFF}}},
	{{{39, 50, -13}, 0, {551, 580}, {0x14, 0x3D, 0x92, 0xFF}}},
	{{{-7, 17, -40}, 0, {423, 488}, {0x14, 0x3D, 0x92, 0xFF}}},
	{{{39, 17, -31}, 0, {551, 488}, {0x16, 0xC4, 0x92, 0xFF}}},
	{{{39, -16, -13}, 0, {551, 397}, {0x16, 0xC4, 0x92, 0xFF}}},
	{{{-7, 17, -40}, 0, {423, 488}, {0x16, 0xC4, 0x92, 0xFF}}},
	{{{-7, 17, -40}, 0, {423, 488}, {0x04, 0xC4, 0x90, 0xFF}}},
	{{{-7, 17, -40}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, 58, 26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, -24, 26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, 17, 47}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, -24, 26}, 0, {423, 373}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, 17, -40}, 0, {423, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, 58, 26}, 0, {423, 604}, {0x7F, 0x00, 0x00, 0xFF}}},
};

Gfx crasher_blue_Right_Forearm_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Right_Forearm_mesh_layer_1_vtx_0 + 0, 8, 23),
	gsSP2Triangles(3, 4, 23, 0, 21, 22, 24, 0),
	gsSP2Triangles(0, 1, 25, 0, 0, 25, 26, 0),
	gsSP2Triangles(27, 28, 6, 0, 8, 9, 29, 0),
	gsSP1Triangle(8, 29, 30, 0),
	gsSPVertex(crasher_blue_Right_Forearm_mesh_layer_1_vtx_0 + 8, 9, 23),
	gsSP2Triangles(23, 24, 10, 0, 23, 10, 25, 0),
	gsSP2Triangles(11, 12, 26, 0, 11, 26, 13, 0),
	gsSP2Triangles(27, 28, 16, 0, 29, 30, 17, 0),
	gsSP1Triangle(29, 17, 31, 0),
	gsSPVertex(crasher_blue_Right_Forearm_mesh_layer_1_vtx_0 + 17, 8, 23),
	gsSP2Triangles(18, 19, 23, 0, 18, 23, 20, 0),
	gsSP2Triangles(7, 24, 15, 0, 7, 15, 25, 0),
	gsSP2Triangles(25, 26, 7, 0, 27, 28, 2, 0),
	gsSP2Triangles(28, 5, 2, 0, 5, 29, 2, 0),
	gsSP2Triangles(29, 14, 2, 0, 14, 30, 2, 0),
	gsSP1Triangle(30, 27, 2, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Forearm_mesh_layer_1_vtx_1[18] = {
	{{{39, -16, -13}, 0, {551, 397}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{39, -16, 23}, 0, {551, 397}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{-7, -24, 26}, 0, {423, 373}, {0x17, 0x83, 0x00, 0xFF}}},
	{{{-7, 58, 26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, 17, 47}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-7, -24, 26}, 0, {0, 0}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, 50, -13}, 0, {551, 580}, {0x14, 0x3D, 0x92, 0xFF}}},
	{{{39, 17, -31}, 0, {551, 488}, {0x14, 0x3D, 0x92, 0xFF}}},
	{{{-7, 17, -40}, 0, {423, 488}, {0x14, 0x3D, 0x92, 0xFF}}},
	{{{39, -16, 23}, 0, {551, 397}, {0x27, 0xDD, 0x74, 0xFF}}},
	{{{-7, 17, 47}, 0, {423, 488}, {0x27, 0xDD, 0x74, 0xFF}}},
	{{{-7, -24, 26}, 0, {423, 373}, {0x27, 0xDD, 0x74, 0xFF}}},
	{{{39, 50, -13}, 0, {551, 580}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, 50, 23}, 0, {551, 580}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, 17, 5}, 0, {551, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, 17, -31}, 0, {551, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, -16, -13}, 0, {551, 397}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, -16, 23}, 0, {551, 397}, {0x7F, 0x00, 0x00, 0xFF}}},
};

Gfx crasher_blue_Right_Forearm_mesh_layer_1_tri_1[] = {
	gsSPVertex(crasher_blue_Right_Forearm_mesh_layer_1_vtx_1 + 0, 18, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 12, 14, 0),
	gsSP2Triangles(16, 15, 14, 0, 17, 16, 14, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_vtx_0[8] = {
	{{{39, -16, 23}, 0, {551, 397}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, 17, 5}, 0, {551, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, -16, 23}, 0, {551, 397}, {0x27, 0xDD, 0x74, 0xFF}}},
	{{{-7, 17, 47}, 0, {423, 488}, {0x27, 0xDD, 0x74, 0xFF}}},
	{{{39, 50, 23}, 0, {551, 580}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{39, 50, 23}, 0, {551, 580}, {0x0F, 0x24, 0x79, 0xFF}}},
	{{{-7, 58, 26}, 0, {423, 604}, {0x0F, 0x24, 0x79, 0xFF}}},
	{{{-7, 17, 47}, 0, {423, 488}, {0x0F, 0x24, 0x79, 0xFF}}},
};

Gfx crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_vtx_0 + 0, 8, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_0[3] = {
	{{{-10, 30, 12}, 0, {551, 488}, {0x27, 0x61, 0x48, 0xFF}}},
	{{{-10, 30, 12}, 0, {551, 488}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{-10, 30, 12}, 0, {551, 488}, {0x0F, 0x7E, 0x08, 0xFF}}},
};

Gfx crasher_blue_Right_Hand_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_0 + 0, 3, 8),
	gsSP2Triangles(2, 8, 3, 0, 9, 0, 1, 0),
	gsSP2Triangles(4, 9, 1, 0, 10, 5, 6, 0),
	gsSP1Triangle(10, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_1[61] = {
	{{{58, 0, -20}, 0, {742, 544}, {0x4A, 0x23, 0x9F, 0xFF}}},
	{{{24, -4, -48}, 0, {647, 613}, {0x4A, 0x23, 0x9F, 0xFF}}},
	{{{24, 41, -32}, 0, {647, 613}, {0x4A, 0x23, 0x9F, 0xFF}}},
	{{{69, 25, 10}, 0, {774, 488}, {0x2E, 0x49, 0x5D, 0xFF}}},
	{{{32, 41, 16}, 0, {669, 488}, {0x2E, 0x49, 0x5D, 0xFF}}},
	{{{24, 15, 40}, 0, {647, 398}, {0x2E, 0x49, 0x5D, 0xFF}}},
	{{{62, -27, 4}, 0, {752, 454}, {0x1F, 0x85, 0x09, 0xFF}}},
	{{{24, -34, 35}, 0, {647, 364}, {0x1F, 0x85, 0x09, 0xFF}}},
	{{{24, -38, -13}, 0, {647, 488}, {0x1F, 0x85, 0x09, 0xFF}}},
	{{{62, -27, 4}, 0, {752, 454}, {0x7A, 0xF1, 0xDF, 0xFF}}},
	{{{58, 0, -20}, 0, {742, 544}, {0x7A, 0xF1, 0xDF, 0xFF}}},
	{{{69, 25, 10}, 0, {774, 488}, {0x7A, 0xF1, 0xDF, 0xFF}}},
	{{{-10, 30, 12}, 0, {551, 488}, {0xEA, 0x61, 0x4E, 0xFF}}},
	{{{-10, 9, 37}, 0, {551, 400}, {0xEA, 0x61, 0x4E, 0xFF}}},
	{{{24, 15, 40}, 0, {647, 398}, {0xEA, 0x61, 0x4E, 0xFF}}},
	{{{32, 41, 16}, 0, {669, 488}, {0xEA, 0x61, 0x4E, 0xFF}}},
	{{{-10, 9, 37}, 0, {551, 400}, {0xD3, 0xD7, 0x70, 0xFF}}},
	{{{-10, -23, 26}, 0, {551, 400}, {0xD3, 0xD7, 0x70, 0xFF}}},
	{{{24, -34, 35}, 0, {647, 364}, {0xD3, 0xD7, 0x70, 0xFF}}},
	{{{24, 15, 40}, 0, {647, 398}, {0xD3, 0xD7, 0x70, 0xFF}}},
	{{{-10, 9, 37}, 0, {-20, 147}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, 30, 12}, 0, {68, 177}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, 31, -22}, 0, {157, 147}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, -2, -33}, 0, {157, 49}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, -23, 26}, 0, {-20, 49}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, -29, -10}, 0, {68, 0}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, -23, 26}, 0, {551, 400}, {0xE3, 0x86, 0x13, 0xFF}}},
	{{{-10, -29, -10}, 0, {551, 488}, {0xE3, 0x86, 0x13, 0xFF}}},
	{{{24, -38, -13}, 0, {647, 488}, {0xE3, 0x86, 0x13, 0xFF}}},
	{{{24, -34, 35}, 0, {647, 364}, {0xE3, 0x86, 0x13, 0xFF}}},
	{{{-10, -29, -10}, 0, {551, 488}, {0xD6, 0xB1, 0xA6, 0xFF}}},
	{{{-10, -2, -33}, 0, {551, 577}, {0xD6, 0xB1, 0xA6, 0xFF}}},
	{{{24, -4, -48}, 0, {647, 613}, {0xD6, 0xB1, 0xA6, 0xFF}}},
	{{{24, -38, -13}, 0, {647, 488}, {0xD6, 0xB1, 0xA6, 0xFF}}},
	{{{-10, 31, -22}, 0, {551, 577}, {0xE0, 0x7B, 0x03, 0xFF}}},
	{{{-10, 30, 12}, 0, {551, 488}, {0xE0, 0x7B, 0x03, 0xFF}}},
	{{{32, 41, 16}, 0, {669, 488}, {0xE0, 0x7B, 0x03, 0xFF}}},
	{{{24, 41, -32}, 0, {647, 613}, {0xE0, 0x7B, 0x03, 0xFF}}},
	{{{-10, -2, -33}, 0, {551, 577}, {0xD3, 0x29, 0x90, 0xFF}}},
	{{{-10, 31, -22}, 0, {551, 577}, {0xD3, 0x29, 0x90, 0xFF}}},
	{{{24, 41, -32}, 0, {647, 613}, {0xD3, 0x29, 0x90, 0xFF}}},
	{{{24, -4, -48}, 0, {647, 613}, {0xD3, 0x29, 0x90, 0xFF}}},
	{{{69, 25, 10}, 0, {774, 488}, {0x58, 0x34, 0xB4, 0xFF}}},
	{{{58, 0, -20}, 0, {742, 544}, {0x58, 0x34, 0xB4, 0xFF}}},
	{{{24, 41, -32}, 0, {647, 613}, {0x58, 0x34, 0xB4, 0xFF}}},
	{{{32, 41, 16}, 0, {669, 488}, {0x58, 0x34, 0xB4, 0xFF}}},
	{{{62, -27, 4}, 0, {752, 454}, {0x49, 0xEA, 0x66, 0xFF}}},
	{{{69, 25, 10}, 0, {774, 488}, {0x49, 0xEA, 0x66, 0xFF}}},
	{{{24, 15, 40}, 0, {647, 398}, {0x49, 0xEA, 0x66, 0xFF}}},
	{{{24, -34, 35}, 0, {647, 364}, {0x49, 0xEA, 0x66, 0xFF}}},
	{{{58, 0, -20}, 0, {742, 544}, {0x3C, 0xB8, 0xAA, 0xFF}}},
	{{{62, -27, 4}, 0, {752, 454}, {0x3C, 0xB8, 0xAA, 0xFF}}},
	{{{24, -38, -13}, 0, {647, 488}, {0x3C, 0xB8, 0xAA, 0xFF}}},
	{{{24, -4, -48}, 0, {647, 613}, {0x3C, 0xB8, 0xAA, 0xFF}}},
	{{{-10, 30, 12}, 0, {551, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, 31, -22}, 0, {551, 577}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, 4, 2}, 0, {551, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, -2, -33}, 0, {551, 577}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, -29, -10}, 0, {551, 488}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, -23, 26}, 0, {551, 400}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-10, 9, 37}, 0, {551, 400}, {0x81, 0x00, 0x00, 0xFF}}},
};

Gfx crasher_blue_Right_Hand_DL_mesh_layer_1_tri_1[] = {
	gsSPVertex(crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_1 + 0, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSP2Triangles(23, 24, 20, 0, 23, 25, 24, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSPVertex(crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_1 + 30, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 25, 27, 26, 0),
	gsSP2Triangles(27, 28, 26, 0, 28, 29, 26, 0),
	gsSP2Triangles(29, 30, 26, 0, 30, 24, 26, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_2[109] = {
	{{{244, -259, -70}, 0, {320, 97}, {0x0C, 0xC5, 0x70, 0xFF}}},
	{{{215, -279, -77}, 0, {416, 97}, {0x0C, 0xC5, 0x70, 0xFF}}},
	{{{250, -294, -89}, 0, {368, 0}, {0x0C, 0xC5, 0x70, 0xFF}}},
	{{{215, -279, -77}, 0, {195, 108}, {0xD2, 0x8B, 0x13, 0xFF}}},
	{{{200, -278, -108}, 0, {288, 109}, {0xD2, 0x8B, 0x13, 0xFF}}},
	{{{250, -294, -89}, 0, {185, 0}, {0xD2, 0x8B, 0x13, 0xFF}}},
	{{{200, -278, -108}, 0, {739, 103}, {0xFF, 0x9E, 0xB0, 0xFF}}},
	{{{215, -258, -133}, 0, {800, 173}, {0xFF, 0x9E, 0xB0, 0xFF}}},
	{{{250, -294, -89}, 0, {848, 0}, {0xFF, 0x9E, 0xB0, 0xFF}}},
	{{{244, -239, -126}, 0, {896, 173}, {0x71, 0xEA, 0xCB, 0xFF}}},
	{{{258, -239, -94}, 0, {957, 103}, {0x71, 0xEA, 0xCB, 0xFF}}},
	{{{250, -294, -89}, 0, {848, 0}, {0x71, 0xEA, 0xCB, 0xFF}}},
	{{{258, -239, -94}, 0, {0, 109}, {0x71, 0xF4, 0x39, 0xFF}}},
	{{{244, -259, -70}, 0, {93, 108}, {0x71, 0xF4, 0x39, 0xFF}}},
	{{{250, -294, -89}, 0, {103, 0}, {0x71, 0xF4, 0x39, 0xFF}}},
	{{{215, -258, -133}, 0, {800, 173}, {0x3D, 0xC7, 0xA0, 0xFF}}},
	{{{244, -239, -126}, 0, {896, 173}, {0x3D, 0xC7, 0xA0, 0xFF}}},
	{{{250, -294, -89}, 0, {848, 0}, {0x3D, 0xC7, 0xA0, 0xFF}}},
	{{{20, 52, -14}, 0, {488, 1027}, {0x58, 0x52, 0xD6, 0xFF}}},
	{{{32, 52, 12}, 0, {563, 1027}, {0x58, 0x52, 0xD6, 0xFF}}},
	{{{115, -59, -28}, 0, {563, 643}, {0x58, 0x52, 0xD6, 0xFF}}},
	{{{103, -58, -54}, 0, {488, 643}, {0x58, 0x52, 0xD6, 0xFF}}},
	{{{129, -77, -35}, 0, {563, 579}, {0x58, 0x52, 0xD6, 0xFF}}},
	{{{117, -77, -61}, 0, {488, 579}, {0x58, 0x52, 0xD6, 0xFF}}},
	{{{-4, 36, -20}, 0, {744, 1636}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{20, 52, -14}, 0, {824, 1636}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{103, -58, -54}, 0, {824, 1252}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{79, -75, -60}, 0, {744, 1252}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{117, -77, -61}, 0, {824, 1188}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{92, -93, -66}, 0, {744, 1188}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{32, 52, 12}, 0, {12, 1135}, {0x58, 0x24, 0x54, 0xFF}}},
	{{{20, 35, 31}, 0, {88, 1135}, {0x58, 0x24, 0x54, 0xFF}}},
	{{{103, -75, -9}, 0, {88, 751}, {0x58, 0x24, 0x54, 0xFF}}},
	{{{115, -59, -28}, 0, {12, 751}, {0x58, 0x24, 0x54, 0xFF}}},
	{{{117, -93, -16}, 0, {88, 687}, {0x58, 0x24, 0x54, 0xFF}}},
	{{{129, -77, -35}, 0, {12, 687}, {0x58, 0x24, 0x54, 0xFF}}},
	{{{20, 35, 31}, 0, {328, 1125}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{-4, 19, 25}, 0, {408, 1125}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{79, -91, -15}, 0, {408, 741}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{103, -75, -9}, 0, {328, 741}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{92, -109, -21}, 0, {408, 677}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{117, -93, -16}, 0, {328, 677}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{-4, 19, 25}, 0, {200, 1135}, {0xA8, 0xAE, 0x2A, 0xFF}}},
	{{{-17, 19, 0}, 0, {275, 1135}, {0xA8, 0xAE, 0x2A, 0xFF}}},
	{{{66, -91, -40}, 0, {275, 751}, {0xA8, 0xAE, 0x2A, 0xFF}}},
	{{{79, -91, -15}, 0, {200, 751}, {0xA8, 0xAE, 0x2A, 0xFF}}},
	{{{80, -109, -47}, 0, {275, 687}, {0xA8, 0xAE, 0x2A, 0xFF}}},
	{{{92, -109, -21}, 0, {200, 687}, {0xA8, 0xAE, 0x2A, 0xFF}}},
	{{{-17, 19, 0}, 0, {620, 1027}, {0xA8, 0xDC, 0xAC, 0xFF}}},
	{{{-4, 36, -20}, 0, {696, 1027}, {0xA8, 0xDC, 0xAC, 0xFF}}},
	{{{79, -75, -60}, 0, {696, 643}, {0xA8, 0xDC, 0xAC, 0xFF}}},
	{{{66, -91, -40}, 0, {620, 643}, {0xA8, 0xDC, 0xAC, 0xFF}}},
	{{{92, -93, -66}, 0, {696, 579}, {0xA8, 0xDC, 0xAC, 0xFF}}},
	{{{80, -109, -47}, 0, {620, 579}, {0xA8, 0xDC, 0xAC, 0xFF}}},
	{{{82, -122, -51}, 0, {284, 653}, {0x90, 0xE0, 0x33, 0xFF}}},
	{{{97, -122, -20}, 0, {191, 652}, {0x90, 0xE0, 0x33, 0xFF}}},
	{{{92, -109, -21}, 0, {200, 687}, {0x90, 0xE0, 0x33, 0xFF}}},
	{{{80, -109, -47}, 0, {275, 687}, {0x90, 0xE0, 0x33, 0xFF}}},
	{{{97, -122, -20}, 0, {416, 641}, {0xDF, 0x05, 0x7B, 0xFF}}},
	{{{117, -93, -16}, 0, {328, 677}, {0xDF, 0x05, 0x7B, 0xFF}}},
	{{{92, -109, -21}, 0, {408, 677}, {0xDF, 0x05, 0x7B, 0xFF}}},
	{{{126, -103, -13}, 0, {320, 641}, {0xDF, 0x05, 0x7B, 0xFF}}},
	{{{97, -102, -76}, 0, {705, 544}, {0x91, 0x05, 0xC2, 0xFF}}},
	{{{82, -122, -51}, 0, {612, 545}, {0x91, 0x05, 0xC2, 0xFF}}},
	{{{80, -109, -47}, 0, {620, 579}, {0x91, 0x05, 0xC2, 0xFF}}},
	{{{92, -93, -66}, 0, {696, 579}, {0x91, 0x05, 0xC2, 0xFF}}},
	{{{126, -103, -13}, 0, {97, 652}, {0x35, 0x48, 0x5A, 0xFF}}},
	{{{129, -77, -35}, 0, {12, 687}, {0x35, 0x48, 0x5A, 0xFF}}},
	{{{117, -93, -16}, 0, {88, 687}, {0x35, 0x48, 0x5A, 0xFF}}},
	{{{141, -83, -37}, 0, {4, 653}, {0x35, 0x48, 0x5A, 0xFF}}},
	{{{141, -83, -37}, 0, {572, 545}, {0x31, 0x73, 0xEB, 0xFF}}},
	{{{126, -82, -69}, 0, {479, 544}, {0x31, 0x73, 0xEB, 0xFF}}},
	{{{117, -77, -61}, 0, {488, 579}, {0x31, 0x73, 0xEB, 0xFF}}},
	{{{129, -77, -35}, 0, {563, 579}, {0x31, 0x73, 0xEB, 0xFF}}},
	{{{126, -82, -69}, 0, {832, 1152}, {0xDF, 0x52, 0xA5, 0xFF}}},
	{{{92, -93, -66}, 0, {744, 1188}, {0xDF, 0x52, 0xA5, 0xFF}}},
	{{{117, -77, -61}, 0, {824, 1188}, {0xDF, 0x52, 0xA5, 0xFF}}},
	{{{97, -102, -76}, 0, {736, 1152}, {0xDF, 0x52, 0xA5, 0xFF}}},
	{{{200, -278, -108}, 0, {288, 109}, {0xA7, 0xAF, 0x28, 0xFF}}},
	{{{215, -279, -77}, 0, {195, 108}, {0xA7, 0xAF, 0x28, 0xFF}}},
	{{{97, -122, -20}, 0, {191, 652}, {0xA7, 0xAF, 0x28, 0xFF}}},
	{{{82, -122, -51}, 0, {284, 653}, {0xA7, 0xAF, 0x28, 0xFF}}},
	{{{215, -279, -77}, 0, {416, 97}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{126, -103, -13}, 0, {320, 641}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{97, -122, -20}, 0, {416, 641}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{244, -259, -70}, 0, {320, 97}, {0x00, 0xD5, 0x77, 0xFF}}},
	{{{215, -258, -133}, 0, {701, 0}, {0xA7, 0xDB, 0xAD, 0xFF}}},
	{{{200, -278, -108}, 0, {608, 1}, {0xA7, 0xDB, 0xAD, 0xFF}}},
	{{{82, -122, -51}, 0, {612, 545}, {0xA7, 0xDB, 0xAD, 0xFF}}},
	{{{97, -102, -76}, 0, {705, 544}, {0xA7, 0xDB, 0xAD, 0xFF}}},
	{{{244, -259, -70}, 0, {93, 108}, {0x59, 0x25, 0x53, 0xFF}}},
	{{{141, -83, -37}, 0, {4, 653}, {0x59, 0x25, 0x53, 0xFF}}},
	{{{126, -103, -13}, 0, {97, 652}, {0x59, 0x25, 0x53, 0xFF}}},
	{{{258, -239, -94}, 0, {0, 109}, {0x59, 0x25, 0x53, 0xFF}}},
	{{{258, -239, -94}, 0, {576, 1}, {0x59, 0x51, 0xD8, 0xFF}}},
	{{{244, -239, -126}, 0, {483, 0}, {0x59, 0x51, 0xD8, 0xFF}}},
	{{{126, -82, -69}, 0, {479, 544}, {0x59, 0x51, 0xD8, 0xFF}}},
	{{{141, -83, -37}, 0, {572, 545}, {0x59, 0x51, 0xD8, 0xFF}}},
	{{{244, -239, -126}, 0, {832, 608}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{97, -102, -76}, 0, {736, 1152}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{126, -82, -69}, 0, {832, 1152}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{215, -258, -133}, 0, {736, 608}, {0x00, 0x2B, 0x89, 0xFF}}},
	{{{32, 52, 12}, 0, {896, 288}, {0xB7, 0x61, 0x23, 0xFF}}},
	{{{20, 52, -14}, 0, {856, 224}, {0xB7, 0x61, 0x23, 0xFF}}},
	{{{8, 35, 6}, 0, {816, 288}, {0xB7, 0x61, 0x23, 0xFF}}},
	{{{-4, 36, -20}, 0, {776, 224}, {0xB7, 0x61, 0x23, 0xFF}}},
	{{{-17, 19, 0}, 0, {736, 288}, {0xB7, 0x61, 0x23, 0xFF}}},
	{{{-4, 19, 25}, 0, {776, 352}, {0xB7, 0x61, 0x23, 0xFF}}},
	{{{20, 35, 31}, 0, {856, 352}, {0xB7, 0x61, 0x23, 0xFF}}},
};

Gfx crasher_blue_Right_Hand_DL_mesh_layer_1_tri_2[] = {
	gsSPVertex(crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_2 + 0, 30, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(18, 19, 20, 0, 18, 20, 21, 0),
	gsSP2Triangles(22, 21, 20, 0, 22, 23, 21, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 27, 26, 0, 28, 29, 27, 0),
	gsSPVertex(crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_2 + 30, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 4, 5, 3, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(10, 9, 8, 0, 10, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 15, 14, 0, 16, 17, 15, 0),
	gsSP2Triangles(18, 19, 20, 0, 18, 20, 21, 0),
	gsSP2Triangles(22, 21, 20, 0, 22, 23, 21, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPVertex(crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_2 + 62, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 23, 21, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPVertex(crasher_blue_Right_Hand_DL_mesh_layer_1_vtx_2 + 94, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(8, 9, 10, 0, 9, 11, 10, 0),
	gsSP2Triangles(11, 12, 10, 0, 12, 13, 10, 0),
	gsSP2Triangles(13, 14, 10, 0, 14, 8, 10, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Left_Shoe_mesh_layer_1_vtx_0[64] = {
	{{{-29, -7, 3}, 0, {480, 0}, {0xE2, 0x99, 0x44, 0xFF}}},
	{{{72, -8, 45}, 0, {345, 277}, {0xE2, 0x99, 0x44, 0xFF}}},
	{{{-13, 23, 50}, 0, {320, 22}, {0xE2, 0x99, 0x44, 0xFF}}},
	{{{73, -35, 4}, 0, {480, 298}, {0xE2, 0x99, 0x44, 0xFF}}},
	{{{88, 11, 50}, 0, {784, 611}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{-8, 46, 50}, 0, {496, 611}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{-13, 23, 50}, 0, {506, 544}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{72, -8, 45}, 0, {762, 544}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{-8, 46, 50}, 0, {593, 975}, {0x87, 0x11, 0x22, 0xFF}}},
	{{{-29, -7, 3}, 0, {460, 815}, {0x87, 0x11, 0x22, 0xFF}}},
	{{{-13, 23, 50}, 0, {593, 908}, {0x87, 0x11, 0x22, 0xFF}}},
	{{{-21, 48, 3}, 0, {460, 966}, {0x87, 0x11, 0x22, 0xFF}}},
	{{{109, -4, -2}, 0, {160, 941}, {0x51, 0xB0, 0x39, 0xFF}}},
	{{{88, 11, 50}, 0, {14, 961}, {0x51, 0xB0, 0x39, 0xFF}}},
	{{{72, -8, 45}, 0, {29, 894}, {0x51, 0xB0, 0x39, 0xFF}}},
	{{{73, -35, 4}, 0, {144, 823}, {0x51, 0xB0, 0x39, 0xFF}}},
	{{{-8, 46, 50}, 0, {448, 960}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{86, 30, 50}, 0, {714, 1009}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{0, 62, 43}, 0, {455, 1009}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{88, 11, 50}, 0, {736, 960}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{138, 12, -9}, 0, {116, 448}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{-10, 66, 3}, 0, {148, 4}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{0, 62, 43}, 0, {262, 35}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{86, 30, 50}, 0, {281, 294}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{-21, 48, 3}, 0, {460, 966}, {0x99, 0x44, 0x1F, 0xFF}}},
	{{{-8, 46, 50}, 0, {593, 975}, {0x99, 0x44, 0x1F, 0xFF}}},
	{{{0, 62, 43}, 0, {574, 1024}, {0x99, 0x44, 0x1F, 0xFF}}},
	{{{-10, 66, 3}, 0, {460, 1024}, {0x99, 0x44, 0x1F, 0xFF}}},
	{{{88, 11, 50}, 0, {14, 961}, {0x41, 0xA2, 0x37, 0xFF}}},
	{{{138, 12, -9}, 0, {180, 1010}, {0x41, 0xA2, 0x37, 0xFF}}},
	{{{86, 30, 50}, 0, {14, 1010}, {0x41, 0xA2, 0x37, 0xFF}}},
	{{{109, -4, -2}, 0, {160, 941}, {0x41, 0xA2, 0x37, 0xFF}}},
	{{{73, -35, 4}, 0, {470, 352}, {0xE5, 0x9E, 0xB4, 0xFF}}},
	{{{-29, -7, 3}, 0, {768, 352}, {0xE5, 0x9E, 0xB4, 0xFF}}},
	{{{-4, 19, -39}, 0, {720, 501}, {0xE5, 0x9E, 0xB4, 0xFF}}},
	{{{72, -8, -39}, 0, {493, 493}, {0xE5, 0x9E, 0xB4, 0xFF}}},
	{{{6, 41, -48}, 0, {664, 781}, {0xFD, 0xE7, 0x84, 0xFF}}},
	{{{72, -8, -39}, 0, {439, 712}, {0xFD, 0xE7, 0x84, 0xFF}}},
	{{{-4, 19, -39}, 0, {667, 710}, {0xFD, 0xE7, 0x84, 0xFF}}},
	{{{89, 16, -45}, 0, {421, 795}, {0xFD, 0xE7, 0x84, 0xFF}}},
	{{{-21, 48, 3}, 0, {460, 966}, {0x93, 0x17, 0xC3, 0xFF}}},
	{{{6, 41, -48}, 0, {318, 975}, {0x93, 0x17, 0xC3, 0xFF}}},
	{{{-4, 19, -39}, 0, {342, 908}, {0x93, 0x17, 0xC3, 0xFF}}},
	{{{-29, -7, 3}, 0, {460, 815}, {0x93, 0x17, 0xC3, 0xFF}}},
	{{{89, 16, -45}, 0, {281, 975}, {0x3E, 0xAB, 0xB9, 0xFF}}},
	{{{73, -35, 4}, 0, {144, 823}, {0x3E, 0xAB, 0xB9, 0xFF}}},
	{{{72, -8, -39}, 0, {266, 894}, {0x3E, 0xAB, 0xB9, 0xFF}}},
	{{{109, -4, -2}, 0, {160, 941}, {0x3E, 0xAB, 0xB9, 0xFF}}},
	{{{138, 12, -9}, 0, {180, 1010}, {0x27, 0x9B, 0xBD, 0xFF}}},
	{{{89, 16, -45}, 0, {281, 975}, {0x27, 0x9B, 0xBD, 0xFF}}},
	{{{87, 31, -42}, 0, {272, 1012}, {0x27, 0x9B, 0xBD, 0xFF}}},
	{{{109, -4, -2}, 0, {160, 941}, {0x27, 0x9B, 0xBD, 0xFF}}},
	{{{89, 16, -45}, 0, {421, 795}, {0x05, 0x02, 0x81, 0xFF}}},
	{{{12, 58, -47}, 0, {664, 830}, {0x05, 0x02, 0x81, 0xFF}}},
	{{{87, 31, -42}, 0, {440, 832}, {0x05, 0x02, 0x81, 0xFF}}},
	{{{6, 41, -48}, 0, {664, 781}, {0x05, 0x02, 0x81, 0xFF}}},
	{{{-10, 66, 3}, 0, {148, 4}, {0x2C, 0x77, 0x02, 0xFF}}},
	{{{138, 12, -9}, 0, {116, 448}, {0x2C, 0x77, 0x02, 0xFF}}},
	{{{87, 31, -42}, 0, {23, 294}, {0x2C, 0x77, 0x02, 0xFF}}},
	{{{12, 58, -47}, 0, {7, 70}, {0x2C, 0x77, 0x02, 0xFF}}},
	{{{6, 41, -48}, 0, {318, 975}, {0xA0, 0x3B, 0xC5, 0xFF}}},
	{{{-21, 48, 3}, 0, {460, 966}, {0xA0, 0x3B, 0xC5, 0xFF}}},
	{{{-10, 66, 3}, 0, {460, 1024}, {0xA0, 0x3B, 0xC5, 0xFF}}},
	{{{12, 58, -47}, 0, {320, 1024}, {0xA0, 0x3B, 0xC5, 0xFF}}},
};

Gfx crasher_blue_Left_Shoe_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Left_Shoe_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPVertex(crasher_blue_Left_Shoe_mesh_layer_1_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 23, 21, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_blue_Right_Shoe_DL_mesh_layer_1_vtx_0[64] = {
	{{{72, -8, -41}, 0, {345, 277}, {0xE2, 0x99, 0xBC, 0xFF}}},
	{{{-29, -7, 1}, 0, {480, 0}, {0xE2, 0x99, 0xBC, 0xFF}}},
	{{{-13, 23, -47}, 0, {320, 22}, {0xE2, 0x99, 0xBC, 0xFF}}},
	{{{73, -35, -1}, 0, {480, 298}, {0xE2, 0x99, 0xBC, 0xFF}}},
	{{{-13, 23, -47}, 0, {506, 544}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{-8, 46, -47}, 0, {496, 611}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{88, 11, -47}, 0, {784, 611}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{72, -8, -41}, 0, {762, 544}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{-29, -7, 1}, 0, {460, 815}, {0x87, 0x11, 0xDE, 0xFF}}},
	{{{-8, 46, -47}, 0, {593, 975}, {0x87, 0x11, 0xDE, 0xFF}}},
	{{{-13, 23, -47}, 0, {593, 908}, {0x87, 0x11, 0xDE, 0xFF}}},
	{{{-21, 48, 1}, 0, {460, 966}, {0x87, 0x11, 0xDE, 0xFF}}},
	{{{72, -8, -41}, 0, {29, 894}, {0x51, 0xB0, 0xC7, 0xFF}}},
	{{{88, 11, -47}, 0, {14, 961}, {0x51, 0xB0, 0xC7, 0xFF}}},
	{{{109, -4, 5}, 0, {160, 941}, {0x51, 0xB0, 0xC7, 0xFF}}},
	{{{73, -35, -1}, 0, {144, 823}, {0x51, 0xB0, 0xC7, 0xFF}}},
	{{{86, 30, -47}, 0, {714, 1009}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{-8, 46, -47}, 0, {448, 960}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{0, 62, -40}, 0, {455, 1009}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{88, 11, -47}, 0, {736, 960}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{0, 62, -40}, 0, {262, 35}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{-10, 66, 1}, 0, {148, 4}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{138, 12, 12}, 0, {116, 448}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{86, 30, -47}, 0, {281, 294}, {0x2B, 0x77, 0x00, 0xFF}}},
	{{{0, 62, -40}, 0, {574, 1024}, {0x99, 0x44, 0xE1, 0xFF}}},
	{{{-8, 46, -47}, 0, {593, 975}, {0x99, 0x44, 0xE1, 0xFF}}},
	{{{-21, 48, 1}, 0, {460, 966}, {0x99, 0x44, 0xE1, 0xFF}}},
	{{{-10, 66, 1}, 0, {460, 1024}, {0x99, 0x44, 0xE1, 0xFF}}},
	{{{138, 12, 12}, 0, {180, 1010}, {0x41, 0xA2, 0xC9, 0xFF}}},
	{{{88, 11, -47}, 0, {14, 961}, {0x41, 0xA2, 0xC9, 0xFF}}},
	{{{86, 30, -47}, 0, {14, 1010}, {0x41, 0xA2, 0xC9, 0xFF}}},
	{{{109, -4, 5}, 0, {160, 941}, {0x41, 0xA2, 0xC9, 0xFF}}},
	{{{-4, 19, 43}, 0, {720, 501}, {0xE5, 0x9E, 0x4C, 0xFF}}},
	{{{-29, -7, 1}, 0, {768, 352}, {0xE5, 0x9E, 0x4C, 0xFF}}},
	{{{73, -35, -1}, 0, {470, 352}, {0xE5, 0x9E, 0x4C, 0xFF}}},
	{{{72, -8, 43}, 0, {493, 493}, {0xE5, 0x9E, 0x4C, 0xFF}}},
	{{{72, -8, 43}, 0, {439, 712}, {0xFD, 0xE7, 0x7C, 0xFF}}},
	{{{6, 41, 51}, 0, {664, 781}, {0xFD, 0xE7, 0x7C, 0xFF}}},
	{{{-4, 19, 43}, 0, {667, 710}, {0xFD, 0xE7, 0x7C, 0xFF}}},
	{{{89, 16, 48}, 0, {421, 795}, {0xFD, 0xE7, 0x7C, 0xFF}}},
	{{{-4, 19, 43}, 0, {342, 908}, {0x93, 0x17, 0x3D, 0xFF}}},
	{{{6, 41, 51}, 0, {318, 975}, {0x93, 0x17, 0x3D, 0xFF}}},
	{{{-21, 48, 1}, 0, {460, 966}, {0x93, 0x17, 0x3D, 0xFF}}},
	{{{-29, -7, 1}, 0, {460, 815}, {0x93, 0x17, 0x3D, 0xFF}}},
	{{{73, -35, -1}, 0, {144, 823}, {0x3E, 0xAB, 0x47, 0xFF}}},
	{{{89, 16, 48}, 0, {281, 975}, {0x3E, 0xAB, 0x47, 0xFF}}},
	{{{72, -8, 43}, 0, {266, 894}, {0x3E, 0xAB, 0x47, 0xFF}}},
	{{{109, -4, 5}, 0, {160, 941}, {0x3E, 0xAB, 0x47, 0xFF}}},
	{{{89, 16, 48}, 0, {281, 975}, {0x27, 0x9B, 0x43, 0xFF}}},
	{{{138, 12, 12}, 0, {180, 1010}, {0x27, 0x9B, 0x43, 0xFF}}},
	{{{87, 31, 45}, 0, {272, 1012}, {0x27, 0x9B, 0x43, 0xFF}}},
	{{{109, -4, 5}, 0, {160, 941}, {0x27, 0x9B, 0x43, 0xFF}}},
	{{{12, 58, 50}, 0, {664, 830}, {0x05, 0x02, 0x7F, 0xFF}}},
	{{{89, 16, 48}, 0, {421, 795}, {0x05, 0x02, 0x7F, 0xFF}}},
	{{{87, 31, 45}, 0, {440, 832}, {0x05, 0x02, 0x7F, 0xFF}}},
	{{{6, 41, 51}, 0, {664, 781}, {0x05, 0x02, 0x7F, 0xFF}}},
	{{{87, 31, 45}, 0, {23, 294}, {0x2C, 0x77, 0xFE, 0xFF}}},
	{{{138, 12, 12}, 0, {116, 448}, {0x2C, 0x77, 0xFE, 0xFF}}},
	{{{-10, 66, 1}, 0, {148, 4}, {0x2C, 0x77, 0xFE, 0xFF}}},
	{{{12, 58, 50}, 0, {7, 70}, {0x2C, 0x77, 0xFE, 0xFF}}},
	{{{-10, 66, 1}, 0, {460, 1024}, {0xA0, 0x3B, 0x3B, 0xFF}}},
	{{{-21, 48, 1}, 0, {460, 966}, {0xA0, 0x3B, 0x3B, 0xFF}}},
	{{{6, 41, 51}, 0, {318, 975}, {0xA0, 0x3B, 0x3B, 0xFF}}},
	{{{12, 58, 50}, 0, {320, 1024}, {0xA0, 0x3B, 0x3B, 0xFF}}},
};

Gfx crasher_blue_Right_Shoe_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_blue_Right_Shoe_DL_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPVertex(crasher_blue_Right_Shoe_DL_mesh_layer_1_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 15, 13, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 23, 21, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPEndDisplayList(),
};


Gfx mat_crasher_blue_NumB[] = {
	gsSPSetLights1(crasher_blue_NumB_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_castle_body_blue_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 16383, 64),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 32, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 7, 0),
	gsDPSetTileSize(0, 0, 0, 508, 508),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_NumB[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Metal__METAL_[] = {
	gsSPSetGeometryMode(G_TEXTURE_GEN),
	gsSPSetLights1(crasher_blue_Metal__METAL__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, TEXEL1, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, TEXEL1, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(4032, 1984, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_Metal_Shade_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 2047, 128),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_Metal_Light_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 512, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 2047, 128),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 512, 1, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(1, 0, 0, 252, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Metal__METAL_[] = {
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Half_Closed_Eyes__SKIN_[] = {
	gsSPSetLights1(crasher_blue_Half_Closed_Eyes__SKIN__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, COMBINED, 0, TEXEL0, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_eyes_half_closed_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_face_neutral_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Half_Closed_Eyes__SKIN_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Closed_Eyes__SKIN_[] = {
	gsSPSetLights1(crasher_blue_Closed_Eyes__SKIN__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, COMBINED, 0, TEXEL0, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_eyes_closed_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_face_neutral_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Closed_Eyes__SKIN_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Left_Eyes__SKIN_[] = {
	gsSPSetLights1(crasher_blue_Left_Eyes__SKIN__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, COMBINED, 0, TEXEL0, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_eyes_left_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_face_neutral_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Left_Eyes__SKIN_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Right_Eyes__SKIN_[] = {
	gsSPSetLights1(crasher_blue_Right_Eyes__SKIN__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, COMBINED, 0, TEXEL0, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_eyes_right_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_face_neutral_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Right_Eyes__SKIN_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Up_Eyes__SKIN_[] = {
	gsSPSetLights1(crasher_blue_Up_Eyes__SKIN__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, COMBINED, 0, TEXEL0, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_eyes_up_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_face_neutral_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Up_Eyes__SKIN_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Down_Eyes__SKIN_[] = {
	gsSPSetLights1(crasher_blue_Down_Eyes__SKIN__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, COMBINED, 0, TEXEL0, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_eyes_down_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_face_neutral_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Down_Eyes__SKIN_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Dead_Eyes__SKIN_[] = {
	gsSPSetLights1(crasher_blue_Dead_Eyes__SKIN__lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, COMBINED, 0, TEXEL0, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_eyes_dead_ia16),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_custom_toad_face_dead_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Dead_Eyes__SKIN_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Wing_Tip[] = {
	gsSPClearGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_mario_wing_tip_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Wing_Tip[] = {
	gsSPSetGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_Wing_Base[] = {
	gsSPClearGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_blue_mario_wing_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_Wing_Base[] = {
	gsSPSetGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d[] = {
	gsSPSetLights1(crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureFilter(G_TF_POINT),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, crasher_blue_castle_arm_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 7),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_16b, 1, crasher_blue_castle_arm_ci4),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_4b, 4, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_NumE[] = {
	gsSPSetLights1(crasher_blue_NumE_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureFilter(G_TF_POINT),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, crasher_blue_castle_shield_blue_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 2),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_16b, 1, crasher_blue_castle_shield_blue_ci4),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_4b, 4, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_NumE[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_NumA[] = {
	gsSPSetLights1(crasher_blue_NumA_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureFilter(G_TF_POINT),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, crasher_blue_castle_sheathed_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 2),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_16b, 1, crasher_blue_castle_sheathed_ci4),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_4b, 4, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_NumA[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d[] = {
	gsSPSetLights1(crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, 0, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureFilter(G_TF_POINT),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 1, crasher_blue_castle_foot_ia8),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureFilter(G_TF_BILERP),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Torso_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Torso_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Torso_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Torso_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Torso_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Torso_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Half_Closed_Eyes__SKIN__2[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Closed_Eyes__SKIN__3[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Left_Eyes__SKIN__4[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Right_Eyes__SKIN__5[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Up_Eyes__SKIN__6[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Down_Eyes__SKIN__7[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Head_DL_mesh_layer_1_mat_override_Dead_Eyes__SKIN__8[] = {
	gsSPDisplayList(mat_crasher_blue_NumB),
	gsSPDisplayList(crasher_blue_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_NumB),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Wing_DL_mesh_layer_4[] = {
	gsSPDisplayList(mat_crasher_blue_Wing_Tip),
	gsSPDisplayList(crasher_blue_Left_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Wing_Tip),
	gsSPDisplayList(mat_crasher_blue_Wing_Base),
	gsSPDisplayList(crasher_blue_Left_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Wing_Base),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Wing_DL_mesh_layer_4_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(crasher_blue_Left_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Wing_DL_mesh_layer_4_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(crasher_blue_Left_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Wing_DL_mesh_layer_4[] = {
	gsSPDisplayList(mat_crasher_blue_Wing_Tip),
	gsSPDisplayList(crasher_blue_Right_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Wing_Tip),
	gsSPDisplayList(mat_crasher_blue_Wing_Base),
	gsSPDisplayList(crasher_blue_Right_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Wing_Base),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Wing_DL_mesh_layer_4_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(crasher_blue_Right_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Wing_DL_mesh_layer_4_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(crasher_blue_Right_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Arm_Color_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Left_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Arm_Color_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Arm_Color_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Forearm_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Left_Forearm_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Forearm_skinned_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Forearm_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Forearm_skinned_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Forearm_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Forearm_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Left_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Left_Forearm_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Forearm_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Left_Forearm_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Forearm_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Left_Forearm_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Hand_DL_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Hand_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(mat_crasher_blue_NumE),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_crasher_blue_NumE),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Hand_DL_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Hand_DL_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(crasher_blue_Left_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Arm_Color_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Right_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Arm_Color_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Arm_Color_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Forearm_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Right_Forearm_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Forearm_skinned_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Forearm_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Forearm_skinned_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Forearm_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Forearm_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Right_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Right_Forearm_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Forearm_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Right_Forearm_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Forearm_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Right_Forearm_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Hand_DL_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Hand_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_crasher_blue_m_f9f205f8_79c4_1d9c_2fbc_a628cb23a2a4_f3d),
	gsSPDisplayList(mat_crasher_blue_NumA),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_crasher_blue_NumA),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Hand_DL_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Hand_DL_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(crasher_blue_Right_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Shoe_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d),
	gsSPDisplayList(crasher_blue_Left_Shoe_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Shoe_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Shoe_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Left_Shoe_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Left_Shoe_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Shoe_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d),
	gsSPDisplayList(crasher_blue_Right_Shoe_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_m_cf7b28a9_19c2_40d2_6ebd_570fe639962c_f3d),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Shoe_DL_mesh_layer_1_mat_override_Metal__METAL__0[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Shoe_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

Gfx crasher_blue_Right_Shoe_DL_mesh_layer_1_mat_override_Metal__METAL__1[] = {
	gsSPDisplayList(mat_crasher_blue_Metal__METAL_),
	gsSPDisplayList(crasher_blue_Right_Shoe_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_blue_Metal__METAL_),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

