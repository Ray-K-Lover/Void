#include "src/game/envfx_snow.h"

const GeoLayout crasher_metal_cap_geo[] = {
	GEO_NODE_START(),
	GEO_OPEN_NODE(),
		GEO_DISPLAY_LIST(LAYER_OPAQUE, crasher_metal_cap_Metal_Cap_Mesh_mesh_layer_1),
	GEO_CLOSE_NODE(),
	GEO_END(),
};
