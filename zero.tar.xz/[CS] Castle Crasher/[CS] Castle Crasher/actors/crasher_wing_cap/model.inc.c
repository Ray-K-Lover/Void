Lights1 crasher_wing_cap_f3dlite_material_lights = gdSPDefLights1(
	0x7F, 0x0, 0x4,
	0xFF, 0x0, 0x12, 0x28, 0x28, 0x28);

Gfx crasher_wing_cap_mario_wing_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_wing_cap_mario_wing_rgba16[] = {
	#include "actors/crasher_wing_cap/mario_wing.rgba16.inc.c"
};

Gfx crasher_wing_cap_mario_wing_tip_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 crasher_wing_cap_mario_wing_tip_rgba16[] = {
	#include "actors/crasher_wing_cap/mario_wing_tip.rgba16.inc.c"
};

Vtx crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_vtx_0[8] = {
	{{{-132, 118, -76}, 0, {974, 1996}, {0xA7, 0xED, 0x58, 0xFF}}},
	{{{-62, 145, -1}, 0, {-16, 1996}, {0xA7, 0xED, 0x59, 0xFF}}},
	{{{-192, 321, -94}, 0, {974, -16}, {0xA6, 0xED, 0x58, 0xFF}}},
	{{{-125, 348, -19}, 0, {-16, -16}, {0xA6, 0xEC, 0x57, 0xFF}}},
	{{{192, 321, -94}, 0, {974, -16}, {0x5A, 0xED, 0x58, 0xFF}}},
	{{{62, 145, -1}, 0, {-16, 1996}, {0x59, 0xED, 0x59, 0xFF}}},
	{{{132, 118, -76}, 0, {974, 1996}, {0x59, 0xED, 0x58, 0xFF}}},
	{{{125, 348, -19}, 0, {-16, -16}, {0x5A, 0xEC, 0x57, 0xFF}}},
};

Gfx crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_tri_0[] = {
	gsSPVertex(crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_vtx_1[8] = {
	{{{-132, 118, -76}, 0, {-16, 1996}, {0xA7, 0xED, 0x58, 0xFF}}},
	{{{-192, 321, -94}, 0, {-16, -16}, {0xA6, 0xED, 0x58, 0xFF}}},
	{{{-261, 293, -171}, 0, {974, -16}, {0xA6, 0xED, 0x58, 0xFF}}},
	{{{-201, 90, -153}, 0, {974, 1996}, {0xA6, 0xED, 0x58, 0xFF}}},
	{{{261, 293, -171}, 0, {974, -16}, {0x5A, 0xED, 0x58, 0xFF}}},
	{{{192, 321, -94}, 0, {-16, -16}, {0x5A, 0xED, 0x58, 0xFF}}},
	{{{132, 118, -76}, 0, {-16, 1996}, {0x59, 0xED, 0x58, 0xFF}}},
	{{{201, 90, -153}, 0, {974, 1996}, {0x5A, 0xED, 0x58, 0xFF}}},
};

Gfx crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_tri_1[] = {
	gsSPVertex(crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_vtx_1 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx crasher_wing_cap_Wing_Cap_DL_mesh_layer_1_vtx_0[96] = {
	{{{-98, 150, -138}, 0, {576, 521}, {0xB7, 0x49, 0xB7, 0xFF}}},
	{{{-65, 184, -138}, 0, {624, 521}, {0xB7, 0x49, 0xB7, 0xFF}}},
	{{{-65, 150, -171}, 0, {576, 496}, {0xB7, 0x49, 0xB7, 0xFF}}},
	{{{-65, 5, -138}, 0, {343, 455}, {0xB7, 0xB7, 0xB7, 0xFF}}},
	{{{-98, 38, -138}, 0, {343, 496}, {0xB7, 0xB7, 0xB7, 0xFF}}},
	{{{-65, 38, -171}, 0, {368, 455}, {0xB7, 0xB7, 0xB7, 0xFF}}},
	{{{80, 150, -171}, 0, {576, 240}, {0x49, 0x49, 0xB7, 0xFF}}},
	{{{80, 184, -138}, 0, {624, 215}, {0x49, 0x49, 0xB7, 0xFF}}},
	{{{114, 150, -138}, 0, {576, 215}, {0x49, 0x49, 0xB7, 0xFF}}},
	{{{80, 38, -171}, 0, {368, 281}, {0x49, 0xB7, 0xB7, 0xFF}}},
	{{{114, 38, -138}, 0, {343, 240}, {0x49, 0xB7, 0xB7, 0xFF}}},
	{{{80, 5, -138}, 0, {343, 281}, {0x49, 0xB7, 0xB7, 0xFF}}},
	{{{-98, 150, 141}, 0, {576, 752}, {0xB7, 0x49, 0x49, 0xFF}}},
	{{{-65, 150, 174}, 0, {576, 793}, {0xB7, 0x49, 0x49, 0xFF}}},
	{{{-65, 184, 141}, 0, {624, 793}, {0xB7, 0x49, 0x49, 0xFF}}},
	{{{-65, 38, 174}, 0, {112, 455}, {0xB7, 0xB7, 0x49, 0xFF}}},
	{{{-98, 38, 141}, 0, {137, 496}, {0xB7, 0xB7, 0x49, 0xFF}}},
	{{{-65, 5, 141}, 0, {137, 455}, {0xB7, 0xB7, 0x49, 0xFF}}},
	{{{80, 150, 174}, 0, {576, 967}, {0x49, 0x49, 0x49, 0xFF}}},
	{{{114, 150, 141}, 0, {576, 1008}, {0x49, 0x49, 0x49, 0xFF}}},
	{{{80, 184, 141}, 0, {624, 967}, {0x49, 0x49, 0x49, 0xFF}}},
	{{{80, 5, 141}, 0, {137, 281}, {0x49, 0xB7, 0x49, 0xFF}}},
	{{{114, 38, 141}, 0, {137, 240}, {0x49, 0xB7, 0x49, 0xFF}}},
	{{{80, 38, 174}, 0, {112, 281}, {0x49, 0xB7, 0x49, 0xFF}}},
	{{{-65, 150, -171}, 0, {576, 455}, {0xA6, 0x00, 0xA6, 0xFF}}},
	{{{-98, 38, -138}, 0, {416, 521}, {0xA6, 0x00, 0xA6, 0xFF}}},
	{{{-98, 150, -138}, 0, {576, 521}, {0xA6, 0x00, 0xA6, 0xFF}}},
	{{{-65, 38, -171}, 0, {416, 455}, {0xA6, 0x00, 0xA6, 0xFF}}},
	{{{-65, 184, 141}, 0, {624, 727}, {0xA6, 0x5A, 0x00, 0xFF}}},
	{{{-65, 184, -138}, 0, {624, 521}, {0xA6, 0x5A, 0x00, 0xFF}}},
	{{{-98, 150, -138}, 0, {576, 521}, {0xA6, 0x5A, 0x00, 0xFF}}},
	{{{-98, 150, 141}, 0, {576, 727}, {0xA6, 0x5A, 0x00, 0xFF}}},
	{{{-98, 38, 141}, 0, {416, 727}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-98, 150, 141}, 0, {576, 727}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-98, 150, -138}, 0, {576, 521}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-98, 38, -138}, 0, {416, 521}, {0x81, 0x00, 0x00, 0xFF}}},
	{{{-65, 184, -138}, 0, {649, 455}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{-65, 184, 141}, 0, {855, 455}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{80, 184, 141}, 0, {855, 281}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{80, 184, -138}, 0, {649, 281}, {0x00, 0x7F, 0x00, 0xFF}}},
	{{{-65, 184, -138}, 0, {649, 455}, {0x00, 0x5A, 0xA6, 0xFF}}},
	{{{80, 184, -138}, 0, {649, 281}, {0x00, 0x5A, 0xA6, 0xFF}}},
	{{{80, 150, -171}, 0, {576, 281}, {0x00, 0x5A, 0xA6, 0xFF}}},
	{{{-65, 150, -171}, 0, {576, 455}, {0x00, 0x5A, 0xA6, 0xFF}}},
	{{{-65, 38, -171}, 0, {416, 455}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{-65, 150, -171}, 0, {576, 455}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{80, 150, -171}, 0, {576, 281}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{80, 38, -171}, 0, {416, 281}, {0x00, 0x00, 0x81, 0xFF}}},
	{{{-65, 5, 141}, 0, {137, 455}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{-65, 5, -138}, 0, {343, 455}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{80, 5, -138}, 0, {343, 281}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{80, 5, 141}, 0, {137, 281}, {0x00, 0x81, 0x00, 0xFF}}},
	{{{-65, 5, -138}, 0, {343, 455}, {0xA6, 0xA6, 0x00, 0xFF}}},
	{{{-65, 5, 141}, 0, {137, 455}, {0xA6, 0xA6, 0x00, 0xFF}}},
	{{{-98, 38, 141}, 0, {137, 496}, {0xA6, 0xA6, 0x00, 0xFF}}},
	{{{-98, 38, -138}, 0, {343, 496}, {0xA6, 0xA6, 0x00, 0xFF}}},
	{{{80, 5, -138}, 0, {343, 281}, {0x00, 0xA6, 0xA6, 0xFF}}},
	{{{-65, 5, -138}, 0, {343, 455}, {0x00, 0xA6, 0xA6, 0xFF}}},
	{{{-65, 38, -171}, 0, {416, 455}, {0x00, 0xA6, 0xA6, 0xFF}}},
	{{{80, 38, -171}, 0, {416, 281}, {0x00, 0xA6, 0xA6, 0xFF}}},
	{{{114, 150, -138}, 0, {576, 215}, {0x5A, 0x00, 0xA6, 0xFF}}},
	{{{80, 38, -171}, 0, {416, 281}, {0x5A, 0x00, 0xA6, 0xFF}}},
	{{{80, 150, -171}, 0, {576, 281}, {0x5A, 0x00, 0xA6, 0xFF}}},
	{{{114, 38, -138}, 0, {416, 215}, {0x5A, 0x00, 0xA6, 0xFF}}},
	{{{80, 184, -138}, 0, {624, 215}, {0x5A, 0x5A, 0x00, 0xFF}}},
	{{{80, 184, 141}, 0, {624, 9}, {0x5A, 0x5A, 0x00, 0xFF}}},
	{{{114, 150, 141}, 0, {576, 9}, {0x5A, 0x5A, 0x00, 0xFF}}},
	{{{114, 150, -138}, 0, {576, 215}, {0x5A, 0x5A, 0x00, 0xFF}}},
	{{{114, 38, -138}, 0, {416, 215}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{114, 150, -138}, 0, {576, 215}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{114, 150, 141}, 0, {576, 9}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{114, 38, 141}, 0, {416, 9}, {0x7F, 0x00, 0x00, 0xFF}}},
	{{{80, 5, 141}, 0, {137, 281}, {0x5A, 0xA6, 0x00, 0xFF}}},
	{{{80, 5, -138}, 0, {343, 281}, {0x5A, 0xA6, 0x00, 0xFF}}},
	{{{114, 38, -138}, 0, {343, 240}, {0x5A, 0xA6, 0x00, 0xFF}}},
	{{{114, 38, 141}, 0, {137, 240}, {0x5A, 0xA6, 0x00, 0xFF}}},
	{{{-98, 150, 141}, 0, {576, 727}, {0xA6, 0x00, 0x5A, 0xFF}}},
	{{{-98, 38, 141}, 0, {416, 727}, {0xA6, 0x00, 0x5A, 0xFF}}},
	{{{-65, 38, 174}, 0, {416, 793}, {0xA6, 0x00, 0x5A, 0xFF}}},
	{{{-65, 150, 174}, 0, {576, 793}, {0xA6, 0x00, 0x5A, 0xFF}}},
	{{{80, 38, 174}, 0, {416, 967}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{80, 150, 174}, 0, {576, 967}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{-65, 150, 174}, 0, {576, 793}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{-65, 38, 174}, 0, {416, 793}, {0x00, 0x00, 0x7F, 0xFF}}},
	{{{80, 184, 141}, 0, {624, 967}, {0x00, 0x5A, 0x5A, 0xFF}}},
	{{{-65, 184, 141}, 0, {624, 793}, {0x00, 0x5A, 0x5A, 0xFF}}},
	{{{-65, 150, 174}, 0, {576, 793}, {0x00, 0x5A, 0x5A, 0xFF}}},
	{{{80, 150, 174}, 0, {576, 967}, {0x00, 0x5A, 0x5A, 0xFF}}},
	{{{-65, 5, 141}, 0, {137, 455}, {0x00, 0xA6, 0x5A, 0xFF}}},
	{{{80, 38, 174}, 0, {112, 281}, {0x00, 0xA6, 0x5A, 0xFF}}},
	{{{-65, 38, 174}, 0, {112, 455}, {0x00, 0xA6, 0x5A, 0xFF}}},
	{{{80, 5, 141}, 0, {137, 281}, {0x00, 0xA6, 0x5A, 0xFF}}},
	{{{114, 38, 141}, 0, {416, 1008}, {0x5A, 0x00, 0x5A, 0xFF}}},
	{{{114, 150, 141}, 0, {576, 1008}, {0x5A, 0x00, 0x5A, 0xFF}}},
	{{{80, 150, 174}, 0, {576, 967}, {0x5A, 0x00, 0x5A, 0xFF}}},
	{{{80, 38, 174}, 0, {416, 967}, {0x5A, 0x00, 0x5A, 0xFF}}},
};

Gfx crasher_wing_cap_Wing_Cap_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(crasher_wing_cap_Wing_Cap_DL_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 27, 25, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPVertex(crasher_wing_cap_Wing_Cap_DL_mesh_layer_1_vtx_0 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPVertex(crasher_wing_cap_Wing_Cap_DL_mesh_layer_1_vtx_0 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSP2Triangles(24, 25, 26, 0, 24, 27, 25, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 30, 31, 0),
	gsSPEndDisplayList(),
};


Gfx mat_crasher_wing_cap_Wing_Base[] = {
	gsSPClearGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_wing_cap_mario_wing_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_wing_cap_Wing_Base[] = {
	gsSPSetGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_wing_cap_Wing_Tip[] = {
	gsSPClearGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, crasher_wing_cap_mario_wing_tip_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_wing_cap_Wing_Tip[] = {
	gsSPSetGeometryMode(G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_crasher_wing_cap_f3dlite_material[] = {
	gsSPSetLights1(crasher_wing_cap_f3dlite_material_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_crasher_wing_cap_f3dlite_material[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx crasher_wing_cap_Wing_Cap_DL_mesh_layer_4[] = {
	gsSPDisplayList(mat_crasher_wing_cap_Wing_Base),
	gsSPDisplayList(crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_crasher_wing_cap_Wing_Base),
	gsSPDisplayList(mat_crasher_wing_cap_Wing_Tip),
	gsSPDisplayList(crasher_wing_cap_Wing_Cap_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_crasher_wing_cap_Wing_Tip),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

Gfx crasher_wing_cap_Wing_Cap_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_crasher_wing_cap_f3dlite_material),
	gsSPDisplayList(crasher_wing_cap_Wing_Cap_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_crasher_wing_cap_f3dlite_material),
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsSPEndDisplayList(),
};

