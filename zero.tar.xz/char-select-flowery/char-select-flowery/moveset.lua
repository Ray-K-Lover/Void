if not charSelectExists then return end

ACT_JARONA_CHARGE = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR)

flowerybowser = mod_storage_load_bool("flowerybowser")

-- stores timestamps to determine whether or not to slip more while jaroning
local sJaronaStop = {}
local FLOWERYCHARGE = audio_stream_load("Charge.ogg")
audio_stream_set_looping(FLOWERYCHARGE, true)
local FLOWERYFIRE = audio_sample_load("ChargeFire.ogg")
local SOUND_NOTP = audio_sample_load("noTP.ogg")

local E_MODEL_FLOWERYEFFECT = smlua_model_util_get_id("floweryeffect_geo")

-- Jarona After Effects

function bhv_floweryAE2_init(o)
    o.oFlags = (OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE)
    o.oOpacity = 0
end

function bhv_floweryAE2_loop(o)
    if o.oTimer < 3 then
        o.oOpacity = o.oOpacity + 80
    else
        o.oOpacity = o.oOpacity - 20
    end
    if o.oOpacity < 0 or o.oTimer > 10 then
        obj_mark_for_deletion(o)
    end
end

local function flowery_after_effect(m)
    if m.actionTimer % 2 == 1 then
        spawn_non_sync_object(
            id_bhvfloweryAE2,
            E_MODEL_FLOWERYEFFECT,
            m.pos.x, m.pos.y, m.pos.z,
            function(AEObj)
                smlua_anim_util_set_animation(AEObj, "FlowerySlideKick")
                AEObj.header.gfx.animInfo.animFrame = m.marioObj.header.gfx.animInfo.animFrame
                AEObj.header.gfx.animInfo.animAccel = 0
                AEObj.parentObj = m.marioObj
                AEObj.globalPlayerIndex = network_global_index_from_local(m.playerIndex)
            end
		)
	end
end

jaronaCooldown = {}
for i = 0, (MAX_PLAYERS - 1) do
    jaronaCooldown[i] = 0
end

local hurtActs = T{
    ACT_SOFT_BACKWARD_GROUND_KB,
    ACT_BACKWARD_GROUND_KB,
    ACT_BACKWARD_AIR_KB,
    ACT_HARD_BACKWARD_AIR_KB,
    ACT_SOFT_FORWARD_GROUND_KB,
    ACT_FORWARD_GROUND_KB,
    ACT_HARD_FORWARD_GROUND_KB,
    ACT_FORWARD_AIR_KB,
    ACT_HARD_FORWARD_AIR_KB,
    ACT_TORNADO_TWIRLING,
    ACT_SHOCKED,
    ACT_SQUISHED,
    ACT_BURNING_JUMP,
    ACT_BURNING_GROUND,
}

--- @param m MarioState
local function act_jarona_charge(m)
    set_character_animation(m, CHAR_ANIM_A_POSE)
    smlua_anim_util_set_animation(m.marioObj, "FloweryCharge")

    perform_air_step(m, 0)

    if (m.controller.buttonDown & X_BUTTON) ~= 0 then
        m.forwardVel = math.clamp(m.forwardVel + 5, 10, 100)
        m.marioObj.header.gfx.angle.y = m.faceAngle.y
        audio_stream_set_frequency(FLOWERYCHARGE, math.remap(10, 100, 0.5, 1, m.forwardVel))
        if m.playerIndex == 0 then
            audio_stream_play(FLOWERYCHARGE, false, 1)
        end

        local shade = math.remap(10, 100, 255, 127, m.forwardVel)
        m.marioBodyState.shadeR = shade
        m.marioBodyState.shadeG = shade
        m.marioBodyState.shadeB = shade
    else
        jaronaCooldown[m.playerIndex] = 50
        sJaronaStop[m.playerIndex] = get_area_update_counter() + m.forwardVel / 100
        m.vel.y = 10
        set_mario_action(m, ACT_SLIDE_KICK, 0)
        m.actionState = 1 -- no bounce

        audio_sample_play(FLOWERYFIRE, m.pos, 1)
        play_character_sound_if_no_flag(m,
            (m.forwardVel > 40)
                and CHAR_SOUND_YAHOO_WAHA_YIPPEE
                or FLOWERY_SOUND_JAST_KIDDING,
            MARIO_MARIO_SOUND_PLAYED)
    end
end
function act_jarona_charge_gravity(m)
    vec3f_mul(m.vel, .7)
end

local function stop_charge_sound(m)
    if m.playerIndex == 0 then
        audio_stream_stop(FLOWERYCHARGE)
    end
end

local function check_jarona(m)
    if jaronaCooldown[m.playerIndex] > 0 then -- Jarona Cooldown
        jaronaCooldown[m.playerIndex] = jaronaCooldown[m.playerIndex] - 1
    end

    if (m.action & (ACT_GROUP_CUTSCENE | ACT_FLAG_ON_POLE | ACT_FLAG_HANGING | ACT_FLAG_RIDING_SHELL | ACT_FLAG_INVULNERABLE | ACT_FLAG_SWIMMING_OR_FLYING | ACT_FLAG_SWIMMING | ACT_FLAG_METAL_WATER) == 0) and m.heldObj == nil then -- if in a ground action
        if (m.controller.buttonPressed & X_BUTTON) ~= 0 and check_cooldown(m) then
            mario_set_forward_vel(m, -40)
            set_mario_action(m, ACT_JARONA_CHARGE, 0)
        end
    end

	if (m.prevAction == ACT_JARONA_CHARGE) then
        flowery_after_effect(m)
        m.flags = m.flags | MARIO_KICKING

        m.marioBodyState.shadeR = 127
        m.marioBodyState.shadeG = 127
        m.marioBodyState.shadeB = 127
    end
end

function check_cooldown(m)
    if (jaronaCooldown[m.playerIndex] == 0) or (jaronaCooldown[m.playerIndex] == 99) then
        return true
    elseif (m.playerIndex == 0) then
        audio_sample_play(SOUND_NOTP, m.pos, .7)
    end
    return false
end

-- Jaroning on Bowser causes him to go flying
-- Code originally from Flowery Land mod, made by SwagSkeleton

define_custom_obj_fields({
    oFloweryHit = 'u32',
})

local function bhv_flowerySync_init(o)
    local bowser = o.parentObj
	network_init_object(o, true, {"oFloweryHit"})

    if flowerybowser then
        if bowser.oBehParams2ndByte == 0 then
            bowser.oHealth = 2
        elseif bowser.oBehParams2ndByte == 1 then
            bowser.oHealth = 3
        elseif bowser.oBehParams2ndByte == 2 then
            bowser.oHealth = 5
        end
    end
end

function bhv_floweryFallingPlatform_loop(o)
    local bowser = obj_get_nearest_object_with_behavior_id(o, id_bhvBowser)

    if bowser == nil then return end -- cancel the code if no bowser can be detected
        if flowerybowser then
            if bowser.oHealth <= 3 then
                o.oAction = 2
        end
    end
end

local function bhv_flowery_bowser_body_anchor_loop(o)
	local bowser = o.parentObj

	if not bowser or bowser.oHeldState ~= HELD_FREE or (bowser.oAction > 1 and bowser.oAction <= 6) or bowser.oAction >= 19 then return end

	local m = gMarioStates[0]
	if ((m.action == ACT_SLIDE_KICK) and (m.prevAction == ACT_JARONA_CHARGE)) and dist_between_objects(o, m.marioObj) <= 400 and abs_angle_diff(m.faceAngle.y, obj_angle_to_object(m.marioObj, o)) < degrees_to_sm64(140) then
		play_sound(SOUND_GENERAL_WALL_EXPLOSION, m.pos)
        play_character_sound(m, CHAR_SOUND_SO_LONGA_BOWSER)
		spawn_non_sync_object(id_bhvVertStarParticleSpawner, E_MODEL_NONE, m.pos.x, m.pos.y, m.pos.z, function()end)
		set_camera_shake_from_point(SHAKE_POS_MEDIUM, m.pos.x, m.pos.y, m.pos.z)

		bowser.oMoveAngleYaw = m.faceAngle.y
        m.forwardVel = m.forwardVel / 2
		o.oFloweryHit = 1
	end

	if o.oFloweryHit == 1 then
		bowser.oAction = 1
		bowser.oForwardVel = 270
		bowser.oVelY = 70
		o.oFloweryHit = 0
	end
	if o.oFloweryHit == 2 then
		bowser.oAction = 1
		bowser.oVelY = 10
		o.oFloweryHit = 0
	end

end

function jarona_interact(m, obj, interactType)
	-- Let PVP Hook handle player interactions
	if interactType == INTERACT_PLAYER then
		return false
	end

	local interactables = {
		[INTERACT_BREAKABLE] = INTERACT_BREAKABLE,
		[INTERACT_BOUNCE_TOP] = INTERACT_BOUNCE_TOP,
		[INTERACT_BOUNCE_TOP2] = INTERACT_BOUNCE_TOP2,
		[INTERACT_HIT_FROM_BELOW] = INTERACT_HIT_FROM_BELOW,
		[INTERACT_GRABBABLE] = INTERACT_GRABBABLE,
		[INTERACT_MR_BLIZZARD] = INTERACT_MR_BLIZZARD,
	}

	if ((m.action == ACT_SLIDE_KICK) and (m.prevAction == ACT_JARONA_CHARGE)) and (interactables[interactType] ~= nil) then
		if obj_has_behavior_id(obj, id_bhvKingBobomb) ~= 0 and m.forwardVel > 80 then -- King Bobomb
			if obj.oFlags & OBJ_FLAG_HOLDABLE ~= 0 and obj.oAction ~= 8 then
				obj.oVelY = 30
				obj.oForwardVel = 30
				obj.oMoveAngleYaw = m.faceAngle.y
				obj.oMoveFlags = 0
				obj.oAction = 4
                play_sound(SOUND_GENERAL_BREAK_BOX, m.pos)
				spawn_non_sync_object(id_bhvVertStarParticleSpawner, E_MODEL_NONE, m.pos.x, m.pos.y, m.pos.z, function()end)
			end
		end
		if obj_has_behavior_id(obj, id_bhvChuckya) ~= 0 then -- Chuckya
			obj.oVelY = 30
			obj.oMoveAngleYaw = m.faceAngle.y
			obj.oForwardVel = 30
			obj.oAction = 2
		end
		if obj_has_behavior_id(obj, id_bhvBreakableBoxSmall) ~= 0 then -- Small Box
			obj.oMoveAngleYaw = m.faceAngle.y
			obj.oVelY = 30
			obj.oForwardVel = math.max(50, m.forwardVel)
		end
		if obj_has_behavior_id(obj, id_bhvMips) ~= 0 then -- Mips
			if obj.oAction ~= MIPS_ACT_IDLE and obj.oAction ~= MIPS_ACT_WAIT_FOR_ANIMATION_DONE then
				obj.oMoveAngleYaw = m.faceAngle.y
				obj.oHeldState = HELD_THROWN
			elseif (obj.oAction == MIPS_ACT_IDLE or obj.oAction == MIPS_ACT_WAIT_FOR_ANIMATION_DONE) and obj.oHeldState == HELD_FREE and m.heldObj == nil then
				m.usedObj = obj
				set_mario_animation(m, CHAR_ANIM_FIRST_PUNCH)
				m.marioObj.header.gfx.animInfo.animFrame = 15
				m.marioObj.header.gfx.animInfo.animAccel = 0
				return set_mario_action(m, ACT_PICKING_UP, 0)
			end
		end
		if obj_has_behavior_id(obj, id_bhvUkiki) ~= 0 then -- Ukiki
			if obj.oAction ~= UKIKI_ACT_GO_TO_CAGE and obj.oAction ~= UKIKI_ACT_RETURN_HOME and obj.oHeldState == HELD_FREE then
				if obj.oAnimState == UKIKI_ANIM_STATE_CAP_ON or obj.oBehParams2ndByte ~= UKIKI_CAP then
					if m.heldObj == nil then
						m.usedObj = obj
						set_mario_animation(m, CHAR_ANIM_FIRST_PUNCH)
						m.marioObj.header.gfx.animInfo.animFrame = 15
						m.marioObj.header.gfx.animInfo.animAccel = 0
						return set_mario_action(m, ACT_PICKING_UP, 0)
					end
				else
					obj.oMoveAngleYaw = m.faceAngle.y
					obj.oAction = 3
					obj.oForwardVel = 0
				end
			end
		end
		if obj_has_behavior_id(obj, id_bhvSmallPenguin) ~= 0 then -- Baby Penguins
			if obj.oHeldState == HELD_FREE and m.heldObj == nil then
				m.usedObj = obj
				set_mario_animation(m, CHAR_ANIM_FIRST_PUNCH)
				m.marioObj.header.gfx.animInfo.animFrame = 15
				m.marioObj.header.gfx.animInfo.animAccel = 0
				return set_mario_action(m, ACT_PICKING_UP, 0)
			end
		end
		
		return true
	end
end

local function flowerybowserToggle(index, value)
    flowerybowser = value
    mod_storage_save_bool("flowerybowser", value)
end


local function moves()
    charSelect.character_hook_moveset(CT_FLOWERY, HOOK_MARIO_UPDATE, check_jarona)
    charSelect.character_hook_moveset(CT_FLOWERY, HOOK_ON_INTERACT, jarona_interact)
end

hook_mario_action(ACT_JARONA_CHARGE, { every_frame = act_jarona_charge, gravity = act_jarona_charge_gravity })
hook_event(HOOK_ON_SET_MARIO_ACTION, stop_charge_sound)
hook_event(HOOK_ON_MODS_LOADED, moves)
hook_behavior(id_bhvBowserBodyAnchor, OBJ_LIST_GENACTOR, false, bhv_flowerySync_init, bhv_flowery_bowser_body_anchor_loop, "bhv_floweryBowserBodyAnchor")
hook_behavior(id_bhvFallingBowserPlatform, OBJ_LIST_SURFACE, false, nil, bhv_floweryFallingPlatform_loop, "bhv_floweryFallingPlatform")
id_bhvfloweryAE2 = hook_behavior(nil, OBJ_LIST_GENACTOR, true, bhv_floweryAE2_init, bhv_floweryAE2_loop, "Flowery AfterEffect 2")

if network_is_server() then
    hook_mod_menu_checkbox("[HOST] Tougher Bowser", mod_storage_load_bool("flowerybowser"), flowerybowserToggle)
end

hook_event(HOOK_MARIO_OVERRIDE_FLOOR_CLASS, function (m)
    local jaronaTime = sJaronaStop[m.playerIndex]
    if jaronaTime and get_area_update_counter() < sJaronaStop[m.playerIndex] then
        return SURFACE_CLASS_VERY_SLIPPERY
    end
end)