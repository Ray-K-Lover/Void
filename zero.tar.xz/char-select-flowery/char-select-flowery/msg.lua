-- Called when player attempts to change out of Flowery character while playing

local function flowerycsmenu()
    if subtitleTimer >= 0 then
        return false
    end
    return true
end

flowery = 0
flowerymsg = 0

local function flowerytimer(m)
    local charNum = charSelect.character_get_current_number()

    if charNum == CT_FLOWERY and m.action == ACT_WALKING then
        flowery = 1
        return true
    end
    return false
end

local SHUT_OUT   = 1 << 0
local FORCE_CHAR = 1 << 1
local TOADERY    = 1 << 2
local SOUND      = 1 << 3
local UNLOCK    = 1 << 4

local REJECT_SWITCH = (SHUT_OUT|FORCE_CHAR|SOUND)

local floweryTable = {
    {REJECT_SWITCH, "Hey now... it isn't polite to remove me while playing the game!"},
    {REJECT_SWITCH, "Surely you want to finish the game with your best friend, right?"},
    {REJECT_SWITCH, "You know, life's a freedom, it's better to choose your rights... but don't forget..."},
    {REJECT_SWITCH|TOADERY, "Rules are just a suggestion. And I shall select the character for you!" },
    {UNLOCK, "Alright princess, if you don't want to play as me, then I won't stop you, go have fun!"},
}

local FLOWERYSOUND = audio_stream_load("FloweryNo2.ogg")

local E_MODEL_TOADERY = smlua_model_util_get_id("toadery_flowery_geo")
local E_MODEL_FLOWERY = smlua_model_util_get_id("flowery_violet_geo")
local function flowerymessage()
    local charNum = charSelect.character_get_current_number()

    if charNum ~= CT_FLOWERY then
        if charSelect.is_menu_open() and flowery == 1 then
            flowerymsg = flowerymsg + 1
            local floweryCond = floweryTable[flowerymsg]
            if floweryCond then
                local flags = floweryCond[1]
                local msg = floweryCond[2]
                charSelect.set_menu_open(flags & SHUT_OUT == 0)
                if flags & FORCE_CHAR ~= 0 then charSelect.character_set_current_number(CT_FLOWERY, nil) end
                if flags & TOADERY ~= 0 then charSelect.character_edit(CT_FLOWERY, "Toadery", nil, "Flowery", nil, E_MODEL_TOADERY, CT_TOAD) end
                if flags & UNLOCK ~= 0 then
                    charSelect.character_edit(CT_FLOWERY, "Flowery", nil, "VIoletSM64", nil, E_MODEL_FLOWERY, CT_MARIO)
                    charSelect.character_add_costume(CT_FLOWERY, "Toadery", nil, "Flowery", nil, E_MODEL_TOADERY, CT_TOAD)
                end
                if flags & SOUND ~= 0 then audio_stream_play(FLOWERYSOUND, true, 1) end
                djui_popup_create("\\#FEE502\\" .. msg, 2)
                return
            end
        end
    end
end

-- Called when Flowery dies in the game

define_custom_obj_fields({
    oFlowery = 'f32',
})

local FLOWERYHERO = audio_stream_load("FloweryHero.ogg")
local FLOWERYHELP = audio_stream_load("FloweryHelp.ogg")
local FLOWERYCHANCE = audio_stream_load("FloweryChance.ogg")

flowerydead = 1

local FlowerDeath = {
    [1]   = {FLOWERYSOUND,  "You should be more careful next time buddy!"},
    [2]   = {FLOWERYHERO,   "You call yourself a hero playing like that?"},
    [3]   = {FLOWERYHELP,   "I'm only trying to help you."},
    [4]   = {FLOWERYCHANCE, "Get a chance, let the real pro handle this."},
    [5]   = {FLOWERYSOUND,  "Don't worry, you'll get it next time buddy!"},
    [6]   = {FLOWERYSOUND,  "Alright fine little guy, I'll stop bothering you, ciao!"},
    [10]  = {FLOWERYSOUND,  "Oh hey! 10 deaths... gotta mean something right?"},
    [25]  = {FLOWERYSOUND,  "Poor guy, you should probably play something else, I heard Deltarune is a great game!"},
    [100] = {FLOWERYSOUND,  "This seems really ridiculous, seems like things took a gorey route..."},
}

local deathActs = T{
    ACT_DEATH_ON_BACK,
    ACT_DEATH_ON_STOMACH,
    ACT_STANDING_DEATH,
    ACT_ELECTROCUTION,
    ACT_SUFFOCATION,
    ACT_DROWNING,
}

local function flowerydeath(m)
    local charNum = charSelect.character_get_current_number()
    if charNum == CT_FLOWERY then
        local deathCond = FlowerDeath[flowerydead]
        if deathCond and deathActs[m.action] then
            flowerydead = flowerydead + 1
            audio_stream_play(deathCond[1], true, 1)
            djui_popup_create("\\#FEE502\\" .. deathCond[2], 2)
        end
    end
end

hook_event(HOOK_ON_SET_MARIO_ACTION, flowerytimer)
hook_event(HOOK_ON_DEATH, flowerydeath)
charSelect.hook_allow_menu_open(flowerycsmenu)
charSelect.hook_on_character_change(flowerymessage)