--- @class XSubtitle
--- @field public text string
--- @field public color Color
--- @field public timeStart number
--- @field public timeEnd number

local COLOR_YELLOW  = { r = 255, g = 255, b = 0 }

local LYRICS_END_TIME = 192 * 30

--- @param text string
--- @param colorCode string
--- @param timeStart number
--- @param timeEnd number
--- @return XSubtitle
local function LYRIC(text, colorCode, timeStart, timeEnd)
    return {
        text = text,
        color = colorCode,
        timeStart = timeStart,
        timeEnd = timeEnd
    }
end

--- @type XSubtitle[]
local sLyricsTable = {
    LYRIC("Ten feet twenty the Flower Man", COLOR_YELLOW, 24, 27.5),
    LYRIC("Is waiting for the touch of his hand", COLOR_YELLOW, 27.5, 30.5),
    LYRIC("Straightening petals out without a plan", COLOR_YELLOW, 30.5, 33.5),
    LYRIC("Like the every daily", COLOR_YELLOW, 33.5, 36),
    LYRIC("Wish that bothers the Flower Man", COLOR_YELLOW, 36, 39.5),
    LYRIC("Could I do something to make him laugh", COLOR_YELLOW, 39.5, 42.5),
    LYRIC("Inside my little chamber made of glass", COLOR_YELLOW, 42.5, 46),
    LYRIC("So he lived the", COLOR_YELLOW, 46, 47.5),
    LYRIC("Flower Man, Flower Man", COLOR_YELLOW, 47.5, 50.25),
    LYRIC("With his heart in the sand", COLOR_YELLOW, 50.25, 53.25),
    LYRIC("So he stands", COLOR_YELLOW, 53.25, 55.25),
    LYRIC("To watch the whole wide world", COLOR_YELLOW, 55.25, 58),
    LYRIC("From a can", COLOR_YELLOW, 58, 59.25),
    LYRIC("Way up high in the sky", COLOR_YELLOW, 59.25, 62.25),
    LYRIC("With the sun in his eyes", COLOR_YELLOW, 62.25, 65.25),
    LYRIC("Ain't it nice", COLOR_YELLOW, 65.25, 67.25),
    LYRIC("The life forever for", COLOR_YELLOW, 67.25, 70.5),
    LYRIC("Flowers", COLOR_YELLOW, 70.5, 72),

    LYRIC("Ten feet twenty the Flower Man", COLOR_YELLOW, 144, 147.5),
    LYRIC("Is waiting for the touch of his hand", COLOR_YELLOW, 147.5, 150.5),
    LYRIC("Fallen to pieces still without a plan", COLOR_YELLOW, 150.5, 153.5),
    LYRIC("Yet the every daily", COLOR_YELLOW, 153.5, 156),
    LYRIC("Hope that powered the Flower Man", COLOR_YELLOW, 156, 159.5),
    LYRIC("Would never cower off of its path", COLOR_YELLOW, 159.5, 162.5),
    LYRIC("Even if broken I am more than glass", COLOR_YELLOW, 162.5, 166),
    LYRIC("So he lived the", COLOR_YELLOW, 166, 167.5),
    LYRIC("Flower Man, Flower Man", COLOR_YELLOW, 167.5, 170.25),
    LYRIC("With his heart in the sand", COLOR_YELLOW, 170.25, 173.25),
    LYRIC("So he stands", COLOR_YELLOW, 173.25, 175.25),
    LYRIC("To watch the whole wide world", COLOR_YELLOW, 175.25, 178),
    LYRIC("From a can", COLOR_YELLOW, 178, 179.25),
    LYRIC("Way up high in the sky", COLOR_YELLOW, 179.25, 182.25),
    LYRIC("With the sun in your eyes", COLOR_YELLOW, 182.25, 185.25),
    LYRIC("Ain't it nice", COLOR_YELLOW, 185.25, 187.25),
    LYRIC("The life forever for", COLOR_YELLOW, 187.25, 190.5),
    LYRIC("Flowers", COLOR_YELLOW, 190.5, 192),
}

subtitleTimer = -1

--- @param message string
--- @param x number
--- @param y number
--- @param scale number
local function djui_hud_print_text_centered(message, x, y, scale)
    local measure = djui_hud_measure_text(message)
    djui_hud_print_text(message, x - (measure * 0.5) * scale, y, scale)
end

--- @param subtitleTable XSubtitle[]
local function get_current_subtitle(subtitleTable)
    for _, lyric in ipairs(subtitleTable) do
        if subtitleTimer >= lyric.timeStart * 30 and subtitleTimer <= lyric.timeEnd * 30 then
            return lyric
        end
    end

    return nil
end

--- @param subtitleTable XSubtitle[]
--- @param y number
--- @param bounce boolean
local function hud_render_subtitle(subtitleTable, y, bounce)
    local subtitle = get_current_subtitle(subtitleTable)
    if subtitle ~= nil then
        local scale = 0.5
        if bounce then
            scale = scale + math.sin(subtitleTimer * 0.5) * 0.01
        end
        local x = djui_hud_get_screen_width() * 0.5
        local length = (djui_hud_measure_text(subtitle.text) * scale) + 4

        djui_hud_set_color(0, 0, 0, 127)
        djui_hud_render_rect(x - length * 0.5, y + (2 * scale), length, 32 * scale)
        djui_hud_set_color(subtitle.color.r, subtitle.color.g, subtitle.color.b, 255)
        djui_hud_print_text_centered(subtitle.text, x, y, scale)
    end
end

local function x_subtitle_render()
    djui_hud_set_resolution(RESOLUTION_N64)
    djui_hud_set_font(FONT_NORMAL)

    if subtitleTimer == -1 then return end

    hud_render_subtitle(sLyricsTable, djui_hud_get_screen_height() - 30, true)

    subtitleTimer = subtitleTimer + 1
    if subtitleTimer > LYRICS_END_TIME then
        subtitleTimer = 0
    end
end

hook_event(HOOK_ON_HUD_RENDER, x_subtitle_render)