-- Swaps Star Model with Flowery Star
-- Credits to Banaza Kong mod

function star_is_collected(starId)
	local gCurrCourseNum = gNetworkPlayers[0].currCourseNum
	local starflags = save_file_get_star_flags(get_current_save_file_num() - 1, gCurrCourseNum - 1)

	if starflags & (1 << starId) ~= 0 then
		return true
	end
	return false
end

---@param o Object
function bhv_star_loop(o)
	local charNum = _G.charSelect.character_get_current_number()
	local E_MODEL_FLOWERY_STAR = smlua_model_util_get_id("flowery_star_geo")

	if charNum == CT_FLOWERY and o.oBehParams2ndByte == 0 then
		if obj_has_model_extended(o, E_MODEL_STAR) ~= 0 then
			obj_set_model_extended(o, E_MODEL_FLOWERY_STAR)
		elseif obj_has_model_extended(o, E_MODEL_TRANSPARENT_STAR) ~= 0 then
			obj_set_model_extended(o, E_MODEL_TRANSPARENT_STAR)
		end
	else
		if obj_has_model_extended(o, E_MODEL_FLOWERY_STAR) ~= 0 then
			obj_set_model_extended(o, E_MODEL_STAR)
		elseif obj_has_model_extended(o, E_MODEL_TRANSPARENT_STAR) ~= 0 then
			obj_set_model_extended(o, E_MODEL_TRANSPARENT_STAR)
		end
	end
end

hook_behavior(id_bhvCelebrationStar, OBJ_LIST_LEVEL, false, nil, bhv_star_loop, "bhv_flowerystar")