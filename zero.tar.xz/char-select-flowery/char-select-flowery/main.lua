-- name: [CS] Flowery
-- description: Hey guys, it's me Flowery! Asgore's college roommate... and best friend. I think I found myself in a new Dark World, and there seems to be a princess that needs to be saved! Perhaps I can wait on giving Asgore his perfect world, here I come San Frandisco!\n\nMade by: VioletSM64\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

local TEXT_MOD_NAME = get_active_mod().name

-- Generates a truth table
function T(t)
    local t2 = {}
    for _, v in ipairs(t) do
        t2[v] = 1
    end
    return t2
end

-- Stops mod from loading if Character Select isn't on, Does not need to be touched
if not charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

--- Load Models ---
local E_MODEL_FLOWERY = smlua_model_util_get_id("flowery_violet_geo")      -- Located in "actors"
local E_MODEL_TOADERY = smlua_model_util_get_id("toadery_flowery_geo")

local E_MODEL_FLOWERY_BLUE_COIN =     smlua_model_util_get_id("flowery_blue_coin_geo")
local E_MODEL_FLOWERY_RED_COIN =     smlua_model_util_get_id("flowery_red_coin_geo")
local E_MODEL_FLOWERY_YELLOW_COIN =    smlua_model_util_get_id("flowery_yellow_coin_geo")

local E_MODEL_FLOWERY_STAR = smlua_model_util_get_id("flowery_star_geo")

--- Load Textures ---
local TEX_FLOWERY_ICON = get_texture_info("flowery_violet_icon") -- Located in "textures"
local TEX_COINHUD = get_texture_info("flowery_coin_hud")
local TEX_FLOWERY_STAR_ICON = get_texture_info("flowery_star_icon")

FLOWERY_SOUND_JAST_KIDDING = CHAR_SOUND_MAX

-- All sound files are located in "sound" folder
local VOICETABLE_FLOWERY = {
    [CHAR_SOUND_OKEY_DOKEY] =        'FloweryItsMeFlowery.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] =         'FloweryLeafItToMe.ogg', -- Starting level
	[CHAR_SOUND_GAME_OVER] =         'FloweryGoodbye.ogg', -- Game Overed
	[CHAR_SOUND_PUNCH_YAH] =         'FloweryHah.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] =         'FloweryHoo.ogg', -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] =         'FloweryJarona.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] =       {'FloweryYes.ogg', 'FloweryStingus.ogg', 'FloweryMostlys.ogg'}, -- First Jump Sounds
	[CHAR_SOUND_HOOHOO] =            {'FloweryGlue.ogg', 'FloweryMyKing.ogg'}, -- Second jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'FloweryJarona1.ogg', 'FloweryJarona2.ogg', 'FloweryJarona3.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] =                'FloweryHuh.ogg', -- Soft wall bonk
	[CHAR_SOUND_UH2] =               'FloweryHuh.ogg', -- Quick ledge get up
	[CHAR_SOUND_UH2_2] =             'FloweryHuh.ogg', -- Landing after long jump
	[CHAR_SOUND_DOH] =               'FloweryHey.ogg', -- Hard wall bonk
	[CHAR_SOUND_OOOF] =              'FloweryHoo.ogg', -- Attacked in air
	[CHAR_SOUND_OOOF2] =             'FloweryHoo.ogg', -- Land from hard bonk
	[CHAR_SOUND_HAHA] =              'FloweryHereICome.ogg', -- Landing triple jump
	[CHAR_SOUND_HAHA_2] =            'FloweryHereICome.ogg', -- Landing in water from big fall
	[CHAR_SOUND_YAHOO] =             'FloweryJarona1.ogg', -- Long jump
	[CHAR_SOUND_WHOA] =              'FloweryWow.ogg', -- Grabbing ledge
	[CHAR_SOUND_EEUH] =              'FloweryFoundGlue.ogg', -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] =          'FloweryFalling.ogg', -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] =      'FloweryGreatStyle.ogg', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] =  'FloweryTakeThat.ogg', -- Ground Pound after startup
	[CHAR_SOUND_WAH2] =              'FloweryFlavor.ogg', -- Throwing something
	[CHAR_SOUND_HRMM] =              'FloweryGiveToYou.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] =        'FloweryHereIComeSanFrandisco.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] =   {'FloweryPredictableCreature.ogg', 'FloweryGetAChance.ogg'}, -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] =          'FloweryNoNoNo.ogg', -- Damaged
	[CHAR_SOUND_PANTING] =           'FloweryHuh.ogg', -- Low health
	[CHAR_SOUND_PANTING_COLD] =      'FloweryHuh.ogg', -- Getting cold
	[CHAR_SOUND_ON_FIRE] =           'FloweryFlesh.ogg', -- Burned
--SLEEP SOUNDS
	[CHAR_SOUND_IMA_TIRED] =         'FloweryMiniPeppers.ogg', -- Mario feeling tired
	[CHAR_SOUND_YAWNING] =           'FloweryDreams.ogg', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING3] =          'FloweryLady.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] =         'FloweryBlingoBlizzard.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] =         'FloweryFlesh.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] =         'FloweryFalling.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] =             'FloweryGoodbye.ogg', -- Dying from damage
	[CHAR_SOUND_DROWNING] =          'FloweryFlesh.ogg', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] =          'FloweryAllAccording.ogg', -- Booted out of level

    [FLOWERY_SOUND_JAST_KIDDING] = 'FloweryJastKidding.ogg'
}

local palettes = {
    {
        name = "Flowery",
        [PANTS]  = "715844",
        [SHIRT]  = "6FA626",
        [GLOVES] = "FFFFFF",
        [SHOES]  = "000000",
        [HAIR]   = "FEE502",
        [SKIN]   = "FFF06F",
        [CAP]    = "DF7332",
        [EMBLEM] = "736A3C"
    },
    {
        name = "Aqua",
        [PANTS]  = "54FFFE",
        [SHIRT]  = "54FFFE",
        [GLOVES] = "ED1C25",
        [SHOES]  = "ED1C25",
        [HAIR]   = "000000",
        [SKIN]   = "54FFFE",
        [CAP]    = "54FFFE",
        [EMBLEM] = "000000"
    },
    {
        name = "Seth",
        [PANTS]  = "9C7ED3",
        [SHIRT]  = "BA48AE",
        [GLOVES] = "BA48AE",
        [SHOES]  = "FFFFFF",
        [HAIR]   = "A349A5",
        [SKIN]   = "CE8FCD",
        [CAP]    = "BA48AE",
        [EMBLEM] = "A349A5"
    },
    {
        name = "Yellow",
        [PANTS]  = "DA8100",
        [SHIRT]  = "FEEB00",
        [GLOVES] = "FFA500",
        [SHOES]  = "DA8100",
        [HAIR]   = "FFA500",
        [SKIN]   = "FEFF41",
        [CAP]    = "FEEB00",
        [EMBLEM] = "FFA500"
    },
    {
        name = "Blue",
        [PANTS]  = "89C9EF",
        [SHIRT]  = "B7D2FF",
        [GLOVES] = "5060EA",
        [SHOES]  = "89C9EF",
        [HAIR]   = "B7D2FF",
        [SKIN]   = "5060EA",
        [CAP]    = "B7D2FF",
        [EMBLEM] = "B7D2FF"
    },
    {
        name = "Green",
        [PANTS]  = "79DE7C",
        [SHIRT]  = "A3FA5F",
        [GLOVES] = "79DE7C",
        [SHOES]  = "79DE7C",
        [HAIR]   = "A3FA5F",
        [SKIN]   = "D8F368",
        [CAP]    = "A3FA5F",
        [EMBLEM] = "79DE7C"
    },
    {
        name = "Orange",
        [PANTS]  = "FF8054",
        [SHIRT]  = "FF8054",
        [GLOVES] = "FFB63D",
        [SHOES]  = "FFB63D",
        [HAIR]   = "FF8054",
        [SKIN]   = "FFB63D",
        [CAP]    = "FF8054",
        [EMBLEM] = "FF8054"
    },
    {
        name = "Pink",
        [PANTS]  = "A73C5C",
        [SHIRT]  = "FF8A90",
        [GLOVES] = "A73C5C",
        [SHOES]  = "FFEAE9",
        [HAIR]   = "FF8A90",
        [SKIN]   = "FBD7C0",
        [CAP]    = "FF8A90",
        [EMBLEM] = "FF8A90"
    }
}

local HEALTH_METER_FLOWERY = {
    label = {
        left = get_texture_info("floweryleft"),
        right = get_texture_info("floweryright"),
    },
    pie = {
        get_texture_info("flowery1"),
        get_texture_info("flowery2"),
        get_texture_info("flowery3"),
        get_texture_info("flowery4"),
        get_texture_info("flowery5"),
        get_texture_info("flowery6"),
        get_texture_info("flowery7"),
        get_texture_info("flowery8"),
    }
}

local function flowery_health_render(localIndex, health, prevX, prevY, prevScaleW, prevScaleH, x, y, scaleW, scaleH)
    prevScaleW = prevScaleW / 64
    prevScaleH = prevScaleH / 64
    scaleW = scaleW / 64
    scaleH = scaleH / 64

    djui_hud_render_texture_interpolated(HEALTH_METER_FLOWERY.label.left, prevX, prevY, prevScaleW, prevScaleH, x, y, scaleW, scaleH)
    djui_hud_render_texture_interpolated(HEALTH_METER_FLOWERY.label.right, prevX + 32*prevScaleW, prevY, prevScaleW, prevScaleH, x + 32*scaleW, y, scaleW, scaleH)

    local healthSeg = math.clamp(health >> 8, 0, 8)
    if healthSeg > 0 then
        djui_hud_render_texture_interpolated(HEALTH_METER_FLOWERY.pie[healthSeg], prevX, prevY, prevScaleW, prevScaleH, x, y, scaleW, scaleH)
    end
end

local ANIMTABLE_FLOWERY = {
    [charSelect.CS_ANIM_MENU] = 'FloweryCS',
}

local function on_character_select_load()
    -- Adds the custom character to the Character Select Menu
    CT_FLOWERY = charSelect.character_add(
        "Flowery", -- Character Name
        "Hey guys, it's me Flowery! Asgore's college roommate... and best friend. I think I found myself in a new Dark World, and there seems to be a princess that needs to be saved! Perhaps I can wait on giving Asgore his perfect world, here I come San Frandisco!", -- Description
        "VioletSM64",     -- Credits
        "FEE502",         -- Menu Color
        E_MODEL_FLOWERY,  -- Character Model
        CT_MARIO,         -- Override Character
        TEX_FLOWERY_ICON, -- Life Icon
        1                 -- Camera Scale
    )

    charSelect.character_add_voice(E_MODEL_FLOWERY, VOICETABLE_FLOWERY)
    charSelect.character_add_voice(E_MODEL_TOADERY, VOICETABLE_FLOWERY)

    charSelect.character_add_palette_preset(E_MODEL_TOADERY, {
        [PANTS]  = "FFFFFF",
        [SHIRT]  = "4227B5",
        [GLOVES] = "FFFFFF",
        [SHOES]  = "68401B",
        [HAIR]   = "000000",
        [SKIN]   = "FED5A1",
        [CAP]    = "FF0000",
        [EMBLEM] = "000000"
        }, "Toadery"
    )
    for _, palette in ipairs(palettes) do
        charSelect.character_add_palette_preset(E_MODEL_FLOWERY, palette, palette.name)
        charSelect.character_add_palette_preset(E_MODEL_TOADERY, palette, palette.name)
    end

    charSelect.character_add_graffiti(CT_FLOWERY, TEX_FLOWERY_ICON)
    charSelect.character_set_category(CT_FLOWERY, TEXT_MOD_NAME)
    charSelect.character_add_animations(E_MODEL_FLOWERY, ANIMTABLE_FLOWERY, nil, nil)
    charSelect.character_add_celebration_star(E_MODEL_FLOWERY, nil, TEX_FLOWERY_STAR_ICON)

    charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvBlueCoinSliding, E_MODEL_FLOWERY_BLUE_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvBlueCoinJumping, E_MODEL_FLOWERY_BLUE_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvHiddenBlueCoin, E_MODEL_FLOWERY_BLUE_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvMovingBlueCoin, E_MODEL_FLOWERY_BLUE_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvMrIBlueCoin, E_MODEL_FLOWERY_BLUE_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvRedCoin, E_MODEL_FLOWERY_RED_COIN)
    charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvSingleCoinGetsSpawned, E_MODEL_FLOWERY_YELLOW_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvMoneybagHidden, E_MODEL_FLOWERY_YELLOW_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvMovingYellowCoin, E_MODEL_FLOWERY_YELLOW_COIN)
	charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvTemporaryYellowCoin, E_MODEL_FLOWERY_YELLOW_COIN)
    charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvYellowCoin, E_MODEL_FLOWERY_YELLOW_COIN)

    charSelect.character_add_model_replacement(CT_FLOWERY, id_bhvCelebrationStar, E_MODEL_FLOWERY_STAR)

    charSelect.character_add_texture_replacement(CT_FLOWERY, "texture_hud_char_coin", TEX_COINHUD)


    charSelect.credit_add(TEXT_MOD_NAME, "VioletSM64", "Pack")
    charSelect.credit_add(TEXT_MOD_NAME, "SwagSkeleton95", "Coding / HP Textures")
    charSelect.credit_add(TEXT_MOD_NAME, "Cooliokid 956", "Coding")
    charSelect.credit_add(TEXT_MOD_NAME, "DorfDork", "Coding")
    charSelect.credit_add(TEXT_MOD_NAME, "Agent X", "Subtitles Code")
    charSelect.credit_add(TEXT_MOD_NAME, "lemonsflp", "Flower Man SM64 Cover")

    charSelect.character_add_health_meter(CT_FLOWERY, flowery_health_render)
end

-- Waits until the API is fully loaded before adding chars, just to be safe
hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)