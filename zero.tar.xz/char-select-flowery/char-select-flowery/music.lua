if not charSelectExists then return end

local SEQ_FLOWERY_BATTLE = audio_stream_load("FlowerMan.ogg")

local function on_floweryseqload(player, seqID)
    audio_stream_stop(SEQ_FLOWERY_BATTLE)
    subtitleTimer = -1

    local charNum = charSelect.character_get_current_number()
    if charNum == CT_FLOWERY then
        if seqID == SEQ_LEVEL_BOSS_KOOPA_FINAL then
            if subtitleTimer >= 0 then return false end
            stop_cap_music()
            stop_shell_music()
            subtitleTimer = 0
            audio_stream_play(SEQ_FLOWERY_BATTLE, false, 1)
            audio_stream_set_looping(SEQ_FLOWERY_BATTLE, true)
            return 0
        end
    end
    return true
end

hook_event(HOOK_ON_SEQ_LOAD, on_floweryseqload)

-- Flower Man SM64 Arrangement by Lemonsflp