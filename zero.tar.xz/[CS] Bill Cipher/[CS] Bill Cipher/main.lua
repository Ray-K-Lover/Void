-- name: [CS] \\#FFF051\\Bill Cipher
-- description: Remember! Reality is an illusion, the universe is a hologram, buy gold, BYE!\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

local TEXT_MOD_NAME = "Bill Cipher"

-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_BILLCIPHER = smlua_model_util_get_id("billcipher_geo")

local TEX_BILLCIPHER_LIFE_ICON = get_texture_info("billcipher_icon")

local VOICETABLE_BILLCIPHER = {
	[CHAR_SOUND_ATTACKED] = {'BillCipherAttacked1.ogg', 'BillCipherAttacked2.ogg'},
	[CHAR_SOUND_COUGHING1] = 'BillCipherCoughing2.ogg',
	[CHAR_SOUND_COUGHING2] = 'BillCipherCoughing1.ogg',
	[CHAR_SOUND_COUGHING3] = 'BillCipherCoughing1.ogg',
	[CHAR_SOUND_DOH] = 'BillCipherDoh.ogg',
	[CHAR_SOUND_DROWNING] = 'BillCipherDrowning.ogg',
	[CHAR_SOUND_DYING] = {'BillCipherDying1.ogg', 'BillCipherDying2.ogg', 'BillCipherDying3.ogg'},
	[CHAR_SOUND_EEUH] = 'BillCipherEeuh.ogg',
	[CHAR_SOUND_GROUND_POUND_WAH] = 'BillCipherPunchWah.ogg',
	[CHAR_SOUND_HAHA] = 'BillCipherHaha.ogg',
	[CHAR_SOUND_HAHA_2] = 'BillCipherHaha2.ogg',
	[CHAR_SOUND_HERE_WE_GO] = {'BillCipherHereWeGo1.ogg', 'BillCipherHereWeGo2.ogg'},
	[CHAR_SOUND_HOOHOO] = 'BillCipherHoohoo.ogg',
	[CHAR_SOUND_HRMM] = 'BillCipherUh2.ogg',
	[CHAR_SOUND_IMA_TIRED] = 'Silent.ogg',
	[CHAR_SOUND_LETS_A_GO] = 'BillCipherLetsAGo.ogg',
	[CHAR_SOUND_MAMA_MIA] = {'BillCipherMamaMia1.ogg', 'BillCipherMamaMia2.ogg', 'BillCipherMamaMia3.ogg'},
	[CHAR_SOUND_OKEY_DOKEY] = 'BillCipherOkeyDokey.ogg',
	[CHAR_SOUND_ON_FIRE] = {'BillCipherOnFire1.ogg', 'BillCipherOnFire2.ogg'},
	[CHAR_SOUND_OOOF] = 'BillCipherOof.ogg',
	[CHAR_SOUND_OOOF2] = 'BillCipherOof2.ogg',
	[CHAR_SOUND_PANTING] = 'Silent.ogg',
	[CHAR_SOUND_PANTING_COLD] = 'Silent.ogg',
	[CHAR_SOUND_PUNCH_HOO] = 'BillCipherPunchHoo.ogg',
	[CHAR_SOUND_PUNCH_WAH] = 'BillCipherPunchWah.ogg',
	[CHAR_SOUND_PUNCH_YAH] = 'BillCipherPunchYah.ogg',
	[CHAR_SOUND_SNORING1] = 'Silent.ogg',
	[CHAR_SOUND_SNORING2] = 'Silent.ogg',
	[CHAR_SOUND_SNORING3] = 'Silent.ogg',
	[CHAR_SOUND_SO_LONGA_BOWSER] = 'BillCipherSoLongBowser.ogg',
	[CHAR_SOUND_TWIRL_BOUNCE] = 'BillCipherBoing.ogg',
	[CHAR_SOUND_UH] = 'BillCipherUh.ogg',
	[CHAR_SOUND_UH2] = 'BillCipherUh2.ogg',
	[CHAR_SOUND_UH2_2] = 'BillCipherUh2.ogg',
	[CHAR_SOUND_WAAAOOOW] = {'BillCipherFalling1.ogg', 'BillCipherFalling2.ogg'},
	[CHAR_SOUND_WAH2] = 'BillCipherWah2.ogg',
	[CHAR_SOUND_WHOA] = 'BillCipherWoah.ogg',
	[CHAR_SOUND_YAHOO] = 'BillCipherYahoo.ogg',
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'BillCipherYahoo.ogg', 'BillCipherWaha.ogg', 'BillCipherYippee.ogg'},
	[CHAR_SOUND_YAH_WAH_HOO] = {'BillCipherYah.ogg', 'BillCipherWah.ogg', 'BillCipherHoo.ogg'},
	[CHAR_SOUND_YAWNING] = 'Silent.ogg',
}

local CAPTABLE_BILLCIPHER = {
    normal = smlua_model_util_get_id("billcipher_hat_geo"),
    wing = smlua_model_util_get_id("billcipher_winghat_geo"),
    metal = smlua_model_util_get_id("billcipher_metalhat_geo"),
    metalWing = smlua_model_util_get_id("billcipher_wingmetalhat_geo"),
}

local PALETTE_BILLCIPHER = {
    [PANTS]  = "000000",
    [SHIRT]  = "ffffff",
    [GLOVES] = "ffffff",
    [SHOES]  = "ffffff",
    [HAIR]   = "ffffff",
    [SKIN]   = "FFF051",
    [CAP]    = "000000",
    [EMBLEM] = "000000"
}

local CSloaded = false
local function on_character_select_load()
    CT_CHARNAME2 = _G.charSelect.character_add("Bill Cipher", {"Remember! Reality is an illusion,", "the universe is a hologram,", "buy gold, BYE!"}, "Cmanflip", {r = 255, g = 240, b = 81}, E_MODEL_BILLCIPHER, CT_CHARNAME2, TEX_BILLCIPHER_LIFE_ICON)
    _G.charSelect.character_add_caps(E_MODEL_BILLCIPHER, CAPTABLE_BILLCIPHER)
    _G.charSelect.character_add_voice(E_MODEL_BILLCIPHER, VOICETABLE_BILLCIPHER)
    _G.charSelect.character_add_palette_preset(E_MODEL_BILLCIPHER, PALETTE_BILLCIPHER)

    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_BILLCIPHER then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_BILLCIPHER then return _G.charSelect.voice.snore(m) end
end

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)