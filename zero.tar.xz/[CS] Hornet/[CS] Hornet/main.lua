-- name: [CS] Hornet
-- description: Hornet from Hollow Knight and Silksong!!\n\n\\#ff7777\\This Pack requires Character Select\nto use as a Library!

if not _G.charSelectExists then
    djui_popup_create(
        "\\#ffffdc\\\n [CS] Hornet \nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!",
        6)
    return
end


local E_MODEL_HORNET = smlua_model_util_get_id('hornet_geo')
local E_MODEL_MASK_SHARD = smlua_model_util_get_id('mask_shard_geo')

local TEX_HORNET_ICON = get_texture_info('hornet-icon')
local TEX_MASK_ICON = get_texture_info('mask-icon')

local VOICETABLE_HORNET = {
    [CHAR_SOUND_ATTACKED] = 'hornet_ouch.ogg',
    [CHAR_SOUND_DOH] = 'hornet_bonk0.ogg',
    [CHAR_SOUND_DROWNING] = 'hornet_death.ogg',
    [CHAR_SOUND_DYING] = 'hornet_death.ogg',
    [CHAR_SOUND_GROUND_POUND_WAH] = 'hornet_shaa.ogg',
    [CHAR_SOUND_HAHA] = { 'hornet_laugh1.ogg', 'hornet_laugh0.ogg' },
    [CHAR_SOUND_HAHA_2] = 'hornet_laugh1.ogg',
    [CHAR_SOUND_HERE_WE_GO] = 'hornet_victory.ogg',
    [CHAR_SOUND_HOOHOO] = 'hornet_att0.ogg',
    [CHAR_SOUND_HRMM] = 'hornet_flourish.ogg',
    [CHAR_SOUND_LETS_A_GO] = 'hornet_letsago.ogg',
    [CHAR_SOUND_MAMA_MIA] = { 'hornet_speak0.ogg', 'hornet_speak1.ogg' },
    [CHAR_SOUND_ON_FIRE] = 'hornet_ouch.ogg',
    [CHAR_SOUND_OOOF] = 'hornet_bonk1.ogg',
    [CHAR_SOUND_OOOF2] = 'hornet_bonk1.ogg',
    [CHAR_SOUND_PUNCH_HOO] = 'hornet_att1.ogg',
    [CHAR_SOUND_PUNCH_WAH] = 'hornet_jump1.ogg',
    [CHAR_SOUND_PUNCH_YAH] = 'hornet_att0.ogg',
    [CHAR_SOUND_SO_LONGA_BOWSER] = 'hornet_flourish.ogg',
    [CHAR_SOUND_TWIRL_BOUNCE] = 'hornet_flourish.ogg',
    [CHAR_SOUND_UH] = 'hornet_bonk1.ogg',
    [CHAR_SOUND_UH2] = 'hornet_jump0.ogg',
    [CHAR_SOUND_UH2_2] = 'hornet_bonk1.ogg',
    [CHAR_SOUND_WAAAOOOW] = 'hornet_death.ogg',
    [CHAR_SOUND_WAH2] = 'hornet_att0.ogg',
    [CHAR_SOUND_WHOA] = 'hornet_bonk1.ogg',
    [CHAR_SOUND_YAHOO] = 'hornet_shaa.ogg',
    [CHAR_SOUND_YAHOO_WAHA_YIPPEE] = { 'hornet_yell0.ogg', 'hornet_yell1.ogg' },
    [CHAR_SOUND_YAH_WAH_HOO] = { 'hornet_jump0.ogg', 'hornet_jump1.ogg' },
}


local CAPS_HORNET = {
    normal = smlua_model_util_get_id("hornet_cap_geo"),
    wing = smlua_model_util_get_id("hornet_wing_cap_geo"),
    metal = smlua_model_util_get_id("hornet_metal_cap_geo"),
    metalWing = smlua_model_util_get_id("hornet_metal_wing_cap_geo")
}


local PALETTE_HORNET = {
    [SHIRT] = { r = 0x58, g = 0x00, b = 0x20 },
    [CAP] = { r = 0x89, g = 0x17, b = 0x40 },
}

local ANIMTABLE_HORNET = {
    [_G.charSelect.CS_ANIM_MENU] = 'hornet_idle',
    [CHAR_ANIM_IDLE_HEAD_CENTER] = 'hornet_idle',
    [CHAR_ANIM_IDLE_HEAD_LEFT] = 'hornet_idle',
    [CHAR_ANIM_IDLE_HEAD_RIGHT] = 'hornet_idle',
    [CHAR_ANIM_FIRST_PERSON] = 'hornet_idle',
}

local SAMPLE_DASH = audio_sample_load('hornet_dash.ogg')
local SAMPLE_NEEDLE_SWING = audio_sample_load('needle_swing.ogg')

CT_HORNET = _G.charSelect.character_add("Hornet",
    { "Rogue protector of the ruins of Hallownest", "Keeping herself busy in Silksong!" }, "wibblus",
    { r = 200, g = 20, b = 80 }, E_MODEL_HORNET, CT_MARIO, TEX_HORNET_ICON)

_G.charSelect.character_add_caps(E_MODEL_HORNET, CAPS_HORNET)
_G.charSelect.character_add_celebration_star(E_MODEL_HORNET, E_MODEL_MASK_SHARD, TEX_MASK_ICON)
_G.charSelect.character_add_voice(E_MODEL_HORNET, VOICETABLE_HORNET)
_G.charSelect.character_add_palette_preset(E_MODEL_HORNET, PALETTE_HORNET)
_G.charSelect.character_add_animations(E_MODEL_HORNET, ANIMTABLE_HORNET)

_G.charSelect.config_character_sounds()


---@param m MarioState
local function hornet_update(m)
    local animInfo = m.marioObj.header.gfx.animInfo
    -- needle swing
    if m.flags & MARIO_CAP_ON_HEAD ~= 0 and (m.action == ACT_HORNET_ATTACK or m.action == ACT_JUMP_KICK) then
        smlua_anim_util_set_animation(m.marioObj, 'hornet_att0')

        m.marioBodyState.capState = 1
        if animInfo.animFrame < 5 then
            m.marioBodyState.handState = 4
        else
            m.marioBodyState.handState = 3
        end
    end
    -- happy face
    if m.marioBodyState.handState == 2 then
        m.marioBodyState.eyeState = 4
    end

    if m.playerIndex == 0 then
        if m.action == ACT_DIVE and animInfo.animFrame < 8 then
            m.vel.y = 1.0
            m.forwardVel = max(45.0, m.forwardVel)
            set_mario_particle_flags(m, PARTICLE_DUST, 0)
        end
    end
end
_G.charSelect.character_hook_moveset(CT_HORNET, HOOK_MARIO_UPDATE, hornet_update)

---@param m MarioState
local function before_set_action(m, nextAct)
    if m.playerIndex ~= 0 then return end

    if m.flags & MARIO_CAP_ON_HEAD ~= 0 then
        if (nextAct == ACT_PUNCHING or nextAct == ACT_MOVE_PUNCHING) and m.input & (INPUT_Z_DOWN | INPUT_A_DOWN) == 0 then
            return set_mario_action(m, ACT_HORNET_ATTACK, 0)
        end
    end
end
_G.charSelect.character_hook_moveset(CT_HORNET, HOOK_BEFORE_SET_MARIO_ACTION, before_set_action)

---@param m MarioState
local function on_set_action(m)
    if m.flags & MARIO_CAP_ON_HEAD ~= 0 then
        if m.action == ACT_JUMP_KICK then
            audio_sample_play(SAMPLE_NEEDLE_SWING, m.pos, 1.0)
        end
        if m.action == ACT_DIVE then
            audio_sample_play(SAMPLE_DASH, m.pos, 1.0)
        end
    end
end
_G.charSelect.character_hook_moveset(CT_HORNET, HOOK_ON_SET_MARIO_ACTION, on_set_action)

local function on_interact(m, o, intType)
    if intType == INTERACT_GRABBABLE and m.action == ACT_HORNET_ATTACK and o.oInteractionSubtype & INT_SUBTYPE_NOT_GRABBABLE == 0 then
        m.interactObj = o
        m.usedObj = o
        if o.oSyncID ~= 0 then network_send_object(o, true) end

        set_anim_to_frame(m, 25)
        set_mario_action(m, ACT_PICKING_UP, 0)
    end
end
_G.charSelect.character_hook_moveset(CT_HORNET, HOOK_ON_INTERACT, on_interact)


ACT_HORNET_ATTACK = allocate_mario_action(ACT_GROUP_OBJECT | ACT_FLAG_ATTACKING)

---@param m MarioState
local function act_hornet_attack(m)
    if m.actionTimer == 0 then
        set_mario_animation(m, CHAR_ANIM_FIRST_PUNCH_FAST)
        set_anim_to_frame(m, 0)
        play_character_sound(m, CHAR_SOUND_PUNCH_YAH)
        audio_sample_play(SAMPLE_NEEDLE_SWING, m.pos, 1.0)

        m.forwardVel = max(16.0, m.forwardVel)
    end
    if (m.actionTimer > 6 and m.actionState == 0) or m.actionTimer > 14 then
        if m.input & INPUT_NONZERO_ANALOG ~= 0 then
            return set_mario_action(m, ACT_WALKING, 0)
        end
        if m.controller.buttonPressed & A_BUTTON ~= 0 then
            return set_mario_action(m, ACT_JUMP, 0)
        end
        if m.controller.buttonPressed & B_BUTTON ~= 0 then
            m.actionTimer = 0
            return set_mario_action(m, ACT_HORNET_ATTACK, 0)
        end
    end
    if m.actionTimer > 24 then
        return set_mario_action(m, ACT_IDLE, 0)
    end

    mario_set_forward_vel(m, approach_f32(m.forwardVel, 0.0, 7.0, 3.0))
    local step = perform_ground_step(m)

    if step == GROUND_STEP_HIT_WALL and m.actionState == 0 then
        play_sound(SOUND_ACTION_HIT, m.marioObj.header.gfx.cameraToObject)
        set_mario_particle_flags(m, PARTICLE_TRIANGLE, 0)
        m.forwardVel = -50.0
        m.actionState = 1
    end
    if step == GROUND_STEP_LEFT_GROUND then
        return set_mario_action(m, ACT_FREEFALL, 0)
    end

    m.actionTimer = m.actionTimer + 1
end
hook_mario_action(ACT_HORNET_ATTACK, act_hornet_attack, INT_PUNCH)
