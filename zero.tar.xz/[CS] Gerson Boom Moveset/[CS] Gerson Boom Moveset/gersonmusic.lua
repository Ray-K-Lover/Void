local bowserBGM = audio_stream_load("knight.ogg")
audio_stream_set_looping(bowserBGM, true)

local bowserBGM2 = audio_stream_load("guardian.ogg")
audio_stream_set_looping(bowserBGM2, true)

local gersonBGM = audio_stream_load("oldman_helps_out.ogg")
audio_stream_set_looping(gersonBGM, true)

local coolBool = false


GERSONBGMLIST ={
    {
       replace = SEQ_LEVEL_BOSS_KOOPA,
       volume = 0.8,
       song = bowserBGM
    },
    {
       replace = SEQ_LEVEL_BOSS_KOOPA_FINAL,
       volume = 1.0,
       song = bowserBGM2
    },
}

local function seq_load_function(soundPlayer, songValue)
	if (songValue == SEQ_EVENT_PEACH_MESSAGE and gNetworkPlayers[0].currLevelNum == LEVEL_BOWSER_3) then
		audio_stream_stop(bowserBGM2)
		audio_stream_play(gersonBGM, true, 0.8)
		return 0
	end
	audio_stream_stop(gersonBGM)
	for i = 1, #GERSONBGMLIST do
		local song = GERSONBGMLIST[i]
		if gGlobalSyncTable.JBchallenge and (gPlayerSyncTable[0].DRstate ~= 0) then
			if (songValue == song.replace) then
				sound_reset_background_music_default_volume(song.replace)
				audio_stream_play(song.song, true, song.volume) --The number here is the volume. 1.0 is the default; set it to whatever you want
				sound_set_background_music_default_volume(song.replace, 0)
				return song.replace;
			end
		end
		audio_stream_stop(song.song)
		sound_reset_background_music_default_volume(song.replace)
	end
end


local function music_init(warpType, levelNum, areaIdx, nodeId, arg)
    coolBool = false
end

local function update_function(m)
    if (m.playerIndex ~= 0) then
        return false
    end
    if (coolBool) then
        local nearBowser = obj_get_nearest_object_with_behavior_id(m.marioObj, id_bhvBowser)
		if nearBowser == nil then return end
		if (nearBowser.oBehParams2ndByte == 2) then
			if (nearBowser.oAction == 4) then
				if (m.action == ACT_READING_NPC_DIALOG) then
					audio_stream_set_volume(gersonBGM, 0.5)
				elseif (nearBowser.oSubAction > 10) then
					audio_stream_stop(gersonBGM)
					coolBool = false
				end
			end
		else
			if (nearBowser.oAction == 4) then
				if (m.action == ACT_READING_NPC_DIALOG) then
					audio_stream_set_volume(bowserBGM, 0.5)
					audio_stream_set_volume(bowserBGM2, 0.5)
				elseif (nearBowser.oSubAction > 3) then
					audio_stream_stop(bowserBGM)
					audio_stream_stop(bowserBGM2)
					coolBool = false
				end
			end
		end
    else
        local nearBowser = obj_get_nearest_object_with_behavior_id(m.marioObj, id_bhvBowser)
        if (nearBowser ~= nil and nearBowser.oAction > 6) then
            coolBool = true
        end
    end
end

hook_event(HOOK_ON_WARP, music_init)
hook_event(HOOK_MARIO_UPDATE, update_function)
hook_event(HOOK_ON_SEQ_LOAD, seq_load_function)