if not _G.charSelectExists then return end

local SOUND_BUSTERHIT = audio_sample_load('snd_rudebuster_hit.ogg')
local SOUND_BUSTERSWING = audio_sample_load('snd_rudebuster_swing.ogg')
SOUND_BOWSERREFLECT = audio_sample_load('snd_weaponpull_fast.ogg')
local E_MODEL_BUSTEREFFECT =      smlua_model_util_get_id("gbustereffect_geo")      -- Located in "actors"

local isBowserNerfed = false

function bhv_custom_box_init(obj)
    obj.oFlags = OBJ_FLAG_HOLDABLE | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_SET_FACE_YAW_TO_MOVE_YAW | OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    cur_obj_scale(1.0)
    obj.oGravity = 2.5
    obj.oFriction = 0.99
    obj.oBuoyancy = 0
    obj.oInteractType = INTERACT_BOUNCE_TOP
    obj.hitboxDownOffset = 20
    obj.oDamageOrCoinValue = 0
    obj.oHealth = 2
    obj.hitboxRadius = 80
    obj.hitboxHeight = 80
    obj.hurtboxRadius = 80
    obj.hurtboxHeight = 80
    obj.oWallHitboxRadius = 160
    obj.oAnimState = 1
    obj.oIntangibleTimer = 0
    obj.oFlags = obj.oFlags & ~0x08

end

function bhv_custom_box2_init(obj)
    obj.oFlags = OBJ_FLAG_HOLDABLE | OBJ_FLAG_COMPUTE_DIST_TO_MARIO | OBJ_FLAG_SET_FACE_YAW_TO_MOVE_YAW | OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    cur_obj_scale(1.0)
    obj.oGravity = 2.5
    obj.oFriction = 0.99
    obj.oBuoyancy = 1.4
    obj.oInteractType = INTERACT_BOUNCE_TOP
    obj.hitboxDownOffset = 20
    obj.oDamageOrCoinValue = 0
    obj.oHealth = 2
    obj.hitboxRadius = 80
    obj.hitboxHeight = 80
    obj.hurtboxRadius = 80
    obj.hurtboxHeight = 80
    obj.oWallHitboxRadius = 160
    obj.oAnimState = 1
    obj.oIntangibleTimer = 0
    obj.oFlags = obj.oFlags & ~0x08

end

function bhv_gersonbuster_init(obj)
    obj.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    cur_obj_scale(1.0)
    cur_obj_become_tangible()
    obj.oGravity            = 0
    obj.oDragStrength       = 0.0
    obj.oFriction           = 1.0
    obj.oBuoyancy           = -2.0
    obj.oWallHitboxRadius   = 5
    obj.hitboxDownOffset    = 50
    obj.hitboxRadius        = 120
    obj.hitboxHeight        = 250
    obj.hurtboxRadius       = 120
    obj.hurtboxHeight       = 250
	if (obj.oDamageOrCoinValue == 0) then
		obj.oDamageOrCoinValue  = 2
	end
    obj.oHealth             = 0
    obj.oInteractType       = INTERACT_DAMAGE
    obj.oNumLootCoins       = 1
    audio_sample_play(SOUND_BUSTERSWING, {x = obj.oPosX, y = obj.oPosY, z = obj.oPosZ}, 1.0)
end

function bhv_gersonbustereffect_init(obj)
    obj.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    cur_obj_scale(1.8)
    obj.oOpacity = 255
end


function bhv_custom_box_loop(obj)
    local sp1E = object_step()
    if (sp1E & 2 ~= 0) then
        cur_obj_resolve_wall_collisions()
        play_sound(SOUND_ACTION_BOUNCE_OFF_OBJECT, obj.header.gfx.cameraToObject)
        obj.oHealth = obj.oHealth - 1
        obj.oForwardVel = math.clamp(obj.oForwardVel * 1.5, -120, 120)
        obj.oMoveAngleYaw = obj.oWallAngle
    end
    obj.oFaceAngleYaw = obj.oFaceAngleYaw + 0x80 * obj.oForwardVel
    local i = 0
    for i = 0, obj.numCollidedObjs do
        local ObjectValue = obj_get_collided_object(obj, i)
        if (ObjectValue ~= nil and obj_is_attackable(ObjectValue) and obj_is_valid_for_interaction(ObjectValue)) then
            ObjectValue.oInteractStatus = ATTACK_FAST_ATTACK | INT_STATUS_INTERACTED | INT_STATUS_WAS_ATTACKED
            play_sound(SOUND_ACTION_HIT_2, obj.header.gfx.cameraToObject)
            obj.oHealth = obj.oHealth - 1
            obj.oForwardVel = obj.oForwardVel * -1
        end
    end

    if (sp1E == 1) then
        cur_obj_play_sound_2(SOUND_GENERAL_BOX_LANDING_2);
    end
    if (sp1E & 1 ~= 0) then
        if (obj.oForwardVel > 20) then
            cur_obj_play_sound_2(SOUND_ENV_SLIDING);
            spawn_sync_object(id_bhvSmoke, E_MODEL_SMOKE, obj.oPosX + ((random_float()*80) - 40), obj.oPosY, obj.oPosZ + ((random_float()*80) - 40), nil)
        end
        --
    end
    if (obj.oHealth < 1 or (obj.oInteractStatus & INT_STATUS_INTERACTED) ~= 0) or (obj.oForwardVel < 6) then
        spawn_mist_particles()
        obj_mark_for_deletion(obj)
    end
    obj_check_floor_death(sp1E, obj.oFloor)
    if (obj.oAction == 100) then
        obj_lava_death()
    elseif (obj.oAction == 101) then
        obj_mark_for_deletion(obj)
    end
    if (obj.oTimer > 500) then
        spawn_mist_particles()
        obj_mark_for_deletion(obj)
    end
end

-------------------------------------------
-------------CREDIT TO WIBBLUS-------------
-------------------------------------------

local function hit_effect_normal(o, target)
    target.oInteractStatus = target.oInteractStatus | ATTACK_FAST_ATTACK | INT_STATUS_WAS_ATTACKED | INT_STATUS_INTERACTED | INT_STATUS_TOUCHED_BOB_OMB
end

local function hit_effect_contact(o, target)
    target.oInteractStatus = target.oInteractStatus | ATTACK_FAST_ATTACK | INT_STATUS_WAS_ATTACKED | INT_STATUS_INTERACTED | ATTACK_FROM_ABOVE

    spawn_mist_particles()
    obj_mark_for_deletion(o)
end

local function hit_effect_bully(o, target)
    target.oInteractStatus = target.oInteractStatus | ATTACK_FAST_ATTACK | INT_STATUS_WAS_ATTACKED | INT_STATUS_INTERACTED

    target.oMoveAngleYaw = o.oMoveAngleYaw
    target.oForwardVel = 40

    spawn_mist_particles()
    obj_mark_for_deletion(o)
end

local function hit_effect_mrblizzard(o, target)
    target.prevObj = nil
    target.oMrBlizzardHeldObj = nil
    target.oAction = MR_BLIZZARD_ACT_DEATH
end

local function hit_effect_piranhaplant(o, target)
    target.oAction = PIRANHA_PLANT_ACT_ATTACKED

    spawn_mist_particles()
    obj_mark_for_deletion(o)
end

local function hit_effect_kingbobomb(o, target)
    if target.oFlags & OBJ_FLAG_HOLDABLE ~= 0 and target.oAction ~= 8 then
        target.oVelY = 30
        target.oForwardVel = 30
        target.oMoveAngleYaw = o.oMoveAngleYaw
        target.oMoveFlags = 0
        target.oAction = 4
    end

    spawn_mist_particles()
    obj_mark_for_deletion(o)
end

local function hit_effect_bowser(o, target)
    if target.oFlags & OBJ_FLAG_HOLDABLE ~= 0 and target.oAction ~= 19 and target.oAction ~= 4 and target.oAction ~= 12 then
		if (o.oBehParams < 10) then
			play_sound(SOUND_OBJ2_BOWSER_ROAR, target.header.gfx.cameraToObject)
			target.oAction = 3
			target.oVelX = 0
			target.oVelZ = 0
			target.oForwardVel = 0
			obj_init_animation(target, 10)
			target.header.gfx.animInfo.animFrame = 20
			audio_sample_play(SOUND_BOWSERREFLECT, {x = o.oPosX, y = o.oPosY, z = o.oPosZ}, 0.4)
			target.oFaceAngleYaw = obj_angle_to_object(o, gMarioStates[network_local_index_from_global(o.globalPlayerIndex)].marioObj)
			target.oMoveAngleYaw = obj_angle_to_object(o, gMarioStates[network_local_index_from_global(o.globalPlayerIndex)].marioObj)
			if network_global_index_from_local(0) == o.globalPlayerIndex then
				local busterObj = spawn_sync_object(
						id_bhvGersonBuster,
						E_MODEL_BUSTERMOVE,
						o.oPosX + o.oVelX, o.oPosY + o.oVelY, o.oPosZ + o.oVelZ,
						function(busterObj)
							busterObj.oFaceAngleYaw = obj_angle_to_object(o, gMarioStates[o.oUnk1A8].marioObj)
							busterObj.oMoveAngleYaw = obj_angle_to_object(o, gMarioStates[o.oUnk1A8].marioObj)
							busterObj.oBehParams = o.oBehParams + 1
							busterObj.oForwardVel = 10 * (o.oBehParams + 4*target.oBehParams2ndByte)
							busterObj.globalPlayerIndex = network_global_index_from_local(o.oUnk1A8)
							busterObj.oUnk1A8 = o.oUnk1A8
							busterObj.parentObj = target
							busterObj.oDamageOrCoinValue = o.oDamageOrCoinValue + target.oBehParams2ndByte
						end
						)
			end
		elseif (target.oBehParams2ndByte == 1) then
			if (target.oHealth <= -1) then
				spawn_mist_particles()
				audio_sample_play(SOUND_BUSTERHIT, {x = o.oPosX, y = o.oPosY, z = o.oPosZ}, 1.0)
				target.oAction = 4
				if network_global_index_from_local(0) == o.globalPlayerIndex then
					local busterObj = spawn_sync_object(
							id_bhvGersonBuster,
							E_MODEL_NONE,
							o.oPosX + o.oVelX, o.oPosY + o.oVelY, o.oPosZ + o.oVelZ,
							function(busterObj)
								busterObj.oFaceAngleYaw = target.oFaceAngleYaw
								busterObj.oMoveAngleYaw = target.oFaceAngleYaw
								busterObj.oForwardVel = 0
								busterObj.globalPlayerIndex = network_global_index_from_local(o.oUnk1A8)
								busterObj.oUnk1A8 = o.oUnk1A8
								busterObj.parentObj = target
								busterObj.oDamageOrCoinValue = 0
								busterObj.oCapUnkF4 = 1
								busterObj.oIntangibleTimer = -1
							end
							)
				end
			elseif (target.oHealth == 0) then
				spawn_mist_particles()
				audio_sample_play(SOUND_BUSTERHIT, {x = o.oPosX, y = o.oPosY, z = o.oPosZ}, 1.0)
				target.oAction = 12
				playerTP[o.oUnk1A8] = 100
				target.oHealth = target.oHealth - 1
			else
				target.oHealth = target.oHealth - 1
				playerTP[o.oUnk1A8] = 100
				obj_init_animation(target, 1)
				play_sound(SOUND_OBJ_BOWSER_TAIL_PICKUP, target.header.gfx.cameraToObject)
				target.oAction = 16
			end
		elseif (target.oBehParams2ndByte == 0) then
			spawn_mist_particles()
			audio_sample_play(SOUND_BUSTERHIT, {x = o.oPosX, y = o.oPosY, z = o.oPosZ}, 1.0)
			if (target.oHealth <= 0) then
				target.oAction = 4
				if network_global_index_from_local(0) == o.globalPlayerIndex then
					local busterObj = spawn_sync_object(
							id_bhvGersonBuster,
							E_MODEL_NONE,
							o.oPosX + o.oVelX, o.oPosY + o.oVelY, o.oPosZ + o.oVelZ,
							function(busterObj)
								busterObj.oFaceAngleYaw = target.oFaceAngleYaw
								busterObj.oMoveAngleYaw = target.oFaceAngleYaw
								busterObj.oForwardVel = 0
								busterObj.globalPlayerIndex = network_global_index_from_local(o.oUnk1A8)
								busterObj.oUnk1A8 = o.oUnk1A8
								busterObj.parentObj = target
								busterObj.oDamageOrCoinValue = 0
								busterObj.oCapUnkF4 = 1
								busterObj.oIntangibleTimer = -1
							end
							)
				end
			else
				playerTP[o.oUnk1A8] = 100
				target.oHealth = target.oHealth - 1
				target.oAction = 12
			end
		else
			spawn_mist_particles()
			audio_sample_play(SOUND_BUSTERHIT, {x = o.oPosX, y = o.oPosY, z = o.oPosZ}, 1.0)
			if (target.oHealth <= 0) then
				target.oAction = 4
				if network_global_index_from_local(0) == o.globalPlayerIndex then
					local busterObj = spawn_sync_object(
							id_bhvGersonBuster,
							E_MODEL_NONE,
							o.oPosX + o.oVelX, o.oPosY + o.oVelY, o.oPosZ + o.oVelZ,
							function(busterObj)
								busterObj.oFaceAngleYaw = target.oFaceAngleYaw
								busterObj.oMoveAngleYaw = target.oFaceAngleYaw
								busterObj.oForwardVel = 0
								busterObj.globalPlayerIndex = network_global_index_from_local(o.oUnk1A8)
								busterObj.oUnk1A8 = o.oUnk1A8
								busterObj.parentObj = target
								busterObj.oDamageOrCoinValue = 0
								busterObj.oCapUnkF4 = 1
								busterObj.oIntangibleTimer = -1
							end
							)
				end
			else
				if (isBowserNerfed) then
					obj_spawn_yellow_coins(o, 3)
				end
				playerTP[o.oUnk1A8] = 100
				target.oHealth = target.oHealth - 1
				target.oAction = 12
				if (target.oHealth == 1) then
					play_music(SEQ_PLAYER_LEVEL, SEQ_EVENT_PEACH_MESSAGE, 0)
				end
			end
		end
    end
    obj_mark_for_deletion(o)
end

local function hit_effect_bullet(o, target)
    spawn_mist_particles_with_sound(SOUND_GENERAL2_BOBOMB_EXPLOSION)
    target.oAction = 3

    spawn_mist_particles()
    obj_mark_for_deletion(o)
end

local function hit_effect_chuckya(o, target)
    target.oAction = 2
    target.oVelY = 30
    target.oMoveAngleYaw = o.oMoveAngleYaw
    target.oForwardVel = 30

    spawn_mist_particles()
    obj_mark_for_deletion(o)
end

local function hit_effect_destroy(o, target)
    spawn_mist_particles_with_sound(SOUND_GENERAL2_BOBOMB_EXPLOSION)
    obj_mark_for_deletion(target)
    obj_mark_for_deletion(o)
end

local PossibleBusterTargets = {
    [id_bhvMario] = function () end,
    [id_bhvGoomba] = hit_effect_normal,
    [id_bhvBobomb] = hit_effect_normal,
    [id_bhvKoopa] = hit_effect_normal,
    [id_bhvFlyGuy] = hit_effect_normal,
    [id_bhvMontyMole] = hit_effect_normal,
    [id_bhvSpindrift] = hit_effect_normal,
    [id_bhvBoo] = hit_effect_normal,
    [id_bhvGhostHuntBoo] = hit_effect_normal,
    [id_bhvBooInCastle] = hit_effect_normal,
    [id_bhvBooWithCage] = hit_effect_normal,
    [id_bhvMerryGoRoundBoo] = hit_effect_normal,
    [id_bhvFlyingBookend] = hit_effect_normal,
    [id_bhvSkeeter] = hit_effect_normal,
    [id_bhvScuttlebug] = hit_effect_normal,
    [id_bhvMoneybag] = hit_effect_normal,
    [id_bhvSnufit] = hit_effect_normal,
    [id_bhvSwoop] = hit_effect_normal,
    [id_bhvEnemyLakitu] = hit_effect_normal,
    [id_bhvSpiny] = hit_effect_normal,
    [id_bhvPokey] = hit_effect_normal,
    [id_bhvPokeyBodyPart] = hit_effect_normal,

    [id_bhvFirePiranhaPlant] = hit_effect_contact,
    [id_bhvBalconyBigBoo] = hit_effect_contact,
    [id_bhvGhostHuntBigBoo] = hit_effect_contact,
    [id_bhvMerryGoRoundBigBoo] = hit_effect_contact,
    [id_bhvChainChomp] = hit_effect_contact,
    [id_bhvBreakableBox] = hit_effect_contact,
    [id_bhvWigglerHead] = hit_effect_contact,
    [id_bhvEyerokHand] = hit_effect_contact,
    [id_bhvKlepto] = hit_effect_contact,

    [id_bhvHeaveHo] = hit_effect_destroy,

    [id_bhvSmallBully] = hit_effect_bully,
    [id_bhvBigBully] = hit_effect_bully,
    [id_bhvSmallChillBully] = hit_effect_bully,
    [id_bhvBigChillBully] = hit_effect_bully,
    [id_bhvMrBlizzard] = hit_effect_mrblizzard,
    [id_bhvPiranhaPlant] = hit_effect_piranhaplant,
    [id_bhvBulletBill] = hit_effect_bullet,
    [id_bhvChuckya] = hit_effect_chuckya,

    [id_bhvKingBobomb] = hit_effect_kingbobomb,
    [id_bhvBowser] = hit_effect_bowser,
}

local function bhv_gersonbuster_loop(obj)
	if (obj.oCapUnkF4 == 1) then
		obj.hitboxRadius = 0
		obj.oIntangibleTimer = -1
		obj.hitboxHeight = 0
		obj.hurtboxRadius = 0
		obj.hurtboxHeight = 0
		obj.oInteractType = 0
		if (obj_has_behavior_id(obj.parentObj, id_bhvBowser) ~= 0) then
			if (obj.parentObj.oForwardVel ~= 0) then
				obj.parentObj.oForwardVel = 0
				obj.parentObj.oVelX = 0
				obj.parentObj.oVelZ = 0
			end
			obj.parentObj.oFaceAngleYaw = obj.oFaceAngleYaw
			obj.parentObj.oMoveAngleYaw = obj.oFaceAngleYaw
		elseif (obj.parentObj.oSubAction > 1) then
			obj_mark_for_deletion(obj)
		end
	else
		-- phys step
		local step = object_step_without_floor_orient()
		obj.oForwardVel = obj.oForwardVel + obj.oTimer
		-- setup for targetting
		local busterTarget
		local targetDistance = 0x56000.0
		-- attack enemies
		if (obj_has_behavior_id(obj.parentObj, id_bhvBowser) ~= 0) then
			if (obj.parentObj.oAction == 3 and obj.parentObj.header.gfx.animInfo.animFrame < 35) then
				obj.parentObj.header.gfx.animInfo.animFrame = 35
			end
		end
		for key, hit_effect in pairs(PossibleBusterTargets) do
			local foundTarget = cur_obj_nearest_object_with_behavior(get_behavior_from_id(key))
			if foundTarget ~= nil and foundTarget ~= obj.parentObj and not (key == id_bhvMario and foundTarget.globalPlayerIndex == obj.globalPlayerIndex) then
				local dist = dist_between_objects(obj, foundTarget)
				if dist < targetDistance then
					targetDistance = dist
					busterTarget = foundTarget
				end
				if obj_check_hitbox_overlap(obj, foundTarget) then
					if (obj_has_behavior_id(foundTarget, id_bhvBowser) == 0) then
						audio_sample_play(SOUND_BUSTERHIT, {x = obj.oPosX, y = obj.oPosY, z = obj.oPosZ}, 1.0)
					end
					hit_effect(obj, foundTarget)
					obj.oTimer = 50
					playerTP[obj.oUnk1A8] = math.min(playerTP[obj.oUnk1A8] + 4, 100)
				end
			end
		end

		if busterTarget ~= nil and targetDistance < 800 then
			local yaw = approach_s16_symmetric(obj.oFaceAngleYaw, obj_angle_to_object(obj, busterTarget), 0x230)
			obj.oFaceAngleYaw = yaw
			obj.oMoveAngleYaw = yaw

			obj.oPosY = approach_f32(obj.oPosY, busterTarget.oPosY, 16, 0.0)
		end

		-- gfx
		obj.oAnimState = obj.oAnimState + 1
		local scale = math.min(obj.oTimer * 0.5, 2.0)
		obj.header.gfx.scale.x = scale
		obj.header.gfx.scale.y = scale
		obj.header.gfx.scale.z = scale
		obj.oGraphYOffset = math.min(85, obj.oTimer * 5 + 25)

		if obj.oTimer >= 50 or step & (OBJ_COL_FLAG_HIT_WALL | OBJ_COL_FLAG_UNDERWATER) ~= 0 then
			spawn_mist_particles_with_sound(SOUND_OBJ_DEFAULT_DEATH)
			obj_mark_for_deletion(obj)
			return
		end
		-- particle
		if obj.oTimer >= 5 and obj.oTimer % 2 == 0 then
			local particleObj = spawn_sync_object(
			id_bhvGersonBustereffect,
			E_MODEL_BUSTEREFFECT,
			obj.oPosX, obj.oPosY, obj.oPosZ,
			function(effectObj)
				effectObj.oFaceAngleYaw = obj.oFaceAngleYaw
				effectObj.oGraphYOffset = obj.oGraphYOffset
				effectObj.globalPlayerIndex = obj.globalPlayerIndex
			end
		   )
    end
   end
end


local function bhv_gersonbustereffect_loop(obj)
   if (obj.oOpacity >= 1) then
	obj.oOpacity = math.max(obj.oOpacity - 20, 0)
	obj.header.gfx.scale.x = math.max(obj.header.gfx.scale.x - 0.15, 0.1)
   elseif (obj.oOpacity <= 0) then
	obj_mark_for_deletion(obj)
   end
end

id_bhvGersonBustereffect = hook_behavior(nil, OBJ_LIST_UNIMPORTANT, true, bhv_gersonbustereffect_init, bhv_gersonbustereffect_loop, "gersonbustereffect")
id_bhvGersonBox = hook_behavior(nil, OBJ_LIST_DESTRUCTIVE, false, bhv_custom_box_init, bhv_custom_box_loop, "bhvGersonBox")
id_bhvGersonBox2 = hook_behavior(nil, OBJ_LIST_DESTRUCTIVE, false, bhv_custom_box2_init, bhv_custom_box_loop, "bhvGersonBox2")
_G.id_bhvGersonBuster = hook_behavior(nil, OBJ_LIST_GENACTOR, true, bhv_gersonbuster_init, bhv_gersonbuster_loop, "gersonbuster")