-- name: [CS] Gerson Boom [+ Moveset!]
-- description: I'm old!

if not _G.charSelectExists then return end

_G.E_MODEL_BUSTERMOVE =      smlua_model_util_get_id("gbuster_geo")      -- Located in "actors"
SOUND_NOTP = audio_sample_load('noTP.ogg')

gGlobalSyncTable.TPregen = mod_storage_load_bool("TPregen")
gGlobalSyncTable.JBchallenge = mod_storage_load_bool("JBchallenge")
sanctuaryskybox = mod_storage_load_bool("sanctuaryskybox")

_G.DRMoveset = {
    isActive = true,
    FLAG_TP_BAR = (1 << 0), -- enables the TP bar
    FLAG_RUDEBUSTER = (1 << 1), -- enables the rude buster
}

gPlayerSyncTable[0].DRstate = 0

local gDRFlagsTable = {}
local gDRCostumeTable = {}

local function checkDRflags(m, flags)
    return (_G.charSelect.get_options_status(6) ~= 0 and (gPlayerSyncTable[m.playerIndex].DRstate & flags ~= 0))
end

local function tableContains(table, key)
	for i=1,#table do
		if (table[i] == key) then
			return true
		end
	end
	return false
end

local function apply_DR_flags()
    local flags = gDRFlagsTable[_G.charSelect.character_get_current_table().model]
    local model = _G.charSelect.character_get_current_table().model
    local costume = _G.charSelect.character_get_current_costume()
    if flags and (tableContains(gDRCostumeTable[_G.charSelect.character_get_current_table().model],costume)) then
        gPlayerSyncTable[0].DRstate = flags
    else
        gPlayerSyncTable[0].DRstate = 0
    end
end

local function setDRCharacterFlags(characterModelID, costumeID, flags)
    if characterModelID == nil then return end
    if costumeID == nil then return end
    gDRFlagsTable[characterModelID] = flags
    gDRCostumeTable[characterModelID] = costumeID
end

local function categories()
local chartable = _G.charSelect.character_get_full_table()
for i = 0, #chartable,1 do
	if chartable[i] ~= nil then
		if gDRFlagsTable[chartable[i][1].model] ~= nil then
			_G.charSelect.character_set_category(i, "Deltarune Moveset")
			end
		end
	end
end
hook_event(HOOK_ON_LEVEL_INIT,categories)

_G.DRMoveset.setDRCharacterFlags = setDRCharacterFlags

---------------------- VARIABLES -----------------------
playerTP = {}
playerTempTP = {}
for i = 0, (MAX_PLAYERS - 1) do
	playerTP[i] = 100
	playerTempTP[i] = 100
end

local gersonMeterTex = get_texture_info('gerson_tp_meter.rgba16')

----------------------------- TP ------------------------------

function TP_on_hud_render()
    if checkDRflags(gMarioStates[0], DRMoveset.FLAG_TP_BAR) then
	djui_hud_set_resolution(RESOLUTION_N64)
	djui_hud_set_filter(FILTER_NEAREST)
	djui_hud_set_color(0, 0, 0, 255)
	djui_hud_render_texture(gersonMeterTex, -1, 41, 1, 1)
	djui_hud_set_color(128, 0, 0, 255)
	djui_hud_render_rect(27, 42, 11, 100)
	if (playerTP[0] > playerTempTP[0]) then
		djui_hud_set_color(255, 255, 255, 255)
		djui_hud_render_rect(27, 142 - playerTP[0], 11, playerTP[0])
		djui_hud_set_color(255, 159, 64, 255)
		djui_hud_render_rect(27, 142 - playerTempTP[0], 11, playerTempTP[0])
	elseif (playerTP[0] < playerTempTP[0]) then
		djui_hud_set_color(255, 0, 0, 255)
		djui_hud_render_rect(27, 142 - playerTempTP[0], 11, playerTempTP[0])
		djui_hud_set_color(255, 159, 64, 255)
		djui_hud_render_rect(27, 142 - playerTP[0], 11, playerTP[0])
	else
		if (playerTempTP[0] < 100) then
			djui_hud_set_color(255, 159, 64, 255)
		else
			djui_hud_set_color(255, 208, 35, 255)
		end
		djui_hud_render_rect(27, 142 - playerTP[0], 11, playerTP[0])
	end
	djui_hud_set_color(255, 255, 255, 255)
	if (playerTempTP[0] < 100) then
		djui_hud_render_rect(27, 142 - playerTempTP[0], 11, 1)
	end
	djui_hud_render_texture(gersonMeterTex, 0, 40, 1, 1)
	djui_hud_set_font(FONT_SPECIAL)
	local gersonMsg = "MAX"
	if (playerTempTP[0] < 100) then
		gersonMsg = tostring(playerTempTP[0])
		djui_hud_set_color(0, 0, 0, 255)
		djui_hud_print_text("%", 6, 97, 1.0)
		djui_hud_print_text(gersonMsg, 14 * 10.5/djui_hud_measure_text(gersonMsg), 82, 0.6)
		djui_hud_set_color(255, 255, 255, 255)
		djui_hud_print_text("%", 7, 96, 1.0)
		djui_hud_print_text(gersonMsg, 16 * 10.5/djui_hud_measure_text(gersonMsg), 81, 0.6)
	else
		djui_hud_set_color(0, 0, 0, 255)
		djui_hud_print_text(gersonMsg, 0, 82, 0.5)
		djui_hud_set_color(255, 255, 0, 255)
		djui_hud_print_text(gersonMsg, 1, 81, 0.5)
	end
   end	
end

hook_event(HOOK_ON_HUD_RENDER_BEHIND, TP_on_hud_render)

local function TP_on_warp(warpType, levelNum, areaIdx, nodeId, arg)
	if (warpType ~= WARP_TYPE_SAME_AREA and warpType ~= WARP_TYPE_CHANGE_AREA) then
		playerTP[0] = 100
		playerTempTP[0] = 100
	end
end

hook_event(HOOK_ON_WARP, TP_on_warp)



function TP_on_interact(m, obj, interactType, interactBool)
    if checkDRflags(gMarioStates[0], DRMoveset.FLAG_TP_BAR) then
		if (obj_has_behavior_id(obj, id_bhvGersonBuster) ~= 0 and obj_has_behavior_id(obj.parentObj, id_bhvBowser) ~= 0 and obj.oBehParams > 2) then
			obj.parentObj.oAction = 8
			play_sound(SOUND_MENU_BOWSER_LAUGH, obj.parentObj.header.gfx.cameraToObject)
		end
		if (interactType == INTERACT_COIN) then
			playerTP[m.playerIndex] = math.min(playerTP[m.playerIndex] + 2*obj.oDamageOrCoinValue, 100)
		elseif (interactType == INTERACT_STAR_OR_KEY) then
			playerTP[m.playerIndex] = 100
		end
	end	
end

local function TP_on_attack_object(m, obj, id)
    if checkDRflags(gMarioStates[0], DRMoveset.FLAG_TP_BAR) then
		if (obj_is_bully(obj) == false and obj_has_behavior_id(obj, id_bhvKoopaShell) == 0 and (obj.oDeathSound ~= SOUND_OBJ_ENEMY_DEATH_LOW or obj_has_behavior_id(obj, id_bhvGoomba) == 0 or id == INT_HIT_FROM_ABOVE or id == INT_GROUND_POUND)) then
			playerTP[m.playerIndex] = math.min(playerTP[m.playerIndex] + 7, 100)
		end
	end
end

hook_event(HOOK_ON_ATTACK_OBJECT, TP_on_attack_object)
hook_event(HOOK_ON_INTERACT, TP_on_interact)

local function on_update(m)

    if (playerTP[m.playerIndex] < 100 and gGlobalSyncTable.TPregen) then
	       playerTP[m.playerIndex] = math.min(playerTP[m.playerIndex] + 1, 100)
    end

	if (playerTempTP[m.playerIndex] < playerTP[m.playerIndex]) then
		playerTempTP[m.playerIndex] = playerTempTP[m.playerIndex] + 1
	elseif (playerTempTP[m.playerIndex] > playerTP[m.playerIndex]) then
		if (playerTempTP[m.playerIndex] - playerTP[m.playerIndex] > 15) then
			playerTempTP[m.playerIndex] = playerTempTP[m.playerIndex] - 5
		else
			playerTempTP[m.playerIndex] = playerTempTP[m.playerIndex] - 1
		end
	end
	if m.heldObj and (obj_has_behavior_id(m.heldObj, id_bhvBowser)) and (math.abs(m.angleVel.y) >= 4096) and (get_global_timer() % 3 == 0) then
		playerTP[m.playerIndex] = math.min(playerTP[m.playerIndex] + 1,100)
	end
end
hook_event(HOOK_MARIO_UPDATE, on_update)


local function apply_tp_cost(m,cost)
	if checkDRflags(gMarioStates[0], DRMoveset.FLAG_TP_BAR) ~= true then return end
	if (playerTP[m.playerIndex] >= cost) then
	playerTP[m.playerIndex] = math.max(playerTP[m.playerIndex] - cost,0)
	return true
	elseif (m.playerIndex == 0) then
	audio_sample_play(SOUND_NOTP, m.pos, 1.5)
	end
return false
end
_G.DRMoveset.apply_tp_cost = apply_tp_cost

----------------------------- BUSTER ------------------------------


function player_allow_interact(m, obj, interactType)
    if (checkDRflags(gMarioStates[0], DRMoveset.FLAG_RUDEBUSTER)) then
		if (obj_has_behavior_id(obj, id_bhvGersonBuster) ~= 0) then
			if (obj_has_behavior_id(obj.parentObj, id_bhvBowser) ~= 0 and m.flags & MARIO_PUNCHING ~= 0) then
				audio_sample_play(SOUND_BOWSERREFLECT, {x = obj.oPosX, y = obj.oPosY, z = obj.oPosZ}, 0.4)
				local busterObj = spawn_sync_object(
						id_bhvGersonBuster,
						E_MODEL_BUSTERMOVE,
						obj.oPosX + obj.oVelX, obj.oPosY + obj.oVelY, obj.oPosZ + obj.oVelZ,
						function(busterObj)
							busterObj.oFaceAngleYaw = m.faceAngle.y
							busterObj.oBehParams = obj.oBehParams + 1
							busterObj.oForwardVel = 10 * obj.oBehParams
							busterObj.globalPlayerIndex = network_global_index_from_local(m.playerIndex)
							busterObj.oUnk1A8 = m.playerIndex
							busterObj.parentObj = m.marioObj
						end
				)
				obj_mark_for_deletion(obj)
				return false
			elseif (obj.parentObj == m.marioObj) then
				return false
			end
		end
	end	
end

hook_event(HOOK_ALLOW_INTERACT, player_allow_interact)

local function player_on_set_action(m)
    if (m.action == ACT_PUNCHING and m.actionArg == 9) and (checkDRflags(gMarioStates[0], DRMoveset.FLAG_RUDEBUSTER)) then
		if ((playerTP[m.playerIndex] >= 33) or checkDRflags(gMarioStates[0], DRMoveset.FLAG_TP_BAR) ~= true) and m.playerIndex == 0 then
		        smlua_anim_util_set_animation(m.marioObj, "gerson_buster")
			playerTP[m.playerIndex] = math.max(playerTP[m.playerIndex] - 33,0)
			local busterObj = spawn_sync_object(
					id_bhvGersonBuster,
					E_MODEL_BUSTERMOVE,
					m.pos.x + 160*sins(m.faceAngle.y), m.pos.y, m.pos.z + 160*coss(m.faceAngle.y),
					function(busterObj)
						busterObj.oFaceAngleYaw = m.faceAngle.y
						busterObj.oBehParams = 1
						busterObj.oForwardVel = 10
						busterObj.globalPlayerIndex = network_global_index_from_local(m.playerIndex)
						busterObj.oUnk1A8 = m.playerIndex
					end
			)
		elseif (m.playerIndex == 0) then
			audio_sample_play(SOUND_NOTP, m.pos, 1.75)
		end
	end
end
hook_event(HOOK_ON_SET_MARIO_ACTION, player_on_set_action)

----------------------------- APPLY FLAGS ------------------------------

local function before_set_action(m, nextAction)
    if m.playerIndex ~= 0 then return end
    apply_DR_flags()
end
hook_event(HOOK_BEFORE_SET_MARIO_ACTION, before_set_action)

----------------------------- MENU OPTIONS ------------------------------

local function TPregentoggle(index, value)
    if network_is_server()then
      gGlobalSyncTable.TPregen = value
      mod_storage_save_bool("TPregen", value)
    end
    if value then
	   djui_chat_message_create("\\#fff200\\TP regen \\#ffffff\\has been turned \\#00ff00\\on.")
        elseif value == false then
	   djui_chat_message_create("\\#fff200\\TP regen \\#ffffff\\has been turned \\#ff0000\\off.")
    end
end

local function JBchallengetoggle(index, value)
    if network_is_server() then
       gGlobalSyncTable.JBchallenge = value
       mod_storage_save_bool("JBchallenge", value)
   end
   if value then
	  djui_chat_message_create("\\#fff200\\Delta warrior Challenge \\#ffffff\\has been turned \\#00ff00\\on.")
       elseif value == false then
	  djui_chat_message_create("\\#fff200\\Delta warrior Challenge \\#ffffff\\has been turned \\#ff0000\\off.")
   end
end

local function skyboxToggle(index, value)
    	sanctuaryskybox = value
	mod_storage_save_bool("sanctuaryskybox", value)
end

local function removebombs()
	if gGlobalSyncTable.JBchallenge then
		local bombBHV = get_behavior_from_id(id_bhvBowserBomb)
		local bombObj = find_object_with_behavior(bombBHV)
		for i=0, count_objects_with_behavior(bombBHV), 1 do
			if (bombObj ~= nil) then
			    obj_mark_for_deletion(bombObj)
			end
			bombObj = obj_get_next_with_same_behavior_id(bombObj)
		end
	end
end
hook_event(HOOK_ON_LEVEL_INIT, removebombs)

if network_is_server() then
    hook_mod_menu_checkbox("[HOST] Regenerate TP", mod_storage_load_bool("TPregen"), TPregentoggle)
    hook_mod_menu_checkbox("[HOST] Delta warrior challenge", mod_storage_load_bool("JBchallenge"), JBchallengetoggle)
    hook_mod_menu_text("Makes the Justice Buster counter mandatory to defeat Bowser.")
end

hook_mod_menu_checkbox("Bowser Sanctuary Skyboxes", mod_storage_load_bool("sanctuaryskybox"), skyboxToggle)