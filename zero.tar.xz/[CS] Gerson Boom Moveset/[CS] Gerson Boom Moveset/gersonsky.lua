if not _G.charSelectExists then return end

E_MODEL_SKY1 = smlua_model_util_get_id("sky1_geo")
E_MODEL_SKY2 = smlua_model_util_get_id("sky2_geo")
E_MODEL_SKY3 = smlua_model_util_get_id("sky3_geo")

local l = gLakituState
local c = gCamera

function bhv_skybox_init(o)
    o.oFlags = OBJ_FLAG_UPDATE_GFX_POS_AND_ANGLE
    o.header.gfx.skipInViewCheck = true
    obj_scale(o, 10.0)
end

function bhv_skybox_loop(o)
    o.oPosX = l.pos.x
    o.oPosY = l.pos.y
    o.oPosZ = l.pos.z
end

id_bhv3DSkybox = hook_behavior(bhv3DSkybox, OBJ_LIST_LEVEL, false, bhv_skybox_init, bhv_skybox_loop)

function SpawnSkybox()
    if sanctuaryskybox ~= true then return end
    local skyboxcheck = obj_get_nearest_object_with_behavior_id(o, id_bhv3DSkybox)
    local p = gNetworkPlayers[0]
    if skyboxcheck == nil and p.currLevelNum == LEVEL_BITDW then
        spawn_non_sync_object(id_bhv3DSkybox, E_MODEL_SKY1, l.pos.x, l.pos.y, l.pos.z, nil)
    elseif skyboxcheck == nil and p.currLevelNum == LEVEL_BITFS then
	spawn_non_sync_object(id_bhv3DSkybox, E_MODEL_SKY2, l.pos.x, l.pos.y, l.pos.z, nil)
    elseif skyboxcheck == nil and p.currLevelNum == LEVEL_BITS then
	spawn_non_sync_object(id_bhv3DSkybox, E_MODEL_SKY3, l.pos.x, l.pos.y, l.pos.z, nil)
    end
end

hook_event(HOOK_ON_LEVEL_INIT, SpawnSkybox)
