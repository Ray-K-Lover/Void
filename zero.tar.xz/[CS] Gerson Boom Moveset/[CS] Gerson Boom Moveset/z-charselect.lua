-- Replace Mod Name with your Character/Pack name.
local TEXT_MOD_NAME = "[CS] Gerson Boom"

-- Stops mod from loading if Character Select isn't on, Does not need to be touched
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_GERSON =      smlua_model_util_get_id("gerson_geo")      -- Located in "actors"
local E_MODEL_HOJ =      smlua_model_util_get_id("hoj_geo")      -- Located in "actors"
local SOUND_GJUMP = audio_sample_load('snd_jump.ogg')
local TEX_GERSON_LIFE_ICON = get_texture_info("gersonlifeicon") -- Located in "textures"

local VOICETABLE_GERSON = {
    [CHAR_SOUND_OKEY_DOKEY] =        'gerson-laugh.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] =         'gerson-laugh.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] =         'gersongya.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] =         {'gersonhah.ogg','gersonow.ogg'}, -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] =         {'gersonah.ogg','gersonaww.ogg'}, -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] =       'gersongya.ogg', -- First Jump Sounds
	[CHAR_SOUND_HOOHOO] =            'gersonhah.ogg', -- Second jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'gersongya.ogg','gersonhah.ogg','gersonwahoo.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] =                'gersonaww.ogg', -- Wall bonk
	--[CHAR_SOUND_UH2] =               '', -  - Landing after long jump
	--[CHAR_SOUND_UH2_2] =             '',
	--[CHAR_SOUND_HAHA] =              '', -- Landing triple jump
	[CHAR_SOUND_HAHA_2] =              'gersonhah.ogg', -- Landing in water after long fall
	[CHAR_SOUND_YAHOO] =             {'gerson-laugh.ogg','gersonwahoo.ogg','snd_jump.ogg','snd_jump.ogg'}, -- Long jump
	[CHAR_SOUND_DOH] =               'gersonaww.ogg', -- Long jump wall bonk
	[CHAR_SOUND_WHOA] =              'gersontalk.ogg', -- Grabbing ledge
	--[CHAR_SOUND_EEUH] =              '', -- Climbing over ledge
	--[CHAR_SOUND_WAAAOOOW] =          '', -- Falling a long distance
	--[CHAR_SOUND_TWIRL_BOUNCE] =      '', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] =  'gersontalk.ogg', 
	[CHAR_SOUND_HRMM] =              'gersontalk.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] =        'gerson-laugh.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] =   'gerson-laugh.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] =          'snd_hurt1.ogg', -- Damaged
	[CHAR_SOUND_OOOF] = 'gersonaww.ogg', -- Grabbed
	[CHAR_SOUND_OOOF2] = 'gersongrunt.ogg', -- Landing during knockback
	[CHAR_SOUND_PANTING] =           'gersontalk.ogg', -- Low health
	[CHAR_SOUND_PANTING_COLD] = 'gersontalk.ogg', -- Exhaling while shivering
	--[CHAR_SOUND_ON_FIRE] =           '', -- Burned
--SLEEP SOUNDS
	--[CHAR_SOUND_IMA_TIRED] =         '', -- Mario feeling tired
	--[CHAR_SOUND_YAWNING] =           '', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] =          'gersontalk.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] =          'gersontalk.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] =          'gersontalk.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] =         'gersontalk.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] =         'gersontalk.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] =         'gersontalk.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] =             'gersongrunt.ogg', -- Dying from damage
	--[CHAR_SOUND_DROWNING] =          '', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] =          'gersongrunt.ogg' -- Booted out of level
}

local VOICETABLE_GERSONVA = {
    [CHAR_SOUND_OKEY_DOKEY] =        'GVA_imold.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] =         'GVA_imold.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] =         {'GVA_yah.ogg','GVA_wah.ogg','GVA_hoh.ogg'}, -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] =         {'GVA_attack2A.ogg','GVA_attack2B.ogg','GVA_attack2C.ogg'}, -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] =         'GVA_hoo.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] =       {'GVA_yah.ogg','GVA_wah.ogg','GVA_hoh.ogg'}, -- First Jump Sounds
	[CHAR_SOUND_HOOHOO] =            'GVA_2ndjump.ogg', -- Second jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'GVA_triplejump1.ogg','GVA_triplejump2.ogg','GVA_haha1.ogg','GVA_haha2.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] =                {'GVA_bonk1.ogg','GVA_bonk2.ogg'}, -- Wall bonk
	--[CHAR_SOUND_UH2] =               '', -  - Landing after long jump
	--[CHAR_SOUND_UH2_2] =             '',
	[CHAR_SOUND_HAHA] =              {'GVA_landing1.ogg','GVA_landing2.ogg','GVA_landing3.ogg','GVA_landing4.ogg'}, -- Landing triple jump
	[CHAR_SOUND_HAHA_2] =            {'GVA_waterland1.ogg','GVA_waterland2.ogg','GVA_waterland3.ogg'}, -- Landing in water after long fall
	[CHAR_SOUND_YAHOO] =             {'GVA_lj1.ogg','GVA_lj2.ogg','GVA_lj3.ogg','GVA_lj4.ogg','GVA_lj5.ogg'}, -- Long jump
	[CHAR_SOUND_DOH] =               {'GVA_bonk1.ogg','GVA_bonk2.ogg'}, -- Long jump wall bonk
	[CHAR_SOUND_WHOA] =              {'GVA_woah1.ogg','GVA_woah2.ogg'}, -- Grabbing ledge
	[CHAR_SOUND_EEUH] =              {'GVA_lift1.ogg','GVA_lift2.ogg','GVA_lift3.ogg'}, -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] =          {'GVA_fall1.ogg','GVA_fall2.ogg','GVA_fall3.ogg','GVA_fall4.ogg','GVA_fall5.ogg'}, -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] =      {'GVA_haha1.ogg','GVA_haha2.ogg'}, -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] =  {'GVA_attack2A.ogg','GVA_attack2B.ogg','GVA_attack2C.ogg'}, 
	[CHAR_SOUND_HRMM] =              {'GVA_lift2.ogg','GVA_lift3.ogg'}, -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] =        {'gerson-laugh.ogg','GVA_imold.ogg'}, -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] =   'gerson-laugh.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] =          {'GVA_hurt1.ogg','GVA_hurt2.ogg','GVA_hurt3.ogg'}, -- Damaged
	[CHAR_SOUND_OOOF] =              {'GVA_oof1.ogg','GVA_bonk1.ogg','GVA_woah1.ogg'}, -- Grabbed
	[CHAR_SOUND_OOOF2] =             {'GVA_oof1.ogg','GVA_oof2.ogg','GVA_oof3.ogg'}, -- Landing during knockback
	[CHAR_SOUND_PANTING] =           {'GVA_lh1.ogg','GVA_lh2.ogg','GVA_lh3.ogg','GVA_lh4.ogg'}, -- Low health
	[CHAR_SOUND_PANTING_COLD] =      {'GVA_cold1.ogg','GVA_cold2.ogg','GVA_cold3.ogg'}, -- Exhaling while shivering
	[CHAR_SOUND_ON_FIRE] =           {'GVA_fire1.ogg','GVA_fire2.ogg'}, -- Burned
--SLEEP SOUNDS
	--[CHAR_SOUND_IMA_TIRED] =         '', -- Mario feeling tired
	--[CHAR_SOUND_YAWNING] =           '', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] =          'gersontalk.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] =          'gersontalk.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] =          'gersontalk.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] =         'gersontalk.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] =         'gersontalk.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] =         'gersontalk.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] =             'GVA_cold3.ogg', -- Dying from damage
	--[CHAR_SOUND_DROWNING] =          '', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] =          'gersongrunt.ogg' -- Booted out of level
}

local ANIMTABLE_GERSON = {
	[CHAR_ANIM_BREAKDANCE]     = 'gerson_buster',
	--[CHAR_ANIM_GROUND_POUND_LANDING]     = 'gerson_swing',
}

local CAPTABLE_GERSON = {
    normal = smlua_model_util_get_id("gersoncap_geo"),
    wing = smlua_model_util_get_id("gersonwingcap_geo"),
    metal = smlua_model_util_get_id("gersonmetalcap_geo"),
    metalWing = smlua_model_util_get_id("gersonmetalwingcap_geo")
}

local HM_GERSON = {
    label = {
        left = get_texture_info("GersonHPRight"),
        right = get_texture_info("GersonHPLeft"),
    },
    pie = {
        [1] = get_texture_info("GersonHp8"),
        [2] = get_texture_info("GersonHp7"),
        [3] = get_texture_info("GersonHp6"),
        [4] = get_texture_info("GersonHp5"),
        [5] = get_texture_info("GersonHp4"),
        [6] = get_texture_info("GersonHp3"),
        [7] = get_texture_info("GersonHp2"),
        [8] = get_texture_info("GersonHp1"),
    }
}

local PALETTE_GERSON = {
    [PANTS]  = "684433",
    [SHIRT]  = "C15F25",
    [GLOVES] = "FFFFFF",
    [SHOES]  = "2A6763",
    [HAIR]   = "F970F0",
    [SKIN]   = "64AA25",
    [CAP]    = "873C2C",
	[EMBLEM] = "9AFC4D"
}

local CSloaded = false
local function on_character_select_load()
    -- Adds the custom character to the Character Select Menu
    CT_GERSON = _G.charSelect.character_add(
        "Gerson Boom", -- Character Name
        "He's old!", -- Description
        "SwagSkeleton95, StarWarrior64", -- Credits
        "64a925",           -- Menu Color
        E_MODEL_GERSON,       -- Character Model
        CT_MARIO,           -- Override Character
        TEX_GERSON_LIFE_ICON, -- Life Icon
        1                  -- Camera Scale
    )
    CT_HOJ = _G.charSelect.character_add_costume(
        CT_GERSON,
        "Hammer of Justice", -- Character Name
        {"He's old!","","","B during a ground pound to hammer spin","","Jump after a groundpound/Hammer spin","to do a triple jump","","Hold Z during a dive slide to roll","","Crouch punch to unleash a Justice Buster!"}, -- Description
        "SwagSkeleton95, StarWarrior64, Baconator2558, Kaktus64", -- Credits
        "ffffff",           -- Menu Color
        E_MODEL_HOJ,       -- Character Model
        CT_MARIO,           -- Override Character
        TEX_GERSON_LIFE_ICON, -- Life Icon
        1                  -- Camera Scale
    )

    -- Adds credits to the credits menu
    _G.charSelect.credit_add(TEXT_MOD_NAME, "SwagSkeleton95", "Model")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "SwagSkeleton95", "Object Coding")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "Baconator2558", "Object Coding")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "Baconator2558", "TP Bar Coding")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "Baconator2558", "Moveset Coding")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "Kaktus64", "Moveset Coding")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "Kaktus64", "HUD Element Sprites")
    _G.charSelect.credit_add(TEXT_MOD_NAME, "StarWarrior64", "Voice Acting")
    if mod_storage_load_bool("gersonvoice") then
		_G.charSelect.character_add_voice(E_MODEL_GERSON, VOICETABLE_GERSON)
		_G.charSelect.character_add_voice(E_MODEL_HOJ, VOICETABLE_GERSON)
        else
		_G.charSelect.character_add_voice(E_MODEL_GERSON, VOICETABLE_GERSONVA)
		_G.charSelect.character_add_voice(E_MODEL_HOJ, VOICETABLE_GERSONVA)
    end
    _G.charSelect.character_add_caps(E_MODEL_GERSON, CAPTABLE_GERSON)
    _G.charSelect.character_add_health_meter(CT_GERSON, HM_GERSON)
    _G.charSelect.character_add_costume_health_meter(CT_GERSON, 2, HM_GERSON)
    _G.charSelect.character_add_caps(E_MODEL_HOJ, CAPTABLE_GERSON)
    _G.charSelect.character_add_palette_preset(E_MODEL_GERSON, PALETTE_GERSON)
    _G.charSelect.character_add_palette_preset(E_MODEL_HOJ, PALETTE_GERSON)
	_G.charSelect.character_add_animations(E_MODEL_HOJ, ANIMTABLE_GERSON)

	---- BOWSER MOVESET:
if _G.bowsMoveset then
    -- Retrieves the custom shell model for this character. Check template_shell.blend for how to set up a shell model properly.
    local E_MODEL_GERSON_SHELL = smlua_model_util_get_id("gersonshell_geo")
    local BOWS_FLAGS_GERSON = _G.bowsMoveset.FLAG_CAN_USE_SHELL
    _G.bowsMoveset.character_add_shell_model(E_MODEL_GERSON, E_MODEL_GERSON_SHELL, 'deltaburst.ogg')
    _G.bowsMoveset.character_set_bows_flags(E_MODEL_GERSON, BOWS_FLAGS_GERSON)
end
----

	---- DR MOVESET:
if _G.DRMoveset then
    local DR_FLAGS_GERSON = _G.DRMoveset.FLAG_TP_BAR | _G.DRMoveset.FLAG_RUDEBUSTER
    _G.DRMoveset.setDRCharacterFlags(E_MODEL_GERSON, {2}, DR_FLAGS_GERSON)
end
----

    CSloaded = true
end

_G.charSelect.config_character_sounds()

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)

---------------------- LOCAL VARIABLES -----------------------
local gersonHammerCount = {}
for i = 0, (MAX_PLAYERS - 1) do
	gersonHammerCount[i] = 2
end

local gStateExtras = {} --kak
for i = 0, MAX_PLAYERS - 1 do
    gStateExtras[i] = {}
    local m = gMarioStates[i]
    local e = gStateExtras[i]
    e.rotAngle = 0
end

------------------------- SHELL MOVE -------------------------


-- find_floor_height(m.pos.x + 260*sins(m.faceAngle.y), m.pos.y + 40, m.pos.z + 260*coss(m.faceAngle.y))

function gerson_before_set_action(m, nextAct, actionArg)
    if _G.charSelect.character_get_current_costume() ~= 2 then return end
    if (m.action == ACT_GROUND_POUND_LAND and m.prevAction == ACT_GERSON_HAMMER_SPIN) then
		m.marioObj.hitboxRadius = 37.0
		if nextAct == ACT_BUTT_SLIDE_STOP then
        	return ACT_IDLE
		end
    end
end

function gerson_on_set_action(m)
    if _G.charSelect.character_get_current_costume() ~= 2 then return end
	if (m.action & ACT_FLAG_AIR == 0 and m.action & ACT_GROUP_MASK ~= ACT_GROUP_AIRBORNE and m.pos.y - m.floorHeight >= 0) then
		gersonHammerCount[m.playerIndex] = 2
	end
    if (m.action == ACT_GROUND_POUND_LAND and m.prevAction ~= ACT_GERSON_HAMMER_SPIN) then
		if (playerTP[m.playerIndex] >= 1) and m.playerIndex == 0 then
			playerTP[m.playerIndex] = playerTP[m.playerIndex] - 1
			local shellObj2 = spawn_sync_object(
					id_bhvGersonBox2,
					E_MODEL_KOOPA_SHELL,
					m.pos.x + 140*sins(m.faceAngle.y + 0x4000), m.pos.y, m.pos.z + 140*coss(m.faceAngle.y + 0x4000),
					function(shellObj2)
						shellObj2.oFaceAngleYaw = m.faceAngle.y + 0x4000
				shellObj2.oMoveAngleYaw = m.faceAngle.y + 0x4000
				shellObj2.oVelY = 5
						shellObj2.oForwardVel = 40
					end
			)
			local shellObj3 = spawn_sync_object(
					id_bhvGersonBox2,
					E_MODEL_KOOPA_SHELL,
					m.pos.x + 140*sins(m.faceAngle.y - 0x4000), m.pos.y, m.pos.z + 140*coss(m.faceAngle.y - 0x4000),
					function(shellObj3)
						shellObj3.oFaceAngleYaw = m.faceAngle.y - 0x4000
				shellObj3.oMoveAngleYaw = m.faceAngle.y - 0x4000
				shellObj3.oVelY = 5
						shellObj3.oForwardVel = 40
					end
			)
		elseif (m.playerIndex == 0) then
			audio_sample_play(SOUND_NOTP, m.pos, 1.5)
		end
    end
    --Hammer Particles
    if m.action == ACT_GROUND_POUND_LAND and m.prevAction == ACT_GERSON_HAMMER_SPIN then
		smlua_anim_util_set_animation(m.marioObj, "gerson_swing")
        --set_mario_particle_flags(m, PARTICLE_HORIZONTAL_STAR, 0)
	spawn_non_sync_object(id_bhvHorStarParticleSpawner, E_MODEL_NONE, m.pos.x + 190*sins(m.faceAngle.y), m.pos.y, m.pos.z + 190*coss(m.faceAngle.y), nil)
        --set_mario_particle_flags(m, PARTICLE_MIST_CIRCLE, 0)
spawn_non_sync_object(id_bhvMistCircParticleSpawner, E_MODEL_NONE, m.pos.x + 190*sins(m.faceAngle.y), m.pos.y, m.pos.z + 190*coss(m.faceAngle.y), nil)
        play_sound(SOUND_ACTION_METAL_HEAVY_LANDING, m.marioObj.header.gfx.cameraToObject)
    end
    if m.action == ACT_GERSON_HAMMER_SPIN then
        play_sound(SOUND_ACTION_METAL_STEP, m.marioObj.header.gfx.cameraToObject)
        set_mario_particle_flags(m, PARTICLE_MIST_CIRCLE, 0)
        play_character_sound(m, CHAR_SOUND_HOOHOO)
    end
end

------------------------- HAMMER MOVE -------------------------

local function limit_angle(a)
    return (a + 0x8000) % 0x10000 - 0x8000
end

ACT_GERSON_HAMMER_SPIN = allocate_mario_action(ACT_GROUP_AIRBORNE | ACT_FLAG_AIR | ACT_FLAG_ATTACKING)

function act_gerson_hammer_spin(m)
    local stepResult = common_air_action_step(m, ACT_GROUND_POUND_LAND, CHAR_ANIM_FORWARD_SPINNING, AIR_STEP_NONE)
    m.marioObj.hitboxRadius = 47.0 -- hitbox size
    m.faceAngle.y = m.intendedYaw - approach_s32(limit_angle(m.intendedYaw - m.faceAngle.y), 0, 0x75, 0x75) -- you cant move freely, but can still strafe
    m.peakHeight = m.pos.y -- Removes fall damage, remove if you want it back
    if m.actionTimer == 0 then -- the little bounce at the start
        m.forwardVel = 45
        m.vel.y = 50
    end
    if m.forwardVel > 75 then -- speed cap
        m.forwardVel = m.forwardVel - 1
    end
    
    m.actionTimer = m.actionTimer + 1
end
hook_mario_action(ACT_GERSON_HAMMER_SPIN, act_gerson_hammer_spin, INT_GROUND_POUND)



ACT_GERSON_ROLL = allocate_mario_action(ACT_GROUP_MOVING | ACT_FLAG_ATTACKING | ACT_FLAG_MOVING) --kak

function act_gerson_roll(m) --kak
    local e = gStateExtras[m.playerIndex]
    local stepResult = perform_ground_step(m)
    m.faceAngle.y = m.intendedYaw - approach_s32(limit_angle(m.intendedYaw - m.faceAngle.y), 0, 0x250, 0x250) -- you cant move freely, but can still strafe
    m.marioBodyState.handState = MARIO_HAND_RIGHT_OPEN -- set this to whatever handstate the hammer state is (if it even is a handstate)
    set_mario_animation(m, MARIO_ANIM_FORWARD_SPINNING)
    apply_slope_accel(m)
    if stepResult == GROUND_STEP_LEFT_GROUND then
        set_mario_action(m, ACT_FREEFALL, 0)
    elseif stepResult == GROUND_STEP_HIT_WALL then
        set_mario_action(m, ACT_BACKWARD_AIR_KB, 0)
        set_mario_particle_flags(m, PARTICLE_VERTICAL_STAR, 0)
        m.vel.y = 30
    elseif stepResult == GROUND_STEP_NONE then
		set_mario_particle_flags(m, PARTICLE_DUST, false);
		play_sound(SOUND_MOVING_TERRAIN_SLIDE + m.terrainSoundAddend, m.marioObj.header.gfx.cameraToObject)
	end
    if (should_begin_sliding(m) ~= 0) then
        return set_mario_action(m, ACT_BEGIN_SLIDING, 0);
    end
    if m.actionTimer > 20 then
        set_mario_action(m, ACT_WALKING, 0)
    end
    if m.forwardVel < 0 then
        set_mario_action(m, ACT_WALKING, 0)
    end
    if m.actionTimer == 0 then
        play_sound(SOUND_ACTION_SPIN, m.marioObj.header.gfx.cameraToObject)
    end
    if m.actionTimer == 10 then
        play_sound(SOUND_ACTION_SPIN, m.marioObj.header.gfx.cameraToObject)
    end

    m.actionTimer = m.actionTimer + 1
end
hook_mario_action(ACT_GERSON_ROLL, act_gerson_roll) --kak



function hammer_mario_update(m)
    if _G.charSelect.character_get_current_costume() ~= 2 then return end
    if m.action == ACT_GROUND_POUND and m.input & INPUT_B_PRESSED ~= 0 then
        if (playerTP[m.playerIndex] >= 6 and gersonHammerCount[m.playerIndex] > 0) then
            if (m.prevAction == ACT_WALL_KICK_AIR) then
                gersonHammerCount[m.playerIndex] = gersonHammerCount[m.playerIndex] - 1
            end
            gersonHammerCount[m.playerIndex] = gersonHammerCount[m.playerIndex] - 1
            audio_sample_play(SOUND_GJUMP, m.pos, 1.0)
            set_mario_action(m, ACT_GERSON_HAMMER_SPIN, 0)
            m.faceAngle.y = m.intendedYaw
            playerTP[m.playerIndex] = playerTP[m.playerIndex] - 6
        elseif (m.playerIndex == 0) then
            audio_sample_play(SOUND_NOTP, m.pos, 1.5)
        end
    end
    if m.action == ACT_GROUND_POUND_LAND and m.prevAction == ACT_GERSON_HAMMER_SPIN then
		smlua_anim_util_set_animation(m.marioObj, "gerson_swing")
		if (m.input & INPUT_B_PRESSED ~= 0) then
			m.faceAngle.y = m.intendedYaw
			set_mario_action(m, ACT_DIVE, 0)
			m.vel.y = 25
			m.forwardVel = 45
		end
    end
    if m.action == ACT_GROUND_POUND_LAND and m.input & INPUT_A_PRESSED ~= 0 then
		if (m.prevAction == ACT_GERSON_HAMMER_SPIN or playerTP[m.playerIndex] >= 6) then
			audio_sample_play(SOUND_GJUMP, m.pos, 1.0)
			m.faceAngle.y = m.intendedYaw
			if m.flags & MARIO_WING_CAP ~= 0 then
				set_mario_action(m, ACT_FLYING_TRIPLE_JUMP, 0)
			else
				set_mario_action(m, ACT_TRIPLE_JUMP, 0)
			end
			play_sound(SOUND_GENERAL_BOING2, m.marioObj.header.gfx.cameraToObject)
			m.vel.y = 65
			m.forwardVel = 45
		elseif (m.playerIndex == 0) then
			audio_sample_play(SOUND_NOTP, m.pos, 1.5)
		end
	end
    if m.action == ACT_DIVE_SLIDE and m.controller.buttonDown & Z_TRIG ~= 0 then
        set_mario_action(m, ACT_GERSON_ROLL, 0)
    end
end

------------------------- HOOKS -------------------------

function geo_switch_gersonhammer(node, matStackIndex)
    local asSwitchNode = cast_graph_node(node)
    local m = geo_get_mario_state()
    if _G.charSelect.character_get_current_costume() ~= 2 then return end
    if m.action == ACT_GERSON_HAMMER_SPIN or m.action == ACT_GROUND_POUND_LAND and m.prevAction == ACT_GERSON_HAMMER_SPIN or (m.action == ACT_PUNCHING and m.actionArg == 9) then
         asSwitchNode.selectedCase = 1
    else
         asSwitchNode.selectedCase = 0
    end
end

function hook_moves()
    charSelect.character_hook_moveset(CT_GERSON, HOOK_MARIO_UPDATE, hammer_mario_update)
    charSelect.character_hook_moveset(CT_GERSON, HOOK_BEFORE_SET_MARIO_ACTION, gerson_before_set_action)
    charSelect.character_hook_moveset(CT_GERSON, HOOK_ON_SET_MARIO_ACTION, gerson_on_set_action)
end

hook_event(HOOK_ON_MODS_LOADED, hook_moves)


local function voiceToggle(index, value)
    mod_storage_save_bool("gersonvoice", value)
    if value then
		_G.charSelect.character_add_voice(E_MODEL_GERSON, VOICETABLE_GERSON)
		_G.charSelect.character_add_voice(E_MODEL_HOJ, VOICETABLE_GERSON)
        elseif value == false then
		_G.charSelect.character_add_voice(E_MODEL_GERSON, VOICETABLE_GERSONVA)
		_G.charSelect.character_add_voice(E_MODEL_HOJ, VOICETABLE_GERSONVA)
    end
end


hook_mod_menu_checkbox("Game voice" , mod_storage_load_bool("gersonvoice"), voiceToggle)